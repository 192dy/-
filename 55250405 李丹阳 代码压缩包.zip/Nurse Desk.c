#include "HMS.h"
#include "Doctor.h"
#include "Patient.h"
#include "Administrator.h"
#include "Nurse.h"
#include"widely_used.h"
#include "F4.h"
#include"registration.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>



/*============================================================
集成修改：护士台系统
============================================================*/

void nurse_desk_system_v2(char *NurseID, Doctor **head_D0, Patient **head_P0,
						  Nurse **head_N0, Medicine **head_M0,
						  Bed **head_B0, Consultation **head_C0) {
	Nurse *me = find_nurse(NurseID, *head_N0);
	if (!me) {
		printf("身份信息获取失败！\n");
		return;
	}
	
	printf("\n===== %s 护士工作站 =====\n", me->name);
	auto_deduct_bed_fee_for_all(*head_B0);
	
	int choice;
	while (1) {
		printf("\n1. 现场挂号（当天）\n");
		printf("2. 出院结算\n");
		printf("3. 新用户注册\n");
		printf("4. 查看候诊队列（医生维度）\n");
		printf("0. 退出\n");
		printf("请选择：");
		
		while (scanf("%d", &choice) != 1) {
			clear_input_buffer();
			printf("请输入数字：");
		}
		clear_input_buffer();
		
		if (choice == 0) break;
		
		switch (choice) {
			case 1: {
			// 现场挂号
			printf("\n--- 现场挂号 ---\n");
			char patientID[20];
			printf("请输入患者病历号：");
			fgets(patientID, sizeof(patientID), stdin);
			patientID[strcspn(patientID, "\n")] = 0;
			
			Patient *p = find_patient(patientID, *head_P0);
			if (!p) {
				printf("  患者不存在，请先注册。\n");
				break;
			}
			
			offline_booking_flow(head_D0, head_P0, head_C0, patientID, true);
			break;
		}
			case 2: {
				Patient *p = find_patient_by_id_with_retry(*head_P0);
				if (p) {
					Nurse_DischargeSettle(p->patientID, *head_P0, *head_B0,
										  *head_C0, *head_M0, get_current_time());
				}
				break;
			}
			case 3: {
				char new_id[20];
				printf("请输入新患者病历号：");
				scanf("%s", new_id);
				clear_input_buffer();
				register_new_patient(head_P0, new_id);
				break;
			}
			case 4: {
				view_doctor_queue_status(*head_D0, *head_C0);
				break;
			}
		default:
			printf("无效选项\n");
		}
	}
}

/*---------- 新增：护士查看医生候诊队列 ----------*/
void view_doctor_queue_status(Doctor *head_D, Consultation *head_C) {
	printf("\n========== 医生候诊队列 ==========\n");
	printf("请输入医生工号（0=返回）：");
	char doc_id[20];
	fgets(doc_id, sizeof(doc_id), stdin);
	doc_id[strcspn(doc_id, "\n")] = 0;
	if (strcmp(doc_id, "0") == 0) return;
	
	Doctor *doc = find_doctor(doc_id, head_D);
	if (!doc) {
		printf("  医生不存在。\n");
		return;
	}
	
	DateTime today = get_current_time();
	
	// 显示上午队列
	printf("\n----- %s 上午队列 -----\n", doc->name);
	display_queue_detail(head_C, doc_id, today, TIME_SLOT_MORNING);
	
	// 显示下午队列
	printf("\n----- %s 下午队列 -----\n", doc->name);
	display_queue_detail(head_C, doc_id, today, TIME_SLOT_AFTERNOON);
}

void display_queue_detail(Consultation *head_C, const char *doc_id,
								 DateTime date, TimeSlot slot) {
	// 收集该医生该时段所有记录
	Consultation *appts[60];
	int apt_count = 0;
	Consultation *walks[60];
	int walk_count = 0;
	
	Consultation *c = head_C;
	while (c != NULL) {
		if (strcmp(c->doctorID, doc_id) == 0 &&
			strcmp(c->status, "已撤销") != 0 &&
			c->consultTime_start.year == date.year &&
			c->consultTime_start.month == date.month &&
			c->consultTime_start.day == date.day) {
			
			int h = c->consultTime_start.hour;
			bool match = (slot == TIME_SLOT_MORNING && h >= 8 && h < 12) ||
			(slot == TIME_SLOT_AFTERNOON && h >= 13 && h < 18);
			if (match) {
				int len = strlen(c->recordID);
				if (len > 0 && c->recordID[len - 1] == 'A') {
					appts[apt_count++] = c;
				} else {
					walks[walk_count++] = c;
				}
			}
		}
		c = c->next;
	}
	
	printf("预约患者（优先）：%d人\n", apt_count);
	for (int i = 0; i < apt_count; i++) {
		printf("  %d. %s（%s）[%s]\n", i + 1,
			   appts[i]->patientNAME, appts[i]->patientID, appts[i]->status);
	}
	
	printf("现场挂号：%d人\n", walk_count);
	for (int i = 0; i < walk_count; i++) {
		printf("  %d. %s（%s）[%s]\n", i + 1,
			   walks[i]->patientNAME, walks[i]->patientID, walks[i]->status);
	}
	
	printf("总计：%d人\n", apt_count + walk_count);
}



//计算患者住院总床位费
float Nurse_CalculateBedCost(const char *patientID, Bed *head_B) {
	Bed *p = head_B;
	while (p) {
		//床位有人，床上患者id==要算钱的患者id
		if (p->status && strcmp(p->status->patient_id, patientID) == 0&&p->status->check_out.year==0) {
			p->status->check_out=get_current_time();//找到床位后把出院时间塞进去
			return get_days_between(p->status->check_in, p->status->check_out) * p->daily_cost;//总床位费=住的天数*每天床位费
		}
		p = p->next;
	}
	return 0;
}

//计算一个患者所有诊疗检查开药的总费用
float Nurse_CalculateConsultCost(const char *patientID, Consultation *head_C) {
	float sum = 0;
	Consultation *p = head_C;
	while (p != NULL) {
//这条诊疗记录是当前患者的，状态是已完成已住院才算费用
		if (strcmp(p->patientID, patientID) == 0 &&
			( strcmp(p->status, "已住院") == 0)) {
			sum += p->cost;
		}
		p = p->next;
	}
	return sum;
}


// ==============================================================================================
// 出院结算：出院，算钱，多退少补，清空床位，标记以出院
// ==============================================================================================
bool Nurse_DischargeSettle(const char *patientID, Patient *head_P, Bed *head_B,
						   Consultation *head_C, Medicine *head_M, DateTime dischargeTime) {
	// 出院前再次自动扣除床位费
	auto_deduct_bed_fee_for_all(head_B);
	
	// 1. 查找患者对应的床位
	Bed *bed = head_B;
	while (bed != NULL) {
		if (bed->status != NULL && strcmp(bed->status->patient_id, patientID) == 0) {
			break;
		}
		bed = bed->next;
	}
	
	// 未住院判断
	if (!bed || !bed->status) {
		printf("患者未住院！\n");
		return false;
	}
	
	// 2. 计算各项费用
	float bedCost = Nurse_CalculateBedCost(patientID, head_B);
	float consultCost = Nurse_CalculateConsultCost(patientID, head_C);
	float totalCost = bedCost + consultCost;
	float deposit = bed->status->ya_cash;
	float needPay = 0- deposit;  // 正确计算：需补缴 = 总费用 - 押金
	
	// 3. 打印结算单
	printf("\n=============== 出院结算 ===============\n");
	printf("患者ID：%s\n", patientID);
	printf("总费用：%.2f 元\n", totalCost);
	printf(" ├─ 床位费用：%.2f 元\n", bedCost);
	printf(" └─ 诊疗/检查/药品费用：%.2f 元\n", consultCost);
	printf("押金余额：%.2f 元\n", deposit);
	
	char payInfo[100];
	if (needPay > 0) {
		printf("需补缴：%.2f 元\n", needPay);
		sprintf(payInfo, "需补缴:%.2f元", needPay);
	} else {
		printf("应退款：%.2f 元\n", -needPay);
		sprintf(payInfo, "应退款:%.2f元", -needPay);
	}
	
	//退回押金
	bed->status->ya_cash=0;
	// ==============================================
	// 核心：自动生成 【出院记录】 写入诊疗记录
	// ==============================================
	Consultation *c = head_C;
	while (c != NULL) {
		// 找到该患者的住院诊疗记录
		if (strcmp(c->patientID, patientID) == 0 && strcmp(c->status, "已住院") == 0) {
			// 修改状态为已出院
			strcpy(c->status, "已出院");
			// 把总费用同步到诊疗记录 cost（非常重要）
			c->cost = totalCost;
			
			// 拼接完整出院记录（自动写入 record_of_inhospital）
			char record[104];
			sprintf(record,//这是个啥函数我也不知道
					"【出院记录】"
					"	出院时间：%04d-%02d-%02d"
					"	总费用：%.2f元 (床位%.2f + 诊疗%.2f)"
					"	住院费：%.2f元  %s"
					"	出院状态：已出院",
					dischargeTime.year, dischargeTime.month, dischargeTime.day,
					totalCost, bedCost, consultCost,
					deposit, payInfo
					);
			// 写入结构体
			strcpy(c->record_of_inhospital, record);
			printf(" 出院记录已自动生成并保存至诊疗记录！\n");
		}
		c = c->next;
	}
	
	return true;
}



