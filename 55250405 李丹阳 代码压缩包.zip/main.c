#include"HMS.h"
#include"Doctor.h"
#include"Patient.h"
#include"Administrator.h"
#include"Nurse.h"
#include"F4.h"
#include"widely_used.h"
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<stdbool.h>
#include <time.h>   // 通用时间头文件
#include <windows.h>// Windows额外头文件
int login_fail_count = 0;//记录登录次数
const int MAX_RETRY = 5; // 最大重试次数

 DateTime current_dt;


int main() {
	printf("请输入时间（按照：'年 月 日 时 分 秒'的格式输入）：\n");
	scanf("%d %d %d %d %d %d",&current_dt.year,&current_dt.month,&current_dt.day,&current_dt.hour,&current_dt.minute,&current_dt.second);
	if(current_dt.year==0)printf("加油\n");
	/*----------数据初始化---------------*/	
	printf("正在进行数据初始化...\n");
	Doctor *head_D=NULL;
	Patient *head_P=NULL;
	Medicine *head_M=NULL;
	Consultation *head_C=NULL;
	Nurse *head_N=NULL;
	Administrator *head_A=NULL;
	Bed *head_B=NULL;
	ExaminationItem *red=NULL;
	ExaminationItem *lab=NULL;
	
	//选择诊疗记录类型
	int choice=0;
	printf("请输入你想要诊疗数据的文件类型（0：400限号类  1：普通通用类）：\n");
	while(1){
		if(scanf("%d",&choice)!=1||(choice!=1&&choice!=0)){
			clear_input_buffer();
			printf("输入数据无效请重新输入:\n");
			continue;
		}
		break;
	}
	
	
    load_all_data(&head_D,&head_P,&head_M,&head_C,&head_N,&head_A,&head_B,&red,&lab,choice);//✅
	
	clear_input_buffer();
	//登录系统；封装
    login_system(&head_D,&head_P,&head_M,&head_C,&head_N,&head_A,&head_B,&red,&lab);
	printf("开始保存数据\n");
	//完成所有操作，直接存储所有数据
	save_all_data(head_D,head_P,head_M,head_C,head_N,head_B,red,lab,choice);//✅
	
	return 0;
}




void login_system(Doctor **head_D0,Patient **head_P0,Medicine **head_M0,Consultation **head_C0,Nurse **head_N0,Administrator **head_A0,Bed **head_B0,ExaminationItem **red,ExaminationItem **lab){
	//解引指针后续引用也方便，名称主函数一样引用更加方便
	/*但注意的是，有些函数，比如修改，最后可以采用返回对应类型的指针，也可以直接**类型传入void返回值*/
	auto_deduct_bed_fee_for_all(*head_B0);            //登录就扣减所有床位费；
	automatic_check_medicine(*head_M0);       //登录就直接去除所有过期的药品；
	printf("\n============= 欢迎来到医疗管理系统 =============\n");
	printf("请选择身份:\n");
	printf("1. 医生\n2. 护士\n3. 患者\n4. 管理人员\n5. 护士台值班人员\n0. 退出系统\n");
	printf("请输入选项: ");
	int choice;
	while(1){//进入while大循环密码输入错误 / 进入相关身份系统完成操作后才能结束
		//选择输入处理，不输入正确选择就一直循环
		if(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5&&choice!=0)){
			clear_input_buffer();
			printf("输入数据无效请重新输入:\n");
			continue;
		}
		if(choice==0) break;    //直接跳出系统保存数据
		
		//医生登录操作
		if(choice==1){
			char temp_id[20];
			char temp_password[20];
			printf("\n------------欢迎来到医生系统^_^-------------\n");
			//**处理登录问题**
			bool login_success=false;
			
			
			while(1){
			clear_input_buffer();
			printf("请输入你的工号：\n");
			gets(temp_id);
			temp_id[strcspn(temp_id,"\n")]=0;
			printf("请输入你的密码：\n");
			gets(temp_password);
			temp_password[strcspn(temp_password,"\n")]=0;
			//处理输入密码错误的情况
			if(!check_doctor(temp_id,temp_password,*head_D0)){
				login_fail_count++;
				if(login_fail_count==5){
					printf("输入工号/密码错误5次，请10mins后再来尝试\n");//这个地方存疑要不要去实现虽：思路是能不能利用gettime写死到文件里就可以了，不过要是这样每个人的结构体里都要再写很多数据了
					break;
				}
				printf("你已输入错误 %d 次，剩余 %d 次输入机会\n",login_fail_count,5-login_fail_count);
			}
				//密码输入成功直接退出循环
				else {
				login_success=true;
				break;//跳出while循环
				}
			}
			if(!login_success)break;//如果输入错误直接退出系统
			//**登陆成功进入医生系统
			printf("---------登陆成功--------\n");
			doctor_system(temp_id,head_D0,head_P0,head_N0,head_M0,head_B0,head_C0,*red,*lab);//医生函数给他退出的选择
			printf("祝您工作愉快！\n");
			break;//跳出while大循环
		}
		
		
		else if(choice==2){
			char temp_id[20];
			char temp_password[20];
			printf("------------欢迎来到护士系统^_^-------------\n");
			//**处理登录问题**
			bool login_success=false;
				
			while(1){
				clear_input_buffer();
				printf("请输入你的工号：\n");
				gets(temp_id);
				temp_id[strcspn(temp_id,"\n")]=0;
				printf("请输入你的密码：\n");
				gets(temp_password);
				temp_password[strcspn(temp_password,"\n")]=0;
				//处理输入密码错误的情况
				if(!check_nurse(temp_id,temp_password,*head_N0)){
					login_fail_count++;
					if(login_fail_count==5){
						printf("输入工号/密码错误5次，请10mins后再来尝试\n");
						break;
					}
					printf("你已输入错误 %d 次，剩余 %d 次输入机会\n",login_fail_count,5-login_fail_count);
				}
				//密码输入成功直接退出循环
				else {
					login_success=true;
					break;
				}
			}
			if(!login_success)break;
			//**登陆成功进入护士系统
			printf("---------登陆成功--------\n");
			nurse_system(temp_id,head_D0,head_P0,head_N0,head_B0,head_C0);
			printf("祝您工作愉快！\n");
			break;//跳出while大循环
		}
		
		
		else if(choice==3){
			char temp_id_0[20];
			char temp_password[20];
			printf("------------您好，很高兴为您服务^_^-------------\n");
			//**处理登录问题**
			bool login_success=false;

			while(1){
				clear_input_buffer();
				printf("请输入您的病历号：\n");
				gets(temp_id_0);
				temp_id_0[strcspn(temp_id_0,"\n")]=0;
				//处理新用户情形
				Patient *patient = find_patient(temp_id_0, *head_P0);
				if(patient == NULL) {
					clear_input_buffer();//****************************************//
					printf(" 患者不存在！是否注册新患者？(y/n)：");
					char reg_choice;
					while(scanf("%c", &reg_choice)!=1||(reg_choice != 'y' && reg_choice != 'Y'&&reg_choice != 'N' && reg_choice != 'n')){
						printf("是否注册新患者？(y/n)：\n");
						clear_input_buffer();
					}
					clear_input_buffer();
					if(reg_choice == 'y' || reg_choice == 'Y') {
						// 调用患者注册函数
						register_new_patient(head_P0, temp_id_0);
						patient = find_patient(temp_id_0, *head_P0);
					}
					else {
						break;
					}
				}
				
				clear_input_buffer();
				printf("请输入您的密码：\n");
				gets(temp_password);
				temp_password[strcspn(temp_password,"\n")]=0;
				//处理输入密码错误的情况
				if(!check_patient(temp_id_0,temp_password,*head_P0)){
					login_fail_count++;
					if(login_fail_count==5){
						printf("输入病历号/密码错误5次，请10mins后再来尝试\n");
						break;
					}
					printf("您已输入错误 %d 次，剩余 %d 次输入机会\n",login_fail_count,5-login_fail_count);
				}
				//密码输入成功直接退出循环
				else {
					login_success=true;
					break;
				}
			}
			if(!login_success)break;
			//**登陆成功进入病人系统
			printf("---------恭喜，登陆成功--------\n");
			patient_system(temp_id_0,head_D0,head_P0,head_N0,head_M0,head_B0,head_C0);
			printf("祝您早日康复！\n");
			break;//跳出while大循环
		}
		
		
		else if(choice==4){
			char temp_id[20];
			char temp_password[20];
			printf("------------欢迎来到管理员系统^_^-------------\n");
			//**处理登录问题**
			bool login_success=false;

			while(1){
				clear_input_buffer();
				printf("请输入您的工号：\n");
				gets(temp_id);
				temp_id[strcspn(temp_id,"\n")]=0;
				printf("请输入您的密码：\n");
				gets(temp_password);
				temp_password[strcspn(temp_password,"\n")]=0;
				//处理输入密码错误的情况
				if(!check_administrator(temp_id,temp_password,*head_A0)){
					login_fail_count++;
					if(login_fail_count==5){
						printf("输入工号/密码错误5次，请10mins后再来尝试\n");
						break;
					}
					printf("您已输入错误 %d 次，剩余 %d 次输入机会\n",login_fail_count,5-login_fail_count);
				}
				//密码输入成功直接退出循环
				else {
					login_success=true;
					break;
				}
			}
			if(!login_success)break;
			//**登陆成功进入超级管理员系统系统
			printf("---------登陆成功--------\n");
			administrator_system(temp_id,head_D0,head_P0,head_M0,head_C0,head_N0,head_A0,head_B0);
			printf("祝您工作愉快！\n");
			break;//跳出while大循环
		}
		
		
		
		else if(choice==5){
			char temp_id[20];
			char temp_password[20];
			printf("------------欢迎来到护士台值班系统^_^-------------\n");
			//**处理登录问题**
			bool login_success=false;
			
			while(1){
				clear_input_buffer();
				printf("请输入您的工号：\n");
				gets(temp_id);
				temp_id[strcspn(temp_id,"\n")]=0;
				printf("请输入您的密码：\n");
				gets(temp_password);
				temp_password[strcspn(temp_password,"\n")]=0;
				//处理输入密码错误的情况
				if(!check_nurse(temp_id,temp_password,*head_N0)){
					login_fail_count++;
					if(login_fail_count==5){
						printf("输入工号/密码错误5次，请10mins后再来尝试\n");
						break;
					}
					printf("您已输入错误 %d 次，剩余 %d 次输入机会\n",login_fail_count,5-login_fail_count);
				}
				//密码输入成功直接退出循环
				else {
					login_success=true;
					break;
				}
			}
			if(!login_success)break;
			//**登陆成功进入超级管理员系统系统
			printf("---------登陆成功--------\n");
			nurse_desk_system_v2(temp_id, head_D0,head_P0,head_N0,head_M0,head_B0,head_C0);
			printf("祝您工作愉快！\n");
			break;//跳出while大循环
		}
		
	}
	//结束开始保存数据；
}

//=======辅助函数：确认账号和密码是否正确========//

//工号密码核对函数
bool check_doctor(char *temp_id,char *temp_password,Doctor *head_D){
	Doctor *D=find_doctor(temp_id,head_D);
	if(D==NULL){
		printf("工号错误！请重新输入\n");
		return false;
	}
	else{
		if(strcmp(temp_password,D->login_password)!=0){
			printf("密码错误！请从新输入\n");
			return false;
		}
	}
	return true;
}

bool check_nurse(char *temp_id,char *temp_password,Nurse *head_N){
	Nurse *N=find_nurse(temp_id,head_N);
	if(N==NULL){
		printf("工号错误,请重新输入\n");
		return false;
	}
	else{
		if(strcmp(temp_password,N->login_password)!=0){
			printf("密码错误，请从新输入\n");
			return false;
		}
	}
	return true;
}

bool check_patient(char *temp_id,char *temp_password,Patient *head_P){	
    Patient *P=find_patient(temp_id,head_P);
	if(P==NULL){
		printf("工号错误！请重新输入\n");
		return false;
	}
	else{
		if(strcmp(temp_password,P->login_password)!=0){
			printf("密码错误！请从新输入\n");
			return false;
		}
	}
	return true;
}

bool check_administrator(char *temp_id,char *temp_password,Administrator *head_A){
	Administrator *A=find_administrator(temp_id,head_A);
	if(A==NULL){
		printf("工号错误！请重新输入\n");
		return false;
	}
	else{
		if(strcmp(temp_password,A->login_password)!=0){
			printf("密码错误！请从新输入\n");
			return false;
		}
	}
	return true;
}







