#include "HMS.h"
#include"widely_used.h"
#include"registration.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

//=========安排住院===========//


// 科室护士最大负荷：带3次重试，错3次返回菜单
int get_nurse_max_patients(const char *dept) {
// --------------------------
// 第1步：检查科室是否合法
// --------------------------
	if (strcmp(dept, "普通内科") == 0) return 3;
	if (strcmp(dept, "骨科") == 0) return 4;
	if (strcmp(dept, "妇产科") == 0) return 2;
	if (strcmp(dept, "儿科") == 0) return 2;
	if (strcmp(dept, "急诊科") == 0) return 1;
// --------------------------
// 第2步：科室不合法 → 返回 -1（代表错误）
// --------------------------
	return -1;
}

// 统计护士负责人数
//遍历床位链表+床位的负责护士是当前护士
int count_nurse_current_patients(const char *nurseID, Bed *head_B) {
	int cnt = 0;
	Bed *p = head_B;
	while (p) {
		//床位被占用+床位的负责护士是当前护士
		if (p->status && strcmp(p->status->nurse_id, nurseID) == 0) cnt++;
		p = p->next;
	}
	return cnt;
}

// 根据科室分配一个空闲护士（带3次重试，错3次返回菜单）

//最多 3 次重试输入科室；
//科室合法 → 遍历该科室护士，找到当前负责患者数 < 最大负荷的护士，返回；
//3 次输入错误 → 返回 NULL；
Nurse* assign_nurse_by_department(const char *dept, Nurse *head_N, Bed *head_B) {
	int retry = 3;  // 最多输3次
	char input_dept[20];
	strcpy(input_dept, dept); // 先把传进来的科室保存
	
	while (retry > 0) {
		// 检查科室是否合法
		int max_p = get_nurse_max_patients(input_dept);
		
		// 如果合法（不是-1），就正常分配护士
		if (max_p != -1) {//这个属于多余的步骤了，毕竟这个地方输入的科室基本就是100%过的
			Nurse *n = head_N;
			while (n != NULL) {
				//护士科室匹配+当前负责患者数<最大负荷
				if (strcmp(n->department, input_dept) == 0) {
					int now = count_nurse_current_patients(n->staff_id, head_B);
					if (now < max_p) {
						return n;//返回该空闲护士
					}
				}
				n = n->next;
			}
			return NULL;//该科室无空闲护士
		}
		
		// ==============================================
		// 走到这里 = 科室不合法 → 提示 + 重试
		// ==============================================
		printf("\n错误：没有这个科室【%s】，请重新输入！\n", input_dept);
		printf("剩余次数：%d 次\n", retry - 1);
		clear_input_buffer();
		printf("请输入正确科室代号(普通内科/骨科/妇产科/儿科/急诊科/影像科/医学检查科)：");
		scanf("%s", input_dept);
		
		retry--;
	}
	
	// ==============================================
	// 3次都错 → 直接返回NULL = 回到护士菜单
	// ==============================================
	printf("\n3次输入错误，返回护士菜单...\n");
	return NULL;
}

// 找空闲床位
Bed* assign_bed_by_type_and_dept(char *dept, int type, Bed *head_B) {
	Bed *p = head_B;
	char dept_0[50];
	strcpy(dept_0,dept);
	if(type==1){//vip房型单独归为vip病房科室
		strcpy(dept_0,"VIP病房");
	}
	while (p) {
		//床位科室+床位类型符合
		if (strcmp(p->department_name, dept_0) == 0 && p->type == type) {
			//床位的上一个患者已经出院
			if (!p->status ||p->status!=NULL && p->status->check_out.year!=0) return p;
		}
		p = p->next;
	}
	return NULL;
}


// 最终完美修复版：房型满了可切换，支持押金自定义，不卡死
void Nurse_AssignPatientToBed(char *patientID, char *doctorID, Patient *head_P, Doctor *head_D, Bed *head_B, Nurse *head_N) {
	printf("\n========== 安排患者住院 ==========\n");
	
	Patient *pat = find_patient(patientID, head_P);
	if (!pat) {
		printf("未找到患者！\n");
		return;
	}
	
	Doctor *doc = find_doctor(doctorID, head_D);
	if (!doc) {
		printf("未找到医生！\n");
		return;
	}
	
	// ======================
	// 选择病房类型（带换房逻辑）
	// ======================
	int type;
	Bed *bed = NULL;
	
	while (1) {
		printf("请选择病房类型：1=VIP  2=2人间  3=3人间\n");
		while (scanf("%d", &type) != 1 || (type < 1 || type > 3)) {
			printf("输入无效，请输入 1/2/3：");
			clear_input_buffer();
		}
		
		// 尝试分配对应类型床位
		bed = assign_bed_by_type_and_dept(doc->department, type, head_B);
		if (bed != NULL) {
			break; // 分配成功 → 跳出循环
		}
		
		// ============== 房型满了，询问换房 ==============
		printf("\n当前选择的病房类型已满！\n");
		printf("是否尝试选择其他类型病房？\n");
		printf("1 = 重新选择房型\n");
		printf("0 = 取消住院\n");
		
		int choice;
		clear_input_buffer();
		while (scanf("%d", &choice) != 1 || (choice != 0 && choice != 1)) {
			printf("请输入 0 或 1：");
			clear_input_buffer();
		}
		
		if (choice == 0) {
			printf("已取消住院安排！\n");
			return;
		}
		// choice == 1 → 继续循环，重新选房
	}
	
	// ======================
	// 分配护士
	// ======================
	Nurse *nur = assign_nurse_by_department(doc->department, head_N, head_B);
	if (!nur) {
		printf("无空闲护士，住院失败！\n");
		return;
	}
	
	// ======================
	// 【修复点】这里绝对不能再判断 bed->status！
	// 因为上面已经保证 bed 是空闲可用的
	// ======================
	
	// 新建住院信息
	Admission_information *adm = (Admission_information*)malloc(sizeof(Admission_information));
	if (adm == NULL) {
		printf("内存分配失败！\n");
		return;
	}
	memset(adm, 0, sizeof(Admission_information));
	
	// 住院天数
	printf("请输入建议病人住院的天数：\n");
	while(scanf("%d",&adm->days)!=1 || adm->days <=0){
		clear_input_buffer();
		printf("请输入正确的住院天数(正整数)：");
	}
	
	// 赋值信息
	strcpy(adm->patient_id, pat->patientID);
	strcpy(adm->doctor_id, doc->staff_id);
	strcpy(adm->nurse_id, nur->staff_id);
	adm->check_in = get_current_time();
	adm->last_deduct_day = adm->check_in;
	adm->check_out = (DateTime){0,0,0,0,0,0}; // 未出院
	
	// ======================
	// 押金输入
	// ======================
	float least_deposit = bed->daily_cost * adm->days;
	float deposit;
	printf("请输入住院押金金额（不能少于 %.2f）：", least_deposit);
	clear_input_buffer();
	
	while (scanf("%f", &deposit) != 1 || deposit < least_deposit) {
		clear_input_buffer();
		if(deposit < least_deposit){
			printf("押金不足！至少需要：%.2f\n", least_deposit);
		}
		printf("请输入正确押金：");
	}
	adm->ya_cash = deposit;
	
	// ======================
	// 扣除当日床位费
	// ======================
	float cost = bed->daily_cost;
	adm->ya_cash -= cost;
	adm->cost_cash = cost;
	
	// ======================
	// 绑定床位（真正占用）
	// ======================
	adm->next = NULL;
	bed->status = adm;
	
	// ======================
	// 成功提示
	// ======================
	printf("\n===== 住院办理成功！=====\n");
	printf("患者ID：%s\n", pat->patientID);
	printf("床位号：%s  类型：%d\n", bed->bed_id, type);
	printf("负责护士：%s\n", nur->staff_id);
	printf("当日床位费：%.2f  | 剩余押金：%.2f\n", cost, adm->ya_cash);
	printf("==========================\n");
}

// ==============================================================================================
// 三次重试查找床位ID
// ==============================================================================================
Bed* find_bed_by_id_with_retry(Bed *head_B) {
	char bedID[30];
	int retry = 3;
	while (retry > 0) {
		printf("\n请输入床位ID（剩余%d次机会）：\n", retry);
		scanf("%s", bedID);
		Bed *p = head_B;
		while (p) {
			if (strcmp(p->bed_id, bedID) == 0) return p;
			p = p->next;
		}
		printf("未找到床位！\n");
		retry--;
	}
	printf("\n3次输入错误，返回护士菜单...\n");
	return NULL;
}

// ==============================================================================================
// 三次重试查找患者ID
// ==============================================================================================
Patient* find_patient_by_id_with_retry(Patient *head_P) {
	char pid[30];
	int retry = 3;
	while (retry > 0) {
		printf("请输入患者ID（剩余%d次机会）：\n", retry);
		scanf("%s", pid);
		Patient *p = find_patient(pid, head_P);
		if (p) return p;
		printf("未找到患者！\n");
		retry--;
	}
	printf("\n3次输入错误，返回护士菜单...\n");
	return NULL;
}

// ==============================================================================================
// 三次重试查找医生ID
// ==============================================================================================
Doctor* find_doctor_by_id_with_retry(Doctor *head_D) {
	char did[30];
	int retry = 3;
	while (retry > 0) {
		printf("请输入医生ID（剩余%d次机会）：\n", retry);
		scanf("%s", did);
		Doctor *d = find_doctor(did, head_D);
		if (d) return d;
		printf("未找到医生！\n");
		retry--;
	}
	printf("\n3次输入错误，返回护士菜单...\n");
	return NULL;
}


void print_patient_info(Patient *patient, Patient *head_P) {
	if (patient == NULL) {
		printf("当前患者信息为空，开始三次重试查找患者...\n");//找不到的话就再找一次
		patient = find_patient_by_id_with_retry(head_P);
		if (!patient) {
			printf("三次查找失败，返回！\n");
			return;
		}
	}
	printf("=====================患者信息=====================\n");
	printf("姓名：%s\n", patient->name);
	printf("年龄：%d\n", patient->age);
	printf("身份证号：%s\n", patient->id_card_number);
	printf("病历号：%s\n", patient->patientID);
	printf("性别：%s\n", patient->gender);
	printf("出生日期：%d年%d月%d日\n", patient->birthday.year, patient->birthday.month, patient->birthday.day);
	printf("手机号码：%s\n", patient->phonenumber);
	printf("紧急联系人：%s\n", patient->Emergency_contact);
	printf("紧急联系人电话：%s\n", patient->Emergency_contact_phonenumber);
	printf("==================================================\n");
}


// ------------------------------ 兼容函数 ------------------------------
//打印某科室所有床位的使用情况（占用or空闲），统计总数?
void Nurse_PrintBedStatusByDept(Bed *head_B, const char *departmentID) {
	printf("\n===== 【%s】床位 =====\n", departmentID);
	Bed *p = head_B; 
	int total = 0, used = 0, free = 0;
	while (p) {
		if (strcmp(p->department_name, departmentID) == 0) {
			total++;
			printf("床位号：%s | 病房类型：%s | 病房号：%s | ", 
				   p->bed_id,
				   p->type == 1 ? "VIP" : (p->type == 2 ? "2人间" : "3人间"), 
				   p->Ward_number);
			// 遍历该床位下所有住院记录链表，找当前在院的
			Admission_information *adm = p->status;
			int is_used = 0;
			while (adm) {
				if (adm->check_out.year == 0) {
					// 找到当前未出院记录 = 有人住
					is_used = 1;
					used++;
					printf("占用 患者：%s 押金：%.2f\n", adm->patient_id, adm->ya_cash);
					break;  // 找到了就停，不用往后遍历
				}
				adm = adm->next;
			}
			// 遍历完都没找到 check_out.year == 0 的
			if (!is_used) {
				free++;
				printf("空闲\n");
			}
		}
		p = p->next;
	}
	printf("总计：%d | 占用：%d | 空闲：%d\n", total, used, free);
}

//显示当前登录护士的负责的所有病人?
void Nurse_QueryResponsiblePatients(const char *nurseID, Patient *head_P, Bed *head_B) {
	printf("\n我负责的患者：\n");
	Bed *p = head_B; 
	int c = 0;
	while (p) {
		// 遍历该床位下的所有住院记录链表
		Admission_information *adm = p->status;
		while (adm) {
			// 找到当前在院的（未出院）且是该护士负责的
			if (adm->check_out.year == 0 && strcmp(adm->nurse_id, nurseID) == 0) {
				c++;
				Patient *pa = find_patient(adm->patient_id, head_P);
				printf("%d. %s 床：%s 押金余额：%.2f\n",
					   c, pa ? pa->name : "未知", p->bed_id, adm->ya_cash);
				break;  // 找到了当前住院记录，不用继续遍历该床位的历史记录
			}
			adm = adm->next;
		}
		p = p->next;
	}
	if (!c) printf("无\n");
}



// 查看床位完整信息
void Nurse_QueryBedFullInfo(Bed *head_B, Patient *head_P, Doctor *head_D, Nurse *head_N, Consultation *head_C) {
	Bed *bed = find_bed_by_id_with_retry(head_B);
	if (!bed) return;
	
	printf("\n========== 床位【%s】完整信息 ==========\n", bed->bed_id);
	printf("科室：%s | 类型：%s | 病房号：%s | 日费：%.2f\n",
		   bed->department_name,
		   bed->type == 1 ? "VIP" : (bed->type == 2 ? "2人间" : "3人间"),
		   bed->Ward_number, bed->daily_cost);
	// 遍历该床位的 status 链表（住院记录链表），不是 bed 链表！
	Admission_information *adm = bed->status;
	int is_free = 1;  // 1=空闲，0=有人住
	
	while (adm) {
		if (adm->check_out.year == 0) {
			is_free = 0;  // 找到未出院记录，说明有人住
			break;
		}
		adm = adm->next;  // 遍历 status 链表，不是 bed 链表！
	}
	
	if (is_free) {
		printf("状态：空闲\n");
	} else {
	
	Patient *pat = find_patient(adm->patient_id, head_P);
	if (pat) {
		printf("\n----- 患者信息 -----\n");
		printf("病历号：%s\n姓名：%s | 性别：%s | 年龄：%d | 电话：%s\n",
			   pat->patientID, pat->name, pat->gender, pat->age, pat->phonenumber);
	}
	
	Consultation *cons = head_C;
	while (cons) {
		if (strcmp(cons->patientID, adm->patient_id) == 0) {
			printf("\n----- 诊疗信息 -----\n");
			printf("主诉：%s\n现病史：%s\n", cons->chiefComplaint, cons->presentIllness);
			printf("查体：%s\n诊断：%s\n", cons->physicalExam, cons->diagnosis);
			printf("检查项目：%s\n处方：%s\n", cons->labTests, cons->prescription);
			break;
		}
		cons = cons->next;
	}
	
	Doctor *doc = find_doctor(adm->doctor_id, head_D);
	if (doc) {
		printf("\n----- 主治医生 -----\n");
		printf("工号：%s\n姓名：%s | 性别：%s | 年龄：%d | 电话：%s\n科室：%s | 职称：%s\n",
			   doc->staff_id, doc->name, doc->gender, doc->age, doc->phone_number, doc->department, doc->job_title);
	}
	
	Nurse *nur = find_nurse(adm->nurse_id, head_N);
	if (nur) {
		printf("\n----- 负责护士 -----\n");
		printf("工号：%s\n姓名：%s | 性别：%s | 年龄：%d | 电话：%s\n科室：%s\n",
			   nur->staff_id, nur->name, nur->gender, nur->age, nur->phone_number, nur->department);
	}
	
	printf("\n----- 住院信息 -----\n");
	printf("入院：%d-%d-%d | 押金：%.2f\n",
		   adm->check_in.year, adm->check_in.month, adm->check_in.day,
		   adm->ya_cash);
	}
}


void Nurse_TriggerDepositWarn(const char *nid, Patient *P, Bed *B, float lim) {
	printf("\n押金不足患者：\n");
	Bed *p = B; 
	int c = 0;
	while (p) {
		// 遍历该床位下的所有住院记录链表，而不是只查第一个
		Admission_information *adm = p->status;
		while (adm) {
			// 只有当前正在住院的（未出院）且是该护士负责的，才检查押金
			if (adm->check_out.year == 0 && 
				strcmp(adm->nurse_id, nid) == 0 && 
				adm->ya_cash < lim) {
				c++;
				Patient *pt = find_patient(adm->patient_id, P);
				printf("%d. %s %.2f\n", c, pt ? pt->name : "?", adm->ya_cash);
			}
			adm = adm->next;
		}
		p = p->next;
	}
	if (!c) printf("无\n");
}


void nurse_system(char *NurseID, Doctor **head_D0, Patient **head_P0, Nurse **head_N0, Bed **head_B0, Consultation **head_C0)
{
	Doctor *head_D = *head_D0;
	Patient *head_P = *head_P0;
	Nurse *head_N = *head_N0;
	Bed *head_B = *head_B0;
	Consultation *head_C = *head_C0;
	Nurse *me = find_nurse(NurseID, head_N);
	
	if (!me) {
		printf("护士信息获取失败！\n");
		return;
	}
	
	printf("\n===== 普通护士系统 =====\n");
	// 自动扣费
	printf("\n【后台】住院安全扣费检查中...\n");
	auto_deduct_bed_fee_for_all(head_B);//这里面反复调用扣费函数是为了获取最最最新的扣费状态
	
	// 自动押金提醒
	printf("\n【提醒】您名下押金不足患者：\n");
	Nurse_TriggerDepositWarn(NurseID, head_P, head_B, 500.0f);
	
	int choice;
	while (1) {
		printf("\n1. 查看本科室床位\n");
		printf("2. 查看我负责的患者\n");
		printf("3. 查看床位完整信息\n");
		printf("4. 查看指定患者完整信息\n");
		printf("0. 退出\n");
		printf("请选择：");
		scanf("%d", &choice); getchar();
		
		if (choice == 0) break;
		
		switch (choice) {
		case 1:
			Nurse_PrintBedStatusByDept(head_B, me->department);
			break;
		case 2:
			Nurse_QueryResponsiblePatients(NurseID, head_P, head_B);
			break;
		case 3:
			Nurse_QueryBedFullInfo(head_B, head_P, head_D, head_N, head_C);
			break;
		case 4: {
			Patient *p = find_patient_by_id_with_retry(head_P);
			int sure = 0;
			if (p != NULL) {
				Bed *B = head_B;
				while (B) {
					// 遍历该床位下的所有住院记录链表
					Admission_information *adm = B->status;
					while (adm) {
						// 找到当前在院的（未出院）且是该患者的记录
						if (adm->check_out.year == 0 && 
							strcmp(adm->patient_id, p->patientID) == 0 &&
							strcmp(adm->nurse_id, NurseID) == 0) {
							sure = 1;
							break;
						}
						adm = adm->next;
					}
					if (sure) break;  // 找到了就退出外层循环
					B = B->next;
				}
			}
			if (sure == 0) printf("该病人不在你的住院管辖范围内，无权查看病人信息.\n");
			if (p != NULL && sure) print_patient_info(p, head_P);
		}
			break;
			
		}
		//由于护士的功能只有查询所以这里就不涉及到数据保存的问题
	}
}



