#ifndef Doctor_H
#define Doctor_H
#include"HMS.h"
#include"registration.h"
#include<stdbool.h>
//统计患者同一日挂号数

int today_patient_reg_count(Consultation*head_C,char*patient_id,DateTime today);


/*======================构建医生系统====================*/
/*------主函数（对应一切医生操作都写在里面）-----*/
void doctor_system(char *DoctorID,Doctor **head_D_0,Patient **head_P,Nurse **head_N,Medicine **head_M,Bed **head_B,Consultation **head_C,ExaminationItem *red,ExaminationItem *lab);

//这些地方要不要用全局变量由对应模块负责人决定
/*迁移到了doctor.c*/

/*---------挂号操作----------*/
// 3. 线下挂号：为到院患者挂号，即时就诊，无提前预约时间限制
bool offline_registration(Doctor **head_D0, Patient **head_P0, Consultation **head_C0,
						  char *patientID, char *doctorID,int time_period);
//计算挂号的时候已经有多少个病人在队列了，且是同一个时间段
int calculate_queue_position(Consultation *head_C, char *doctorID,
							 DateTime appointment_date, bool is_morning);
	

//1. 校验规则：每日总号源 400、医生限号 40、患者限号 5、科室限号 1；
void check_rest_number(/******/);
//1. 叫号：读取"候诊"状态的诊疗记录，显示患者信息 + 历史病史；
void Reading_Waiting_Information(Consultation **head_C0, Patient **head_P0, char *doctorID);
//2. 录入诊疗信息（主诉、诊断、医嘱）//4. 确认机制：弹窗确认费用 / 诊断；(直接写到录入诊疗信息这一列里)
void input_consultation_info(Consultation **head_C0, Medicine **head_M0,Bed **head_B0,Nurse **head_N0,
							 Patient **head_P0,Doctor **head_D0,
							 char *doctorID, char *patientID);
//2.'录入检查详情（影像，医疗检查专用）
void input_consultation_info_examine(Consultation **head_C0, Medicine **head_M0,Bed **head_B0,Nurse **head_N0,
									 Patient **head_P0,Doctor **head_D0,
									 char *doctorID, char *patientID,ExaminationItem *red,ExaminationItem *lab) ;
void choice_examine(ExaminationItem *examine_list, Consultation *current);//选择检查项目
//3. 开药：校验库存、限量（≤50 盒）、自动计算费用；
bool check_stock(Medicine *head_M, char *medicine_name, int required_amount);//校验库存
float calculate_medicine_cost(Medicine *head_M, char *prescription);//计算药品总费用
//5. 转住院：触发入院流程；

//床位函数：里面会用到住院函数可能有的情况就是：直接遍历head_B的链表传入想要的床位的类型，直接在status里构建相应的状态,
//但是这里就需要先打印对应科室剩余的床位状态，来确定各个类型病房的剩余量
void transfer_to_hospital(Consultation **head_C0, Bed **head_B0, Doctor **head_D0,
						  char *patientID, char *doctorID);

//6. 病历修改：标记原记录 "已撤销"，新建正确记录,那条记录全部废除，信息全部要重新录入；****这里要注意操作要符合实际医院的操作
void amend_consultation(Consultation **head_C0, Medicine **head_M0,
						char *old_recordID, char *doctorID);

// 模块2：诊疗/费用接口
void update_consult_status(Consultation *head_C, char *patientID, char *status);  // 更新诊疗状态
float get_medical_fee(Consultation *head_C, char *patientID);                     // 获取诊疗/药品/检查总费用

// 辅助显示函数
void display_department_list(void);
void view_my_patients(Consultation *head_C, char *doctorID);
void clear_input_buffer(void);

//住院函数
/*辅助函数*/
int get_nurse_max_patients(const char *dept);
int count_nurse_current_patients(const char *nurseID, Bed *head_B);
Nurse* assign_nurse_by_department(const char *dept, Nurse *head_N, Bed *head_B);



void Nurse_AssignPatientToBed(char *patientID, char *doctorID, Patient *head_P, Doctor *head_D, Bed *head_B, Nurse *head_N);


int today_doctor_count_all(Consultation *head_C, char *DoctorID,DateTime today);//截止到医生退出系统的时间，一共看了多少病人


bool doctor_on_duty(Doctor*doctor,DateTime now,int time_period);//检查这个时间段医生有没有空

int today_doctor_count(Consultation*head_C,char*doctor_id,DateTime today,int time_period);//检查某个医生在一段时间（上午/下午）的已挂号量；


void display_doctors_by_dept(Doctor *head_D, Consultation *head_C,const char *dept_name, DateTime today,int time_period);//展示在职医生

bool doctor_active(Doctor*doctor);//检查医生是否在职？

//检查号源看看触发了哪一个红线
CheckResult check_reg_restriction(Consultation *head_C, Doctor *target_doctor,
								  char *patientID, DateTime today,int time_period);


//辅助函数，计算医生工号哈希值
int hash_doctor_id(const char*doctorID);

//找到最快要过期的药品
MedicineIORecord *find_earlist_record(Medicine *selected_med);
//药品处理函数
void medicine_reduce(Medicine* selected_med,int quantity);

#endif
