#ifndef Nurse_H
#define Nurse_H
#include"HMS.h"
#include<stdbool.h>
#include"registration.h"


/*====================== 护士模块（住院/床位）对外接口 ======================*/
/*-----------构建护士系统（主函数）-------------*/
void nurse_system(char *NurseID, Doctor **head_D0, Patient **head_P0, Nurse **head_N0, Bed **head_B0, Consultation **head_C0);

// 优化：打印本科室床位状态（补充科室参数）
void Nurse_PrintBedStatusByDept(Bed *head_B, const char *departmentID);

// 优化：护士查自己负责的病人（补充必要参数）
void Nurse_QueryResponsiblePatients(const char *nurseID, Patient *head_P, Bed *head_B);

/**
 * @brief 病人出院结算（含床位释放、费用汇总、状态更新）
 * @param patientID 病人病历号（唯一标识）
 * @param head_P 病人链表头指针（用于查询病人信息/余额）
 * @param head_B 床位链表头指针（用于释放床位）
 * @param head_C 诊疗链表头指针（用于汇总诊疗费用）
 * @param dischargeTime 出院时间（用于判断是否免当日床位费）
 * @return true 结算成功并完成出院流程；false 结算失败（如余额不足/病人未住院）
 * @note 1. 结算成功后会将病人的住院状态改为“已出院”，床位状态改为“空闲”；
 *       2. 若出院时间在00:00-08:00，免当日床位费；
 */
bool Nurse_DischargeSettle(const char *patientID, Patient *head_P, Bed *head_B,
						   Consultation *head_C, Medicine *head_M,DateTime dischargeTime);


// 子接口1：计算单个病人的床位费用
float Nurse_CalculateBedCost(const char *patientID, Bed *head_B);

// 子接口2：计算单个病人的诊疗费用
float Nurse_CalculateConsultCost(const char *patientID, Consultation *head_C);

// 子接口3：计算单个病人的药品费用
float Nurse_CalculateMedicineCost(const char *patientID, Medicine *head_M);

// 总接口：汇总所有费用（调用子接口）
float Nurse_CalculatePatientTotalCost(const char *patientID, Bed *head_B, 
									  Consultation *head_C, Medicine *head_M,
									  DateTime inTime, DateTime outTime);

// 押金预警：登录时提示自己负责的病人余额不足
void Nurse_TriggerDepositWarn(const char *nurseID, Patient *head_P, Bed *head_B, float warnThreshold);

// 出院时间判断：返回是否免当日床位费
bool Nurse_JudgeDischargeBedFeeFree(DateTime inTime, DateTime outTime);


//护士输入一个床位 ID → 系统把这个床位的【全部信息】完整显示出来
void Nurse_QueryBedFullInfo(Bed *head_B, Patient *head_P, Doctor *head_D, Nurse *head_N, Consultation *head_C);



// ==============================================================================================
// 三次重试查找床位ID
// ==============================================================================================
Bed* find_bed_by_id_with_retry(Bed *head_B);

// ==============================================================================================
// 三次重试查找患者ID
// ==============================================================================================
Patient* find_patient_by_id_with_retry(Patient *head_P);

// ==============================================================================================
// 三次重试查找医生ID
// ==============================================================================================
Doctor* find_doctor_by_id_with_retry(Doctor *head_D) ;

// ==============================================================================================
// 查找单个患者并输出基本信息
// ==============================================================================================
void print_patient_info(Patient *patient, Patient *head_P);



//=========安排住院===========//
//辅助函数

// 科室护士最大负荷：带3次重试，错3次返回菜单
int get_nurse_max_patients(const char *dept);

// 统计护士负责人数
int count_nurse_current_patients(const char *nurseID, Bed *head_B);

// 根据科室分配一个空闲护士（带3次重试，错3次返回菜单）
Nurse* assign_nurse_by_department(const char *dept, Nurse *head_N, Bed *head_B);

// 找空闲床位
Bed* assign_bed_by_type_and_dept(char *dept, int type, Bed *head_B);

// 最终完美版：房型满了可切换，支持押金自定义，不卡死
void Nurse_AssignPatientToBed(char *patientID, char *doctorID, Patient *head_P, Doctor *head_D, Bed *head_B, Nurse *head_N);


/*-----------构建护士台值班系统（主函数）-------------*/
void nurse_desk_system_v2(char *NurseID, Doctor **head_D0, Patient **head_P0,
						  Nurse **head_N0, Medicine **head_M0,
						  Bed **head_B0, Consultation **head_C0);



#endif
