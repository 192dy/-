#include"HMS.h"
#include"Doctor.h"
#include"Patient.h"
#include"Nurse.h"
#include"F4.h"
#include"Administrator.h"
#include"widely_used.h"
#include"registration.h"
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<stdbool.h>
#include <time.h>   // 通用时间头文件


/* 辅助：从单号提取3位挂号序号（倒数第4位开始的数字） */
static int get_record_seq(Consultation *c) {
	int len = strlen(c->recordID);
	if (len < 4) return 999;  // 异常值排最后
	int seq = 0;
	// 倒数第4位开始读3位数字，例如 ...005A 提取出 5
	if (sscanf(c->recordID + len - 4, "%3d", &seq) == 1) return seq;
	return 999;
}

/* 辅助：判断是否为预约患者（单号末尾A=appointment） */
static bool is_appointment(Consultation *c) {
	int len = strlen(c->recordID);
	return (len > 0 && c->recordID[len - 1] == 'A');
}

/* 辅助：冒泡排序，预约优先、同渠道按序号从小到大 */
static void sort_patients_by_queue(Consultation **arr, int n) {
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - i - 1; j++) {
			bool apt_j = is_appointment(arr[j]);
			bool apt_j1 = is_appointment(arr[j+1]);
			
			// 预约 vs 现场：预约排前面
			if (!apt_j && apt_j1) {
				Consultation *tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
			}
			// 同渠道：按挂号序号从小到大（先挂的先看）
			else if (apt_j == apt_j1) {
				int seq_j = get_record_seq(arr[j]);
				int seq_j1 = get_record_seq(arr[j+1]);
				if (seq_j > seq_j1) {
					Consultation *tmp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = tmp;
				}
			}
		}
	}
}




/*============================================================
集成修改：叫号系统（医生端）
预约优先原则
============================================================*/

/*============================================================
叫号功能：按预约优先、挂号先后顺序叫号（不展示渠道）
============================================================*/
void reading_waiting_info_v2(Consultation **head_C0, Patient **head_P0,
							 char *doctorID) {
	Consultation *head_C = *head_C0;
	Patient *head_P = *head_P0;
	DateTime today = get_current_time();
	
	// 1. 收集该医生今天所有"候诊"患者
	Consultation *waiting[30];
	int count = 0;
	
	Consultation *c = head_C;
	while (c != NULL && count < 30) {
		if (strcmp(c->doctorID, doctorID) == 0 &&
			strcmp(c->status, "候诊") == 0 &&
			c->consultTime_start.year == today.year &&
			c->consultTime_start.month == today.month &&
			c->consultTime_start.day == today.day) {
			waiting[count++] = c;
		}
		c = c->next;
	}
	
	if (count == 0) {
		printf("\n========== 候诊患者列表 ==========\n");
		printf("当前无候诊患者\n");
		printf("==================================\n");
		return;
	}
	
	// 2. 排序：预约优先，同渠道按挂号序号（内部逻辑不变）
	sort_patients_by_queue(waiting, count);
	
	// 3. 叫第一个（排序后的队首）
	Consultation *target = waiting[0];
	
	// 显示患者信息
	Patient *patient = find_patient(target->patientID, head_P);
	if (!patient) {
		printf("  患者信息异常！\n");
		return;
	}
	
	printf("\n========== 当前就诊患者 ==========\n");
	printf("排队序号：第1号（共%d人候诊）\n", count);
	printf("挂号单号：%s\n", target->recordID);
	printf("患者姓名：%s\n", patient->name);
	printf("性别：%s | 年龄：%d\n", patient->gender, patient->age);
	printf("联系电话：%s\n", patient->phonenumber);
	
	// 历史记录
	printf("\n----- 历史就诊记录 -----\n");
	Consultation *h = head_C;
	int hist_count = 0;
	while (h != NULL) {
		if (strcmp(h->patientID, target->patientID) == 0 &&
			strcmp(h->status, "已完成") == 0) {
			hist_count++;
			printf("\n记录%d：%d-%02d-%02d | %s\n", hist_count,
				   h->consultTime_start.year, h->consultTime_start.month,
				   h->consultTime_start.day, h->diagnosis);
			printf("  处方：%s\n", h->prescription);
		}
		h = h->next;
	}
	if (hist_count == 0) printf("无历史记录\n");
	
	// 更新状态
	strcpy(target->status, "就诊中");
	printf("\n已叫号：%s，状态更新为【就诊中】\n", patient->name);
	
	// 顺便展示后面排队的人（不显示渠道）
	if (count > 1) {
		printf("\n----- 后续候诊队列 -----\n");
		for (int i = 1; i < count; i++) {
			printf("第%02d号：%s | %s\n",
				   i + 1,
				   waiting[i]->patientNAME,
				   waiting[i]->recordID);
		}
	}
	printf("==================================\n");
}


/*============================================================
展示列表：按预约优先、挂号先后顺序展示今日所有患者（不展示渠道）
============================================================*/
void view_my_patients(Consultation *head_C, char *doctorID) {
	DateTime today = get_current_time();
	
	// 1. 收集该医生今天所有患者（不限状态）
	Consultation *patients[50];
	int count = 0;
	
	Consultation *c = head_C;
	while (c != NULL && count < 50) {
		if (strcmp(c->doctorID, doctorID) == 0 &&
			c->consultTime_start.year == today.year &&
			c->consultTime_start.month == today.month &&
			c->consultTime_start.day == today.day) {
			patients[count++] = c;
		}
		c = c->next;
	}
	
	printf("\n========== 我的患者列表 ==========\n");
	
	if (count == 0) {
		printf("今日暂无患者\n");
		printf("================================\n");
		return;
	}
	
	// 2. 排序：预约优先，同渠道按挂号序号（内部逻辑不变）
	sort_patients_by_queue(patients, count);
	
	// 3. 按顺序输出（去掉渠道列）
	printf("序号 | 患者姓名 | 状态     | 挂号单号\n");
	printf("----------------------------------------\n");
	for (int i = 0; i < count; i++) {
		printf(" %02d  | %-8s | %-8s | %s\n",
			   i + 1,
			   patients[i]->patientNAME,
			   patients[i]->status,
			   patients[i]->recordID);
	}
	printf("----------------------------------------\n");
	printf("共 %d 位患者\n", count);
	printf("================================\n");
}


// 全局变量：记录当日挂号数
int daily_total_reg = 0; 
// 每日总号源400
int doc_reg_count[100] = {0};
// 医生当日挂号数（索引对应工号哈希，简化）
int pat_reg_count[100] = {0}; 
// 患者当日挂号数
int pat_dept_reg[100][7] = {0};

/*.@@@@ 全局变量设计不合理daily_total_reg 记录当日挂号数，但无 “每日清零” 逻辑（如系统启动 / 日期切换时重置），会导致跨天数据累加错误；全局变量直接暴露，无封装函数（如 get_daily_reg_count()/reset_daily_reg_count()），易被其他模块误修改，数据安全性差；
用 “工号哈希” 作为数组索引，无哈希冲突处理逻辑（不同工号哈希到同一索引时，数据会覆盖）。
3. 缺少参数校验*/


int calculate_queue_position(Consultation *head_C, char *doctorID,
							 DateTime appointment_date, bool is_morning) {
	// 收集该医生该日期该时段的所有记录
	Consultation *records[60];  // 最多60个
	int count = 0;
	
	Consultation *c = head_C;
	while(c != NULL) {
		if(strcmp(c->doctorID, doctorID) == 0 &&
		   strcmp(c->status, "已撤销") != 0 &&
		   c->consultTime_start.year == appointment_date.year &&
		   c->consultTime_start.month == appointment_date.month &&
		   c->consultTime_start.day == appointment_date.day) {
			
			bool c_is_morning = (c->consultTime_start.hour >= 8 && c->consultTime_start.hour < 12);
			if(is_morning == c_is_morning) {
				records[count] = c;
				count++;
			}
		}
		c = c->next;
	}
	
	// 按挂号单号排序（单号小的在前 = 先挂号的在前）
	// 线上预约在前一天19点后挂号，线下在当天挂号，所以线上单号更小
	for(int i = 0; i < count - 1; i++) {
		for(int j = 0; j < count - 1 - i; j++) {
			if(strcmp(records[j]->recordID, records[j + 1]->recordID) > 0) {
				Consultation *temp = records[j];
				records[j] = records[j + 1];
				records[j + 1] = temp;
			}
		}
	}
	
	return count;  // 返回已有几人（新患者排在第 count+1 位）
}

//统计患者同一日挂号数

int today_patient_reg_count(Consultation*head_C,char*patient_id,DateTime today)
{
	int count=0;
	Consultation *curr=head_C;
	while(curr != NULL)
	{
		if( strcmp(curr->patientID,patient_id) == 0 &&//是否是该患者
		   curr->consultTime_start.year == today.year &&
		   curr->consultTime_start.month == today.month &&
		   curr->consultTime_start.day == today.day )//是否是今天的挂号记录
		{
			count++;
		}
		curr=curr->next;	
	}
	return count;
}

CheckResult check_reg_restriction(Consultation *head_C, Doctor *target_doctor,
								  char *patientID, DateTime today,int time_period) 
{
	// 1. 检查总号源（上限400）
	int total_today = 0;
	Consultation *c = head_C;
	while(c != NULL) {
		if(c->consultTime_start.year == today.year &&
		   c->consultTime_start.month == today.month &&
		   c->consultTime_start.day == today.day) 
		{
			total_today++;
		}
		c = c->next;
	}
	if(total_today >= 400) return CHECK_FAIL_TOTAL;
	
	// 2. 检查医生限号（上限30）
	int doc_today = today_doctor_count(head_C, target_doctor->staff_id, today,time_period);
	if(doc_today >= 30) return CHECK_FAIL_DOCTOR;
	
	// 3. 检查患者限号（上限5）
	int pat_today = today_patient_reg_count(head_C, patientID, today);
	if(pat_today >= 5) return CHECK_FAIL_PATIENT;
	
	// 4. 检查科室限号（每个科室上限1次/日）
	// 注：此处简化实现，实际需要遍历患者当日挂号记录检查科室
	int dept_idx = get_dept_index(target_doctor->department);
	int hash_pat = hash_patient_id(patientID);
	if(pat_dept_reg[hash_pat][dept_idx] >= 1) return CHECK_FAIL_DEPT;
	
	return CHECK_PASS;
}

//辅助函数，计算医生工号哈希值

int hash_doctor_id(const char*doctorID)
{
	int hash=0;
	for(int i=1;doctorID[i] != '\0';i++)
	{
		hash=(hash*31+doctorID[i])%100;
	}
	return hash;
}


//生成挂号单号（格式：YYYYMMDD+工号+顺序号）
void generate_record_ID(DateTime sign_in_time,char*DoctorID,int daily_total_reg,char*out_recordID);



//生成挂号单号（格式：YYYYMMDD+工号+顺序号）

void generate_record_ID(DateTime sign_in_time,char*DoctorID,int daily_total_reg,char*out_recordID)
{
	sprintf(out_recordID,"%04d%02d%02d%s%03d",sign_in_time.year,sign_in_time.month,sign_in_time.day,DoctorID,daily_total_reg+1);
}


//检查医生是否任职

bool doctor_active(Doctor*doctor)
{
	return doctor->staff_status==1;
}


// 显示指定科室的在职医生列表
void display_doctors_by_dept(Doctor *head_D, Consultation *head_C,const char *dept_name, DateTime today,int time_period) 
{
	printf("\n================================= %s 医生列表 ==============================\n", dept_name);
	printf("%-10s %-10s %-10s %-10s %-15s\n", "工号", "姓名", "职称", "状态", "剩余号源");
	printf("----------------------------------------------------------\n");
	//输出基本格式
	Doctor *d = head_D;
	int found = 0;
	while(d != NULL) 
	{
		if(strcmp(d->department, dept_name) == 0 && d->staff_status==1) 
		{
			if(doctor_on_duty(d, today,time_period)) //这个函数在doctor里
			{//找到这个部门而且还值日的医生
				int today_count = 0;
				today_count = today_doctor_count(head_C,d->staff_id,today,time_period);
				
				// 此处简化：需要传入head_C计算，实际调用时传入
				printf("医生工号：%-10s 医生姓名：%-10s 医生职称：%-10s 剩余挂号数量：%-15d\n",
					   d->staff_id, d->name, d->job_title, 
					   30 - today_count);
				found++;
			}
		}
		d = d->next;
	}
	if(!found) 
	{
		printf("当前科室暂无值班医生\n");
	}
	printf("==================================\n");
}




//辅助函数
//检查医生当天是否值班

bool doctor_on_duty(Doctor*doctor,DateTime now,int time_period)
{   date now_0=(date){now.year,now.month,now.day};//找到最快要过期的药品
	int weekday=Get_current_day_of_the_week(now_0);//获取具体日期
	return (doctor->schedule[weekday][time_period-1] //这个地方我们的time_period对应的是1/2但是对应的早上和晚上在值班表里是0/1故用-1来达到目的
			);//检查是否排班（早班，午班）晚班不看病啊
}


//统计医生今日已接诊数
int today_doctor_count(Consultation*head_C,char*doctor_id,DateTime today,int time_period)
{
	int count=0;
	Consultation *curr=head_C;
	while(curr != NULL)
	{
		if( strcmp(curr->doctorID,doctor_id) == 0 &&//是否是该医生的诊疗记录
		   curr->consultTime_start.year == today.year &&
		   curr->consultTime_start.month == today.month &&
		   curr->consultTime_start.day == today.day &&//是否是今天的诊疗记录
		   strcmp(curr->status,"已撤销") != 0)//是否已撤消
		{
			if(time_period==1&&curr->consultTime_start.hour<12){
				count++;
			}
			else if(time_period==2&&curr->consultTime_start.hour>13){
				count++;
			}
			
		}
		curr=curr->next;
	}
	return count;
}




// 显示科室列表

void display_department_list(void) 
{
	printf("\n========== 科室列表 ==========\n");
	printf("1. 普通内科\n");
	printf("2. 骨科\n");
	printf("3. 妇产科\n");
	printf("4. 儿科\n");
	printf("5. 急诊科\n");
	printf("6. 影像科\n");
	printf("7. 医学检验科\n");
	printf("===============================\n");
}


//叫号，读取“候诊”状态的诊疗记录

void Reading_Waiting_Information(Consultation **head_C0, Patient **head_P0, char *doctorID) {
	Consultation *head_C = *head_C0;
	Patient *head_P = *head_P0;
	
	printf("\n========== 候诊患者列表 ==========\n");
	
	// 找到最早的候诊记录（按时间排序）
	//这里使用earliest来给找出候诊时间最早的患者
	Consultation *earliest = NULL;
	Consultation *c = head_C;
	DateTime today = get_current_time();
	
	while(c != NULL) {
		// 筛选条件：匹配医生 + 状态为候诊 + 日期为今天
		if(strcmp(c->doctorID, doctorID) == 0 &&
		   strcmp(c->status, "候诊") == 0 &&
		   c->consultTime_start.year == today.year &&
		   c->consultTime_start.month == today.month &&
		   c->consultTime_start.day == today.day) {
			
			if(earliest == NULL) {
				earliest = c;
			} else {
				// 比较时间，找更早的就诊时间
				// 先比较小时，小时相同再比较分钟
				if(c->consultTime_start.hour < earliest->consultTime_start.hour ||
				   (c->consultTime_start.hour == earliest->consultTime_start.hour &&
					c->consultTime_start.minute < earliest->consultTime_start.minute)) {
					earliest = c;
				}
			}
		}
		c = c->next;
	}
	
	if(earliest == NULL) {
		printf("当前无候诊患者\n");
		return;
	}
	
	// ==================== 显示患者基本信息 ====================
	Patient *patient = find_patient(earliest->patientID, head_P);
	if(patient == NULL) {
		printf(" 患者信息异常！\n");
		return;
	}
	
	printf("\n========== 当前就诊患者 ==========\n");
	printf("挂号单号：%s\n", earliest->recordID);
	printf("患者姓名：%s\n", patient->name);
	printf("性别：%s\n", patient->gender);
	printf("年龄：%d\n", patient->age);
	printf("联系电话：%s\n", patient->phonenumber);
	printf("紧急联系人：%s (%s)\n", patient->Emergency_contact, 
		   patient->Emergency_contact_phonenumber);
	
	// ==================== 显示历史病史 ====================
	// 遍历该患者的所有历史诊疗记录，供医生参考
	printf("\n========== 历史诊疗记录 ==========\n");
	Consultation *history = head_C;
	int history_count = 0;
	while(history != NULL) {
		// 只显示已完成的记录（不包括候诊、就诊中、已撤销）
		if(strcmp(history->patientID, earliest->patientID) == 0 &&
		   strcmp(history->status, "已完成") == 0) {
			history_count++;
			printf("\n--- 就诊记录 %d ---\n", history_count);
			printf("就诊时间：%d-%02d-%02d\n", 
				   history->consultTime_start.year,
				   history->consultTime_start.month,
				   history->consultTime_start.day);
			printf("就诊医生：%s\n", history->doctorNAME);
			printf("主诉：%s\n", history->chiefComplaint);
			printf("诊断：%s\n", history->diagnosis);
			printf("处方：%s\n", history->prescription);
		}
		history = history->next;
	}
	if(history_count == 0) {
		printf("无历史就诊记录\n");
	}
	
	// ==================== 更新状态为"就诊中" ====================
	strcpy(earliest->status, "就诊中");
	printf("\n==================================\n");
	printf("已叫号，患者 %s 进入就诊中状态\n", patient->name);
}

/* ==================== 药品管理函数 ==================== */

bool check_stock(Medicine *head_M, char *medicine_name, int required_amount) 
{
	Medicine *m = head_M;
	while(m != NULL) {
		if(strcmp(m->name, medicine_name) == 0) 
		{
			if(m->stock >= required_amount) 
			{
				return true;
			} 
			else 
			{
				printf(" 药品 %s 库存不足！当前库存：%d，需求：%d\n", 
					   medicine_name, m->stock, required_amount);
				return false;
			}
		}
		m = m->next;
	}
	printf(" 药品 %s 不存在！\n", medicine_name);
	return false;
}

//生成出药记录
void medicine_recored(Medicine *Med,int quantity,char *doctorID){
	MedicineIORecord *new_recored=(MedicineIORecord *)malloc(sizeof(MedicineIORecord));
	new_recored->number=quantity;
	new_recored->deadline_time=(DateTime){0,0,0,0,0,0};
	new_recored->is_valid=1;
	new_recored->io_type=2;
	strcpy(new_recored->operator_id,doctorID);
	new_recored->operate_time=get_current_time();
	new_recored->next=Med->io_list;
	Med->io_list=new_recored;
}

//在到最快过期的药品并减少药品库存
bool deduct_medicine_stock(Medicine **head_M0, char *prescription,char *doctorID) {
	char temp_prescription[300];
	strcpy(temp_prescription, prescription);
	char *token = strtok(temp_prescription, ",");
	while(token != NULL) {
		char med_name[50];
		int quantity;
		if(sscanf(token, "%s %d盒", med_name, &quantity) == 2) {
			Medicine *Med=find_medicine(med_name,*head_M0);
			medicine_reduce(Med,quantity);
			medicine_recored(Med,quantity,doctorID);
		}
		token = strtok(NULL, ",");
	}
	return true;
}


// 模糊查询药品（按药品名称匹配）
int fuzzy_search_medicine(Medicine *head, const char *keyword, Medicine **results, int max_results) {
	if (head == NULL || keyword == NULL || strlen(keyword) == 0) {
		return 0;
	}
	int count = 0;
	Medicine *current = head;
	while (current != NULL && count < max_results) {
		// 匹配规则：关键词是药品名的子串（支持中文模糊匹配）
		if (strstr(current->name, keyword) != NULL) {
			results[count++] = current;
		}
		current = current->next;
	}
	return count;
}

// 药品选择交互函数
Medicine *select_medicine_by_fuzzy_search_consultation(Medicine *head) {
	char keyword[50];
	const int MAX_RESULTS = 20;
	Medicine *results[MAX_RESULTS];
	
	while (1) {
		// 1. 输入查询关键词
		printf("\n===== 药品模糊查询 =====\n");
		clear_input_buffer();
		printf("请输入药品名称关键词（输入0返回）：");
		scanf("%s", keyword);
		clear_input_buffer();
		
		// 2. 退出查询
		if (strcmp(keyword, "0") == 0) {
			printf("退出药品查询...\n");
			return NULL;
		}
		
		// 3. 执行模糊查询
		int match_count = fuzzy_search_medicine(head, keyword, results, MAX_RESULTS);
		
		// 4. 无匹配结果
		if (match_count == 0) {
			printf(" 未找到包含「%s」的药品信息！\n", keyword);
			clear_input_buffer();
			printf("是否重新查询？(1=重新查询，0=返回)：");
			int choice;
			while (scanf("%d", &choice) != 1 || (choice != 0 && choice != 1)) {
				clear_input_buffer();
				printf("输入错误！请输入1(重新查询)或0(返回)：");
			}
			clear_input_buffer();
			if (choice == 0) {
				return NULL;
			}
			continue;
		}
		
		// 5. 展示匹配结果
		printf("\n===== 匹配药品（共%d种）=====\n", match_count);
		printf("%-6s %-20s %-10s %-10s\n", "编号", "药品名称", "库存", "售价(元)");
		printf("--------------------------------------------------\n");
		for (int i = 0; i < match_count; i++) {
			printf("[%-4d] %-20s %-10d %-10.2f\n",
				   i+1, results[i]->name, results[i]->stock, results[i]->selling_price);
		}
		
		// 6. 选择结果
		printf("\n请选择操作：\n");
		printf("1~%d = 选中对应药品 | 0 = 重新查询 | -1 = 返回\n", match_count);
		int select;
		while (1) {
			clear_input_buffer();
			printf("请输入选项：");
			if (scanf("%d", &select) != 1) {
				clear_input_buffer();
				printf(" 输入错误！请输入数字！\n");
				continue;
			}
			clear_input_buffer();
			if (select == 0) {
				break;
			} else if (select == -1) {
				return NULL;
			} else if (select >= 1 && select <= match_count) {
				return results[select-1];
			} else {
				printf(" 输入超出范围！请输入1~%d、0或-1\n", match_count);
			}
		}
	}
}

//找到最快要过期的药品
MedicineIORecord *find_earlist_record(Medicine *selected_med){
	if (selected_med == NULL) {
		printf("错误：selected_med 为 NULL\n");
		return NULL;
	}
	if (selected_med->io_list == NULL) {
		printf("错误：%s 的 io_list 为 NULL\n", selected_med->name);
		return NULL;
	}
	/////////////
	//找不到阿司匹林泡腾片，数据丢了？？？
	MedicineIORecord *m_r = selected_med->io_list;
	
	
	if(m_r->next==NULL) {
		return m_r;
	}
	else {
		MedicineIORecord *earlist=m_r;
		while(m_r&&m_r->io_type==1){
			if(constract_two_days(m_r->deadline_time,earlist->deadline_time))  ;
			else earlist=m_r;
			m_r=m_r->next;
		}
		return earlist;
	}
}
//药品处理函数
void medicine_reduce(Medicine* selected_med,int quantity){
	selected_med->stock -= quantity;
	int need_number=quantity;
	while(need_number){
		MedicineIORecord *recordor=find_earlist_record(selected_med);
		if(recordor->number>=need_number){
			recordor->number-=need_number;
			need_number=0;
			if(recordor->number==0)
			{
				recordor->is_valid=false;
			}
		}
		else {
			need_number=need_number-recordor->number;
			recordor->is_valid=false;
		}
	}
}



// 交互式处方录入函数
void input_prescription_interactive(Consultation *current, Medicine **head_M0) {
	Medicine *head_M = *head_M0;
	
	char prescription_buffer[300] = "";
	float total_medicine_cost = 0.0;
	
	printf("\n========== 处方录入 ==========\n");
	printf("说明：支持模糊查询药品，可多次添加药品\n");
	printf("===================================\n");
	
	int medicine_index = 0;
	
	while (1) {
		printf("\n----- 添加第 %d 种药品 -----\n", medicine_index + 1);
		
		// 步骤1：模糊查询选择药品
		printf("请选择药品：\n");
		Medicine *selected_med = select_medicine_by_fuzzy_search_consultation(head_M);
		
		if (selected_med == NULL) {
			if (medicine_index == 0) {
				printf(" 尚未添加任何药品！\n");
				printf("是否确定不开具处方？(y/n)：");
				char confirm;////////////////////////////////////////////////////////////////////////////////////////////////clear已经删了
				scanf("%c", &confirm);
				clear_input_buffer();
				if (confirm == 'y' || confirm == 'Y') {
					strcpy(current->prescription, "");
					printf("已取消处方录入\n");
					return;
				} else {
					continue;
				}
			} else {
				printf("是否结束添加药品？(y/n)：");
				char confirm;
				clear_input_buffer();
				scanf("%c", &confirm);
				clear_input_buffer();
				if (confirm == 'y' || confirm == 'Y') {
					break;
				} else {
					continue;
				}
			}
		}
		
		// 步骤2：显示选中药品信息
		printf("\n 已选择药品：%s\n", selected_med->name);
		printf("   库存：%d | 售价：%.2f 元/盒\n", selected_med->stock, selected_med->selling_price);
		
		// 步骤3：输入数量
		int quantity;
		while (1) {
			printf("请输入数量（盒，输入0取消选择此药品）：");
			if (scanf("%d", &quantity) != 1) {
				clear_input_buffer();
				printf(" 输入无效！请输入正整数！\n");
				continue;
			}
			clear_input_buffer();
			
			if (quantity == 0) {
				printf("已取消选择此药品\n");
				break;
			}
			
			if (quantity < 0) {
				printf(" 数量不能为负数！请重新输入！\n");
				continue;
			}
			
			// 检查库存
			if (quantity > selected_med->stock) {
				printf(" 库存不足！当前库存：%d，无法满足需求：%d\n", 
					   selected_med->stock, quantity);
				printf("请重新输入数量（不超过%d）：\n", selected_med->stock);
				continue;
			}
			
			break;
		}
		
		if (quantity == 0) {
			continue;
		}
		// 步骤4：即时结算
		float item_cost = selected_med->selling_price * quantity;
		//不具体扣减费用，等到后来确认了再去扣减
		total_medicine_cost += item_cost;
		medicine_index++;
		// 添加到缓冲区
		char item_str[400];
		sprintf(item_str, "%s %d盒", selected_med->name, quantity);
		if (strlen(prescription_buffer) > 0) {
			strcat(prescription_buffer, ", ");
		}
		strcat(prescription_buffer, item_str);
		// 显示本次添加结果
		printf("\n----- 本次添加结算 -----\n");
		printf("药品：%s\n", selected_med->name);
		printf("数量：%d 盒\n", quantity);
		printf("单价：%.2f 元\n", selected_med->selling_price);
		printf("小计：%.2f 元\n", item_cost);
		printf("扣除后库存：%d 盒\n", selected_med->stock-quantity);
		
		// 显示当前处方汇总
		printf("\n----- 当前处方汇总 -----\n");
		printf("处方：%s\n", prescription_buffer);
		printf("累计药品费用：%.2f 元\n", total_medicine_cost);
		printf("------------------------\n");
		
		// 步骤5：询问是否继续
		printf("\n是否继续添加药品？(1=继续添加，0=完成处方)：");
		int choice;
		while (scanf("%d", &choice) != 1 || (choice != 0 && choice != 1)) {
			clear_input_buffer();
			printf(" 输入错误！请输入1(继续添加)或0(完成处方)：");
		}
		clear_input_buffer();
		
		if (choice == 0) {
			current->cost=total_medicine_cost;
			break;
		}
	}
	
	// 保存处方
	strcpy(current->prescription, prescription_buffer);
	printf("*********************************%s*******************************************",current->prescription);
	printf("\n========== 处方录入完成 ==========\n");
	if (strlen(prescription_buffer) > 0) {
		printf("最终处方：%s\n", prescription_buffer);
		printf("药品总费用：%.2f 元\n", total_medicine_cost);
	} else {
		printf("未开具任何药品\n");
	}
	printf("===================================\n");
}








/* ==================== 诊疗信息录入 ==================== */

void input_consultation_info(Consultation **head_C0, Medicine **head_M0,Bed **head_B0,Nurse **head_N0,
							 Patient **head_P0,Doctor **head_D0,
							 char *doctorID, char *patientID) {//这个函数也没有while保护他这个地方出了，
	Consultation *head_C = *head_C0;
	//Medicine *head_M = *head_M0;
	Bed *head_B=*head_B0;
	Nurse *head_N=*head_N0;
	Patient *head_P=*head_P0;
	Doctor *head_D=*head_D0;
	
	// 找到当前就诊中的记录
	Consultation *current = head_C;
	while(current != NULL) {
		if(strcmp(current->doctorID, doctorID) == 0 &&
		   strcmp(current->patientID, patientID) == 0 &&
		   strcmp(current->status, "就诊中") == 0) {
			break;
		}
		current = current->next;
	}
	
	if(current == NULL) {
		printf(" 未找到就诊中的记录！请先叫号\n");
		return;
	}
	
	printf("\n========== 录入诊疗信息 ==========\n");
	printf("患者：%s（挂号单号：%s）\n", current->patientNAME, current->recordID);
	clear_input_buffer();
	
	//char chiefComplaint_0[400];
	// -------------------- 1. 录入主诉 --------------------
	printf("请输入主诉（如：头痛三天）：\n");
	fgets(current->chiefComplaint, sizeof(current->chiefComplaint), stdin);
	current->chiefComplaint[strcspn(current->chiefComplaint, "\n")] = 0;
	
	//char presentIllness_0[400];
	// -------------------- 2. 录入现病史 --------------------
	printf("请输入现病史（详细描述发病过程）：\n");
	fgets(current->presentIllness, sizeof(current->presentIllness), stdin);
	current->presentIllness[strcspn(current->presentIllness, "\n")] = 0;
	
	//char physicalExam_0[400];
	// -------------------- 3. 录入体格检查 --------------------
	printf("请输入体格检查结果：\n");
	fgets(current->physicalExam, sizeof(current->physicalExam), stdin);
	current->physicalExam[strcspn(current->physicalExam, "\n")] = 0;
	
	//char diagnosis_0[400];
	// -------------------- 4. 录入诊断结果 --------------------
	printf("请输入诊断结果：\n");
	fgets(current->diagnosis, sizeof(current->diagnosis), stdin);
	current->diagnosis[strcspn(current->diagnosis, "\n")] = 0;
	
	//char labTests_0[400];
	// -------------------- 5. 录入检查项目 --------------------
	printf("请输入建议检查项目（如：血常规、胸片）：\n");
	fgets(current->labTests, sizeof(current->labTests), stdin);
	current->labTests[strcspn(current->labTests, "\n")] = 0;
	
	
	// -------------------- 6. 录入治疗计划 --------------------
	printf("请输入治疗计划：\n");
	fgets(current->treatmentPlan, sizeof(current->treatmentPlan), stdin);
	current->treatmentPlan[strcspn(current->treatmentPlan, "\n")] = 0;
	
	// -------------------- 7. 录入处方 --------------------
	input_prescription_interactive(current, head_M0);
	

	// ==================== 自动计算费用 ====================
	// 药品费用：按售价×数量计算
	float medicine_cost = current->cost;
	// 总费用 = 药品费 + 检查费 + 挂号费(20元)
	current->cost = medicine_cost + 20.0;//+ exam_cost 
	
	// ==================== 确认机制 ====================
	// 显示录入信息供医生确认，确保不会误录
	printf("\n========== 诊疗信息确认 ==========\n");
	printf("主诉：%s\n", current->chiefComplaint);
	printf("现病史：%s\n", current->presentIllness);
	printf("体格检查：%s\n", current->physicalExam);
	printf("诊断结果：%s\n", current->diagnosis);
	printf("检查项目：%s\n", current->labTests);
	printf("治疗计划：%s\n", current->treatmentPlan);
	printf("处方：%s\n", current->prescription);
	printf("----------------------------------\n");
	printf("费用明细：\n");
	printf("  挂号费：20.00 元\n");
	//printf("  检查费：%.2f 元\n", exam_cost);
	printf("  药品费：%.2f 元\n", medicine_cost);
	printf("  总费用：%.2f 元\n", current->cost);
	printf("==================================\n");
	
	printf("确认保存诊疗信息？(y/n)：");
	char confirm;
	while(scanf("%c", &confirm)!=1||(confirm!='y'&&confirm!='Y'&&confirm!='n'&&confirm!='N')){
		printf("请输入正确字母：(y/n)\n");
	}
	strcpy(current->status,"已完成");
	clear_input_buffer();
	if(confirm == 'y' || confirm == 'Y') {
		// 扣减药品库存（实际消耗）
		if(strlen(current->prescription) > 0) {
			deduct_medicine_stock(head_M0, current->prescription,doctorID);
		}
		// 询问是否需要住院
		printf("患者是否需要住院？(y/n)：");
		char need_hospital;
		scanf("%c", &need_hospital);
		clear_input_buffer();
		//这里需要插入患者住院的函数，联动护士住院那里
		if(need_hospital == 'y' || need_hospital == 'Y') {
			Nurse_AssignPatientToBed(patientID, doctorID,head_P,head_D,head_B, head_N);
		} else {
			strcpy(current->status, "已完成");
			printf(" 诊疗完成！\n");
		}
		
		// 记录结束时间
		current->consultTime_end = get_current_time();
		printf("诊疗记录已保存，结束时间：%d-%02d-%02d %02d:%02d\n",
			   current->consultTime_end.year, current->consultTime_end.month,
			   current->consultTime_end.day, current->consultTime_end.hour,
			   current->consultTime_end.minute);
	} else {
		printf("已取消保存，诊疗信息未录入\n");
	}
}


void choice_examine(ExaminationItem *examine_list, Consultation *current) {
	if (!examine_list || !current) return;
	
	strcpy(current->labTests, "");  // 清空之前的
	current->cost = 0.0;
	int first = 1;
	int choice;
	
	while (1) {
		printf("\n=== 检查项目列表 ===\n");
		ExaminationItem *p = examine_list;
		int i = 1;
		while (p) {
			printf("%d. %s (%.2f元)\n", i, p->item_name, p->price);
			p->status = i++;  // 临时用status存序号
			p = p->next;
		}
		printf("0. 结束\n");
		
		if (strlen(current->labTests) > 0) {
			printf("\n已选: %s | 费用: %.2f元\n", current->labTests, current->cost);
		}
		printf("\n选择: ");
		
		if (scanf("%d", &choice) != 1) {
			while (getchar() != '\n');
			continue;
		}
		if (choice == 0) break;
		if (choice < 1 || choice >= i) {
			printf("无效序号！\n");
			continue;
		}
		
		// 找到选中的项目
		ExaminationItem *t = examine_list;
		while (t && t->status != choice) t = t->next;
		if (!t) continue;
		
		// 追加到 labTests 字符串
		if (first) {
			strcpy(current->labTests, t->item_name);
			first = 0;
		} else {
			strcat(current->labTests, "，");
			strcat(current->labTests, t->item_name);
		}
		
		// 累加费用
		current->cost += t->price;
		printf(" %s (%.2f元) | 累计: %.2f元\n", 
			   t->item_name, t->price, current->cost);
	}
	
	// 恢复status
	ExaminationItem *r = examine_list;
	while (r) { r->status = 1; r = r->next; }
}

/* ==================== 诊疗信息录入 ==================== */

void input_consultation_info_examine(Consultation **head_C0, Medicine **head_M0,Bed **head_B0,Nurse **head_N0,
									 Patient **head_P0,Doctor **head_D0,
									 char *doctorID, char *patientID,ExaminationItem *red,ExaminationItem *lab) {//这个函数也没有while保护他这个地方出了，
	Consultation *head_C = *head_C0;
	
	// 找到当前就诊中的记录
	Consultation *current = head_C;
	while(current != NULL) {
		if(strcmp(current->doctorID, doctorID) == 0 &&
		   strcmp(current->patientID, patientID) == 0 &&
		   strcmp(current->status, "就诊中") == 0) {
			break;
		}
		current = current->next;
	}
	
	if(current == NULL) {
		printf(" 未找到就诊中的记录！请先叫号\n");
		return;
	}
	
	printf("\n========== 录入诊疗信息 ==========\n");
	printf("患者：%s（挂号单号：%s）\n", current->patientNAME, current->recordID);	
	//char chiefComplaint_0[400];
	// -------------------- 1. 录入主诉 --------------------
	strcpy(current->chiefComplaint,"医学检查无需录入主诉");
	// -------------------- 2. 录入现病史 --------------------
	strcpy(current->presentIllness,"医学检查无需录入现病史");
	// -------------------- 3. 录入体格检查 --------------------
	strcpy(current->physicalExam,"医学检查无需录入体格检查结果");
	// -------------------- 4. 录入检查项目 --------------------
	/////////////////////
	///////////////////a
	// 根据科室选择对应的项目列表
	ExaminationItem *examine_list = NULL;
	if (strcmp(current->department, "影像科") == 0) {
		examine_list = red;
	} else if (strcmp(current->department, "医学检验科") == 0) {
		examine_list = lab;
	}
	choice_examine(examine_list, current);
	
	
	// -------------------- 5. 录入诊断结果 --------------------
	clear_input_buffer();
	printf("请输入诊断结果：\n");
	fgets(current->diagnosis, sizeof(current->diagnosis), stdin);
	current->diagnosis[strcspn(current->diagnosis, "\n")] = 0;
	// -------------------- 6. 录入治疗计划 --------------------
	strcpy(current->physicalExam,"医学检查无需录入治疗计划");
	// -------------------- 7. 录入处方 --------------------
	strcpy(current->prescription,"为开具任何药品");
	strcpy(current->record_of_inhospital,"空");
	
	
	
	// ==================== 确认机制 ====================
	// 显示录入信息供医生确认，确保不会误录
	printf("\n========== 诊疗信息确认 ==========\n");
	printf("主诉：%s\n", current->chiefComplaint);
	printf("现病史：%s\n", current->presentIllness);
	printf("体格检查：%s\n", current->physicalExam);
	printf("诊断结果：%s\n", current->diagnosis);
	printf("检查项目：%s\n", current->labTests);
	printf("治疗计划：%s\n", current->treatmentPlan);
	printf("处方：%s\n", current->prescription);
	printf("----------------------------------\n");
	printf("费用明细：\n");
	printf("检查费用：%.2f 元\n", current->cost);
	printf("==================================\n");
	
	printf("确认保存诊疗信息？(y/n)：");
	char confirm;
	while(scanf("%c", &confirm)!=1||(confirm!='y'&&confirm!='Y'&&confirm!='n'&&confirm!='N')){
		printf("请输入正确字母：(y/n)\n");
	}
	strcpy(current->status,"已完成");
	clear_input_buffer();
	if(confirm == 'y' || confirm == 'Y') {
		printf(" 诊疗完成！\n");
		// 记录结束时间
		current->consultTime_end = get_current_time();
		printf("诊疗记录已保存，结束时间：%d-%02d-%02d %02d:%02d\n",
			   current->consultTime_end.year, current->consultTime_end.month,
			   current->consultTime_end.day, current->consultTime_end.hour,
			   current->consultTime_end.minute);
	} else {
		printf("已取消保存，诊疗信息未录入\n");
	}
}


/* ==================== 病历修改功能 ==================== */

void amend_consultation(Consultation **head_C0, Medicine **head_M0,
						char *old_recordID, char *doctorID) {
	Consultation *head_C = *head_C0;
	//Medicine *head_M = *head_M0;
	// ==================== 1. 找到原记录 ====================
	Consultation *old_record = head_C;
	while(old_record != NULL) {
		if(strcmp(old_record->recordID, old_recordID) == 0) {
			break;
		}
		old_record = old_record->next;
	}
	
	if(old_record == NULL) {
		printf("未找到指定诊疗记录！\n");
		return;
	}
	
	// ==================== 2. 检查状态是否允许修改 ====================
	// 只有完成或住院状态的记录可以修改
	if(strcmp(old_record->status, "已完成") != 0 &&
	   strcmp(old_record->status, "已住院") != 0) {
		printf(" 该诊疗记录状态为【%s】，无法修改！\n", old_record->status);
		printf("  只有【已完成】和【已住院】状态的记录可以修改\n");
		return;
	}
	
	// ==================== 3. 显示原记录信息 ====================
	printf("\n========== 病历修改 ==========\n");
	printf("原记录信息：\n");
	printf("挂号单号：%s\n", old_record->recordID);
	printf("患者：%s\n", old_record->patientNAME);
	printf("就诊时间：%d-%02d-%02d\n",
		   old_record->consultTime_start.year,
		   old_record->consultTime_start.month,
		   old_record->consultTime_start.day);
	printf("诊断：%s\n", old_record->diagnosis);
	printf("处方：%s\n", old_record->prescription);
	printf("状态：%s\n", old_record->status);
	printf("===============================\n");
	
	printf("确认修改此病历？(y/n)：");
	char confirm;
	scanf("%c", &confirm);
	clear_input_buffer();
	
	if(confirm != 'y' && confirm != 'Y') {
		printf(" 已取消修改\n");
		return;
	}
	
	// ==================== 4. 标记原记录为已撤销 ====================
	strcpy(old_record->status, "已撤销");
	printf("原记录已标记为【已撤销】\n");
	
	// ==================== 5. 创建新记录 ====================
	Consultation *new_record = (Consultation*)malloc(sizeof(Consultation));
	if(new_record == NULL) {
		printf(" 内存分配失败！\n");
		return;
	}
	
	// 生成新记录ID（在原ID后加"_R"后缀，表示Revised）
	sprintf(new_record->recordID, "%s_R", old_record->recordID);
	strcpy(new_record->doctorID, old_record->doctorID);
	strcpy(new_record->patientID, old_record->patientID);
	strcpy(new_record->doctorNAME, old_record->doctorNAME);
	strcpy(new_record->patientNAME, old_record->patientNAME);
	strcpy(new_record->department, old_record->department);
	new_record->consultTime_start = get_current_time();  // 修改时间使用当前时间
	
	// ==================== 6. 逐项录入新信息 ====================
	// 每项显示原值，留空则使用原值
	printf("\n========== 录入新诊疗信息 ==========\n");
	printf("留空则使用原值（即回车）\n");
	
	printf("请输入主诉（原：%s）：\n", old_record->chiefComplaint);
	fgets(new_record->chiefComplaint, sizeof(new_record->chiefComplaint), stdin);
	new_record->chiefComplaint[strcspn(new_record->chiefComplaint, "\n")] = 0;
	if(strlen(new_record->chiefComplaint) == 0) {
		strcpy(new_record->chiefComplaint, old_record->chiefComplaint);
	}
	
	printf("请输入现病史（原：%s）：\n", old_record->presentIllness);
	fgets(new_record->presentIllness, sizeof(new_record->presentIllness), stdin);
	new_record->presentIllness[strcspn(new_record->presentIllness, "\n")] = 0;
	if(strlen(new_record->presentIllness) == 0) {
		strcpy(new_record->presentIllness, old_record->presentIllness);
	}
	
	printf("请输入体格检查（原：%s）：\n", old_record->physicalExam);
	fgets(new_record->physicalExam, sizeof(new_record->physicalExam), stdin);
	new_record->physicalExam[strcspn(new_record->physicalExam, "\n")] = 0;
	if(strlen(new_record->physicalExam) == 0) {
		strcpy(new_record->physicalExam, old_record->physicalExam);
	}
	
	printf("请输入诊断结果（原：%s）：\n", old_record->diagnosis);
	fgets(new_record->diagnosis, sizeof(new_record->diagnosis), stdin);
	new_record->diagnosis[strcspn(new_record->diagnosis, "\n")] = 0;
	if(strlen(new_record->diagnosis) == 0) {
		strcpy(new_record->diagnosis, old_record->diagnosis);
	}
	
	printf("请输入建议检查项目（原：%s）：\n", old_record->labTests);
	fgets(new_record->labTests, sizeof(new_record->labTests), stdin);
	new_record->labTests[strcspn(new_record->labTests, "\n")] = 0;
	if(strlen(new_record->labTests) == 0) {
		strcpy(new_record->labTests, old_record->labTests);
	}
	
	printf("请输入治疗计划（原：%s）：\n", old_record->treatmentPlan);
	fgets(new_record->treatmentPlan, sizeof(new_record->treatmentPlan), stdin);
	new_record->treatmentPlan[strcspn(new_record->treatmentPlan, "\n")] = 0;
	if(strlen(new_record->treatmentPlan) == 0) {
		strcpy(new_record->treatmentPlan, old_record->treatmentPlan);
	}
	
	printf("请输入处方（原：%s）：\n", old_record->prescription);
	if(strlen(new_record->prescription) == 0) {//开处药方不变
		strcpy(new_record->prescription, old_record->prescription);
		new_record->cost=old_record->cost;
	}
	else {
		clear_input_buffer();
		input_prescription_interactive(new_record, head_M0);
	}
	
	
	//ok啊这个也是直接置空了住院记录这里
	strcpy(new_record->record_of_inhospital, "空");	
	// ==================== 7. 重新计算费用 ====================
	float medicine_cost = new_record->cost;
	new_record->cost = medicine_cost + 20.0;
	//因为诊疗记录撤销前，这个病人已经拿药治疗了，这个时候就不需要再考虑回复撤销前药品的库存问题了
	
	
	// ==================== 8. 设置状态 ====================
	// 询问住院状态（如果原记录是已住院，默认保持已住院）
	if(strcmp(old_record->status, "已住院") == 0) {
		strcpy(new_record->status, "已住院");
	} else {
		printf("患者是否需要住院？(y/n)：");
		char need_hospital;
		scanf("%c", &need_hospital);
		clear_input_buffer();
		
		if(need_hospital == 'y' || need_hospital == 'Y') {
			strcpy(new_record->status, "已住院");
		} else {
			strcpy(new_record->status, "已完成");
		}
	}
	
	new_record->consultTime_end = get_current_time();
	
	// ==================== 9. 头插法加入链表 ====================
	new_record->next = head_C;
	*head_C0 = new_record;
	
	printf("\n 病历修改完成！\n");
	printf("原挂号单号：%s → 已撤销\n", old_record->recordID);
	printf("新挂号单号：%s\n", new_record->recordID);
	printf("新诊断：%s\n", new_record->diagnosis);
	printf("新处方：%s\n", new_record->prescription);
	printf("新费用：%.2f 元\n", new_record->cost);
}

/* ==================== 辅助查询函数 ==================== */

void update_consult_status(Consultation *head_C, char *patientID, char *status) {
	Consultation *c = head_C;
	while(c != NULL) {
		if(strcmp(c->patientID, patientID) == 0) {
			strcpy(c->status, status);
		}
		c = c->next;
	}
}



//截止到医生退出系统的时间，一共看了多少病人
int today_doctor_count_all(Consultation *head_C, char *DoctorID,DateTime today){
	int count=0;
	Consultation *curr=head_C;
	while(curr != NULL)
	{
		if( strcmp(curr->doctorID,DoctorID) == 0 &&//是否是该医生的诊疗记录
		   curr->consultTime_start.year == today.year &&
		   curr->consultTime_start.month == today.month &&
		   curr->consultTime_start.day == today.day &&//是否是今天的诊疗记录
		   strcmp(curr->status,"已撤销") != 0)//是否已撤消
		{
			count++;
			
		}
		curr=curr->next;
	}
	return count;
}

/*=========================主函数===============================*/

void doctor_system(char *DoctorID,Doctor **head_D0,Patient **head_P0,Nurse **head_N0,Medicine **head_M0,Bed **head_B0,Consultation **head_C0,ExaminationItem *red,ExaminationItem *lab)
{
	Doctor *head_D=*head_D0;
	Patient *head_P=*head_P0;
	Consultation *head_C=*head_C0;

	
	//查找进入系统的医生信息
	Doctor *current_doctor=find_doctor(DoctorID,head_D);
	
	if(current_doctor == NULL)
	{
		printf("医生信息不存在！\n");//可以有但是这种状况基本不存在
		return;
	}	
	
	// 显示欢迎信息
	printf("\n========================================\n");
	printf("  欢迎，%s 医生\n", current_doctor->name);
	printf("  科室：%s | 职称：%s\n", current_doctor->department, current_doctor->job_title);
	printf("========================================\n");
	
	DateTime today = get_current_time();
	int time_period;
	if(today.hour>12) time_period=2;
	else time_period=1;
	// 检查是否值班，如不值班给出温馨提示
	if(!doctor_on_duty(current_doctor, today,time_period)) {
		printf(" 温馨提示：您今日不值班，但仍可使用系统功能\n");
	}
	printf("科室名称: [%s]\n", current_doctor->department);
	if(strcmp(current_doctor->department,"影像科")==0||strcmp(current_doctor->department,"医学检验科")==0){
		int choice;
		while(1) {
			// ==================== 显示主菜单 ====================
			printf("\n========== 医生工作站 ==========\n");
			printf("1. 叫号（查看候诊患者）\n");
			printf("2. 录入检查项目\n");
			printf("3. 查看今日患者列表\n");
			printf("0. 退出医生系统\n");
			printf("================================\n");
			printf("请输入操作选项：");
			
			// 输入校验
			if(scanf("%d", &choice) != 1) {
				clear_input_buffer();
				printf(" 输入无效，请重新选择\n");
				continue;
			}
			clear_input_buffer();
			switch(choice) {
				
				case 1: {
				// ==================== 叫号 ====================
				// 功能：按挂号时间顺序叫号，显示患者信息和历史病历，这个自动把最近的病人的时间改成看诊中，就算是开始看诊了    然后就直接返回while循环然后让患者开始输入诊断结果ok
				reading_waiting_info_v2(head_C0, head_P0,
										DoctorID);	
				break;
			}
				case 2: {//美其名曰叫做我们这个系统，既能完成患者排队然后一个一个进，进来就直接告诉医生自己的病例号然后看诊，或者就是医生自己叫号，人都在外边休息室等着
					// ==================== 录入诊疗信息 ====================
					// 功能：录入主诉、诊断、处方等，自动计算费用
					printf("\n========== 录入诊疗信息 ==========\n");
					printf("请输入患者病历号：");
					char patientID[20];
					fgets(patientID, sizeof(patientID), stdin);
					patientID[strcspn(patientID, "\n")] = 0;
					
					// 3.1 检查是否有就诊中的记录
					Consultation *c = head_C;
					bool has_active = false;
					while(c != NULL) {
						if(strcmp(c->doctorID, DoctorID) == 0 &&
						   strcmp(c->patientID, patientID) == 0 &&
						   strcmp(c->status, "就诊中") == 0) {
							has_active = true;
							break;
						}
						c = c->next;
					}
					
					// 3.2 如果没有就诊中但有候诊记录，自动切换为就诊中
					if(!has_active) 
					{
						c = head_C;
						while(c != NULL) {
							if(strcmp(c->doctorID, DoctorID) == 0 &&
							   strcmp(c->patientID, patientID) == 0 &&
							   strcmp(c->status, "候诊") == 0) {
								strcpy(c->status, "就诊中");
								has_active = true;
								printf("已将患者状态从【候诊】更新为【就诊中】\n");
								break;
							}
							c = c->next;
						}
					}
					
					if(!has_active) {
						printf(" 该患者不在就诊列表中！请先挂号或叫号\n");
						break;
					}
					
					// 3.3 执行诊疗信息录入
					input_consultation_info_examine(head_C0,head_M0,head_B0,head_N0,
													head_P0,head_D0,
													current_doctor->staff_id,patientID,red,lab);
					
					break;
				}
				case 3: {
					// ==================== 查看今日患者列表 ====================
					view_my_patients(head_C, DoctorID);
					break;
				}
			case 0:
				// 退出医生系统
				printf("正在退出医生系统...\n");
				printf("今日已接诊患者数：%d\n", today_doctor_count_all(head_C, DoctorID, today));
				return;
			default:
				printf(" 无效选项，请重新选择\n");
			}//很好的思路无效选项也在switch里处理了
		}//这里利用while循环使医生能进行多种操作
	}
	else{
		int choice;
		while(1) {
			// ==================== 显示主菜单 ====================
			printf("\n========== 医生工作站 ==========\n");
			printf("1. 叫号（查看候诊患者）\n");
			printf("2. 录入诊疗信息\n");
			printf("3. 查看今日患者列表\n");
			printf("4. 修改病历\n");
			printf("5. 查看患者历史病历\n");
			printf("0. 退出医生系统\n");
			printf("================================\n");
			printf("请输入操作选项：");
			
			// 输入校验
			if(scanf("%d", &choice) != 1) {
				clear_input_buffer();
				printf(" 输入无效，请重新选择\n");
				continue;
			}
			clear_input_buffer();
			switch(choice) {
				
				case 1: {
				// ==================== 叫号 ====================
				// 功能：按挂号时间顺序叫号，显示患者信息和历史病历，这个自动把最近的病人的时间改成看诊中，就算是开始看诊了    然后就直接返回while循环然后让患者开始输入诊断结果ok
				reading_waiting_info_v2(head_C0, head_P0,
										DoctorID);	
				break;
			}
				case 2: {//美其名曰叫做我们这个系统，既能完成患者排队然后一个一个进，进来就直接告诉医生自己的病例号然后看诊，或者就是医生自己叫号，人都在外边休息室等着
					// ==================== 录入诊疗信息 ====================
					// 功能：录入主诉、诊断、处方等，自动计算费用
					printf("\n========== 录入诊疗信息 ==========\n");
					printf("请输入患者病历号：");
					char patientID[20];
					fgets(patientID, sizeof(patientID), stdin);
					patientID[strcspn(patientID, "\n")] = 0;
					
					// 3.1 检查是否有就诊中的记录
					Consultation *c = head_C;
					bool has_active = false;
					while(c != NULL) {
						if(strcmp(c->doctorID, DoctorID) == 0 &&
						   strcmp(c->patientID, patientID) == 0 &&
						   strcmp(c->status, "就诊中") == 0) {
							has_active = true;
							break;
						}
						c = c->next;
					}
					
					// 3.2 如果没有就诊中但有候诊记录，自动切换为就诊中
					if(!has_active) 
					{
						c = head_C;
						while(c != NULL) {
							if(strcmp(c->doctorID, DoctorID) == 0 &&
							   strcmp(c->patientID, patientID) == 0 &&
							   strcmp(c->status, "候诊") == 0) {
								strcpy(c->status, "就诊中");
								has_active = true;
								printf("已将患者状态从【候诊】更新为【就诊中】\n");
								break;
							}
							c = c->next;
						}
					}
					
					if(!has_active) {
						printf(" 该患者不在就诊列表中！请先挂号或叫号\n");
						break;
					}
					
					// 3.3 执行诊疗信息录入
					input_consultation_info(head_C0,head_M0,head_B0,head_N0,
											head_P0,head_D0,
											current_doctor->staff_id,patientID);
					
					break;
				}
				case 3: {
					// ==================== 查看今日患者列表 ====================
					view_my_patients(head_C, DoctorID);
					break;
				}
				case 4: {
					// ==================== 修改病历 ====================
					// 功能：标记原记录已撤销，新建正确记录
					printf("\n========== 修改病历 ==========\n");
					printf("请输入要修改的挂号单号：");
					char recordID[30];
					fgets(recordID, sizeof(recordID), stdin);
					recordID[strcspn(recordID, "\n")] = 0;
					
					amend_consultation(head_C0, head_M0, recordID, DoctorID);
					break;
				}
				case 5: {
					// ==================== 查看患者历史病历 ====================
					// 功能：查看患者的既往就诊记录，辅助诊断
					printf("\n========== 查看历史病历 ==========\n");
					printf("请输入患者病历号：");
					char patientID[20];
					fgets(patientID, sizeof(patientID), stdin);
					patientID[strcspn(patientID, "\n")] = 0;
					
					Patient *patient = find_patient(patientID, head_P);
					if(patient == NULL) {
						printf(" 患者不存在！\n");
						break;
					}
					
					printf("\n患者：%s（%s，%d岁）\n", patient->name, patient->gender, patient->age);
					printf("联系电话：%s\n", patient->phonenumber);
					printf("\n========== 历史就诊记录 ==========\n");
					
					Consultation *history = head_C;
					int count = 0;
					while(history != NULL) {
						if(strcmp(history->patientID, patientID) == 0) {
							count++;
							printf("\n--- 记录 %d ---\n", count);
							printf("挂号单号：%s\n", history->recordID);
							printf("就诊时间：%d-%02d-%02d %02d:%02d\n",
								   history->consultTime_start.year,
								   history->consultTime_start.month,
								   history->consultTime_start.day,
								   history->consultTime_start.hour,
								   history->consultTime_start.minute);
							printf("就诊医生：%s\n", history->doctorNAME);
							printf("主诉：%s\n", history->chiefComplaint);
							printf("诊断：%s\n", history->diagnosis);
							printf("处方：%s\n", history->prescription);
							printf("费用：%.2f\n", history->cost);
							printf("状态：%s\n", history->status);
						}
						history = history->next;
					}
					if(count == 0) {
						printf("无历史就诊记录\n");
					} else {
						printf("\n共 %d 条就诊记录\n", count);
					}
					printf("================================\n");
					break;
				}
			case 0:
				// 退出医生系统
				printf("正在退出医生系统...\n");
				printf("今日已接诊患者数：%d\n", today_doctor_count_all(head_C, DoctorID, today));
				return;
			default:
				printf(" 无效选项，请重新选择\n");
			}//很好的思路无效选项也在switch里处理了
		}//这里利用while循环使医生能进行多种操作
	}
	
}


