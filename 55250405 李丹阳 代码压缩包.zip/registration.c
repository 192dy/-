#include "HMS.h"
#include "Doctor.h"
#include "Patient.h"
#include "Administrator.h"
#include "Nurse.h"
#include"widely_used.h"
#include "F4.h"
#include"registration.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>


/*---------- 科室常量 ----------*/
static const char* DEPARTMENT_NAMES[] = {
	"普通内科", "骨科", "妇产科", "儿科",
	"急诊科", "影像科", "医学检验科"
};
#define DEPT_COUNT 7

/*---------- 静态计数器（实际应用应持久化） ----------*/
//static int g_daily_sequence = 0;
static int g_current_tracking_date = 0;

/*============================================================
日期有效性检查
============================================================*/


bool is_date_bookable_online(DateTime today, DateTime target_date) {
	int diff = days_between(today, target_date);
	// 线上：提前1-7天（不能当天，不能提前超过7天）
	return (diff >= 1 && diff <= 7);
}

bool is_date_bookable_offline(DateTime today, DateTime target_date) {
	int diff = days_between(today, target_date);
	// 线下：仅限当天
	return (diff == 0);
}

/*============================================================
模糊时段系统
============================================================*/

FuzzyTimeSlot precise_to_fuzzy(TimeSlot slot, int queue_position) {
	if (slot == TIME_SLOT_MORNING) {
		// 上午30人，前15人前半段，后15人后半段
		return (queue_position <= 15) ? FUZZY_MORNING_EARLY : FUZZY_MORNING_LATE;
	} else {
		// 下午30人，前15人前半段，后15人后半段
		return (queue_position <= 15) ? FUZZY_AFTERNOON_EARLY : FUZZY_AFTERNOON_LATE;
	}
}

const char* fuzzy_slot_description(FuzzyTimeSlot slot) {
	switch (slot) {
		case FUZZY_MORNING_EARLY:    return "上午较早时段（约08:00-09:30）";
		case FUZZY_MORNING_LATE:     return "上午较晚时段（约09:30-11:30）";
		case FUZZY_AFTERNOON_EARLY:  return "下午较早时段（约13:30-15:00）";
		case FUZZY_AFTERNOON_LATE:   return "下午较晚时段（约15:00-17:30）";
		default:                      return "就诊当日留意叫号";
	}
}

/*============================================================
核心排队逻辑（优先级队列）
============================================================*/

// 从诊疗记录推断渠道类型（通过recordID前缀或扩展字段）
// 新设计中：线上预约单号以"A"结尾，线下以"W"结尾
static BookingChannel infer_channel_from_record(Consultation *record) {
	// 通过单号最后一位判断：A=appointment预约, W=walk-in现场
	int len = strlen(record->recordID);
	if (len > 0 && record->recordID[len - 1] == 'A') {
		return CHANNEL_ONLINE;
	}
	return CHANNEL_OFFLINE;
}

// 在记录创建时标记渠道（通过单号后缀）
static void mark_record_channel(char *recordID, BookingChannel channel) {
	int len = strlen(recordID);
	// 替换最后一位为渠道标记
	if (len > 0) {
		recordID[len - 1] = (channel == CHANNEL_ONLINE) ? 'A' : 'W';
	}
}

QueueInfo calculate_queue_info(
							   Consultation *head_C,
							   char *doctorID,
							   DateTime target_date,
							   TimeSlot time_slot,
							   BookingChannel new_channel
							   ) {
	QueueInfo info = {0, 0, 0, FUZZY_UNKNOWN, 
	(new_channel == CHANNEL_ONLINE) ? PRIORITY_APPOINTMENT : PRIORITY_WALK_IN,
	""};
	
	int appointment_count = 0;  // 预约人数
	int walkin_count = 0;       // 现场人数
	
	Consultation *c = head_C;
	while (c != NULL) {
		// 匹配同医生、同日期、同时段、非撤销
		if (strcmp(c->doctorID, doctorID) == 0 &&
			strcmp(c->status, "已撤销") != 0 &&
			c->consultTime_start.year == target_date.year &&
			c->consultTime_start.month == target_date.month &&
			c->consultTime_start.day == target_date.day) {
			
			// 判断时段
			TimeSlot record_slot;
			int hour = c->consultTime_start.hour;
			if (hour >= 8 && hour < 12) {
				record_slot = TIME_SLOT_MORNING;
			} else if (hour >= 13 && hour < 18) {
				record_slot = TIME_SLOT_AFTERNOON;
			} else {
				c = c->next;
				continue;
			}
			
			if (record_slot == time_slot) {
				BookingChannel ch = infer_channel_from_record(c);
				if (ch == CHANNEL_ONLINE) {
					appointment_count++;
				} else {
					walkin_count++;
				}
			}
		}
		c = c->next;
	}
	
	// 计算位置
	if (new_channel == CHANNEL_ONLINE) {
		// 预约患者：排在所有预约之后，现场之前
		info.appointment_queue_pos = appointment_count + 1;
		info.total_queue_pos = info.appointment_queue_pos;
	} else {
		// 现场患者：排在所有预约和所有现场之后
		info.walkin_queue_pos = walkin_count + 1;
		info.total_queue_pos = appointment_count + info.walkin_queue_pos;
	}
	
	// 确定模糊时段
	info.fuzzy_slot = precise_to_fuzzy(time_slot, info.total_queue_pos);
	info.fuzzy_desc = fuzzy_slot_description(info.fuzzy_slot);
	
	return info;
}

/*============================================================
限号检查（沿用之前逻辑，增加渠道检查）
============================================================*/



CheckResult check_booking_quota(
									   Consultation *head_C,
									   Doctor *doctor,
									   char *patientID,
									   DateTime today,
									   DateTime target_date,
									   TimeSlot time_slot,
									   BookingChannel channel
									   ) {
	// 0. 日期有效性检查
	if (channel == CHANNEL_ONLINE) {
		if (!is_date_bookable_online(today, target_date)) {
			int diff = days_between(today, target_date);
			if (diff < 1) {
				printf("  线上预约不支持当天挂号，请到医院现场挂号。\n");
			} else if (diff > 7) {
				printf("  线上最多提前7天预约，请选择更近的日期。\n");
			}
			return CHECK_FAIL_DATE_INVALID;
		}
	} else {
		if (!is_date_bookable_offline(today, target_date)) {
			printf("  现场挂号仅限当天，不支持预约其他日期。\n");
			return CHECK_FAIL_DATE_INVALID;
		}
	}
	
	// 1-5. 原有检查逻辑
	// ...（全院400、医生30、患者5、科室1、医生在岗）
	// 1. 全院总号源
	int total_today = 0;
	Consultation *c = head_C;
	while (c != NULL) {
		if (c->consultTime_start.year == target_date.year &&
			c->consultTime_start.month == target_date.month &&
			c->consultTime_start.day == target_date.day &&
			strcmp(c->status, "已撤销") != 0) {
			total_today++;
		}
		c = c->next;
	}
	if (total_today >= 400) return CHECK_FAIL_TOTAL;
	
	// 2. 医生号源
	int doc_count = 0;
	c = head_C;
	while (c != NULL) {
		if (strcmp(c->doctorID, doctor->staff_id) == 0 &&
			strcmp(c->status, "已撤销") != 0 &&
			c->consultTime_start.year == target_date.year &&
			c->consultTime_start.month == target_date.month &&
			c->consultTime_start.day == target_date.day) {
			int h = c->consultTime_start.hour;
			if ((time_slot == TIME_SLOT_MORNING && h >= 8 && h < 12) ||
				(time_slot == TIME_SLOT_AFTERNOON && h >= 13 && h < 18)) {
				doc_count++;
			}
		}
		c = c->next;
	}
	if (doc_count >= 30) return CHECK_FAIL_DOCTOR;
	
	// 3. 患者日限号
	int pat_count = 0;
	c = head_C;
	while (c != NULL) {
		if (strcmp(c->patientID, patientID) == 0 &&
			strcmp(c->status, "已撤销") != 0 &&
			c->consultTime_start.year == target_date.year &&
			c->consultTime_start.month == target_date.month &&
			c->consultTime_start.day == target_date.day) {
			pat_count++;
		}
		c = c->next;
	}
	if (pat_count >= 5) return CHECK_FAIL_PATIENT;
	
	// 4. 同科室重复
	c = head_C;
	while (c != NULL) {
		if (strcmp(c->patientID, patientID) == 0 &&
			strcmp(c->status, "已撤销") != 0 &&
			strcmp(c->department, doctor->department) == 0 &&
			c->consultTime_start.year == target_date.year &&
			c->consultTime_start.month == target_date.month &&
			c->consultTime_start.day == target_date.day) {
			return CHECK_FAIL_DEPT;
		}
		c = c->next;
	}
	
	// 5. 医生在岗
	int weekday = Get_current_day_of_the_week((date){target_date.year, target_date.month, target_date.day});
	int sched_idx = time_slot - 1;
	if (doctor->staff_status != 1 || 
		doctor->schedule[weekday][sched_idx] != 1) {
		return CHECK_FAIL_DOCTOR_OFF;
	}
	
	return CHECK_PASS;
}

/*============================================================
单号生成（带渠道标记）
============================================================*/

// 从已有记录中，找出该医生该日期当前最大序号，返回 +1
static int get_next_sequence(Consultation *head_C, char *doctorID, DateTime date) {
	int max_seq = 0;
	Consultation *c = head_C;
	
	// 构造前缀：YYYYMMDD + 医生ID，例如 "20260512D001"
	char prefix[50];
	sprintf(prefix, "%04d%02d%02d%s", date.year, date.month, date.day, doctorID);
	int prefix_len = strlen(prefix);
	
	while (c != NULL) {
		// 如果 recordID 以该前缀开头，说明是同医生同天的记录
		if (strncmp(c->recordID, prefix, prefix_len) == 0) {
			int seq = 0;
			// 提取前缀后面的3位数字
			if (sscanf(c->recordID + prefix_len, "%3d", &seq) == 1) {
				if (seq > max_seq) max_seq = seq;
			}
		}
		c = c->next;
	}
	return max_seq + 1;  // 在最大序号基础上 +1
}


static void generate_booking_id(DateTime date,  char *doctorID, 
								int seq, BookingChannel channel,
								char *out, size_t out_size) {
	// 格式：YYYYMMDD + 医生ID + 3位序号 + 1位渠道标记(A/W)
	char suffix = (channel == CHANNEL_ONLINE) ? 'A' : 'W';
	snprintf(out, out_size, "%04d%02d%02d%s%03d%c",
			 date.year, date.month, date.day, doctorID, seq, suffix);
}

/*============================================================
统一挂号执行
============================================================*/

bool execute_booking(
					 Doctor **head_D0,
					 Patient **head_P0,
					 Consultation **head_C0,
					 char *patientID,
					 char *doctorID,
					 char *dept_name,
					 DateTime target_date,
					 TimeSlot time_slot,
					 BookingChannel channel,
					 char *out_recordID,
					 size_t recordID_size
					 ) {
	DateTime today = get_current_time();
	
	// ---------- 验证患者 ----------
	Patient *patient = find_patient(patientID, *head_P0);
	if (!patient) {
		printf("  患者不存在！\n");
		return false;
	}
	
	// ---------- 验证医生 ----------
	Doctor *doctor = find_doctor(doctorID, *head_D0);
	if (!doctor) {
		printf("  医生不存在！\n");
		return false;
	}
	
	// ---------- 限号检查 ----------
	CheckResult check = check_booking_quota(*head_C0, doctor, patientID, today,
											target_date, time_slot, channel);
	switch (check) {
		case CHECK_FAIL_TOTAL:  printf("\n 挂号失败！！！今日号源已满。\n"); return false;
		case CHECK_FAIL_DOCTOR: printf("\n 挂号失败！！！该医生号源已满。\n"); return false;
		case CHECK_FAIL_PATIENT: printf("\n  挂号失败！！！您今日挂号数已达上限。\n"); return false;
		case CHECK_FAIL_DEPT:   printf("\n  挂号失败！！！同科室每日限挂1次。\n"); return false;
		case CHECK_FAIL_DOCTOR_OFF: printf("\n  挂号失败！！！医生该时段不值班。\n"); return false;
		case CHECK_FAIL_DATE_INVALID: return false;
		default: break;
	}
	
	// ---------- 计算排队信息 ----------
	QueueInfo qinfo = calculate_queue_info(*head_C0, doctorID, target_date, time_slot, channel);
	
	// ---------- 生成单号 ----------
	//g_daily_sequence++;
	// ---------- 生成单号 ----------
	int seq = get_next_sequence(*head_C0, doctorID, target_date);  // 实时计算
	char recordID[35];
	generate_booking_id(target_date, doctorID, seq, channel, recordID, sizeof(recordID));
	
	// ---------- 构建就诊时间（用于系统内部排序）----------
	DateTime visit_time = target_date;
	visit_time.minute = 0;
	visit_time.second = 0;
	if (time_slot == TIME_SLOT_MORNING) {
		visit_time.hour = 8;
	} else {
		visit_time.hour = 13;
		visit_time.minute = 30;
	}
	
	// ---------- 创建记录 ----------
	Consultation *rec = (Consultation*)malloc(sizeof(Consultation));
	if (!rec) {
		printf("  内存分配失败！\n");
		return false;
	}
	
	strcpy(rec->recordID, recordID);
	strcpy(rec->doctorID, doctorID);
	strcpy(rec->patientID, patientID);
	strcpy(rec->department, dept_name);
	strcpy(rec->doctorNAME, doctor->name);
	strcpy(rec->patientNAME, patient->name);
	rec->consultTime_start = visit_time;
	rec->consultTime_end = visit_time;
	strcpy(rec->chiefComplaint, "(空)");
	strcpy(rec->presentIllness, "(空)");
	strcpy(rec->physicalExam, "(空)");
	strcpy(rec->diagnosis, "(空)");
	strcpy(rec->labTests, "(空)");
	strcpy(rec->treatmentPlan, "(空)");
	strcpy(rec->prescription, "(空)");
	strcpy(rec->record_of_inhospital, "(空)");
	rec->cost = 0.0;
	strcpy(rec->status, "候诊");
	rec->next = NULL;
	
	// ---------- 插入链表 ----------
	rec->next = *head_C0;
	*head_C0 = rec;
	
	// ---------- 输出结果（模糊时间版）----------
	printf("\n+========== 挂号成功 ==========+\n");
	printf("| 挂号单号：%s\n", recordID);
	printf("| 就诊科室：%s\n", dept_name);
	printf("| 就诊医生：%s（%s）\n", doctor->name, doctor->job_title);
	printf("| 就诊日期：%d-%02d-%02d\n", target_date.year, target_date.month, target_date.day);
	printf("| 就诊时段：%s\n", (time_slot == TIME_SLOT_MORNING) ? "上午" : "下午");
	
	// 显示排队信息（带优先级说明）
	printf("|--------------------------------\n");
	if (channel == CHANNEL_ONLINE) {
		printf("| 您是【预约患者】，享有优先排队权\n");
		printf("| 预约排队序号：第 %d 位\n", qinfo.appointment_queue_pos);
	} else {
		printf("| 您是【现场挂号】\n");
		printf("| 现场排队序号：第 %d 位\n", qinfo.walkin_queue_pos);
		if (qinfo.appointment_queue_pos > 0) {
			printf("| 提示：您前面有预约患者优先就诊\n");
		}
	}
	printf("| 预估就诊：%s\n", qinfo.fuzzy_desc);
	printf("| 当前状态：候诊\n");
	printf("| 请提前15分钟到达医院候诊\n");
	printf("+================================+\n");
	
	if (out_recordID) {
		strncpy(out_recordID, recordID, recordID_size - 1);
		out_recordID[recordID_size - 1] = '\0';
	}
	return true;
}

/*============================================================
模糊时间显示
============================================================*/

void display_fuzzy_appointment_info(QueueInfo *info, TimeSlot slot) {
	printf("排队情况：");
	if (info->priority == PRIORITY_APPOINTMENT) {
		printf("预约队列第%d位\n", info->appointment_queue_pos);
	} else {
		printf("现场队列第%d位", info->walkin_queue_pos);
		if (info->appointment_queue_pos > 0) {
			printf("（前面有预约患者）");
		}
		printf("\n");
	}
	printf("预估就诊时间：%s\n", info->fuzzy_desc);
}

/*============================================================
日期选择（线上预约用）
============================================================*/

static void print_available_dates(DateTime today) {
	printf("\n========== 可预约日期（未来7天）==========\n");
	printf("0. 取消预约\n");
	
	const char* weekdays[] = {"", "周一", "周二", "周三", "周四", "周五", "周六","周日"};
	
	for (int i = 1; i <= 7; i++) {
		DateTime d = date_add_days(today, i);
		int wd = Get_current_day_of_the_week((date){d.year, d.month, d.day});
		printf("%d. %d-%02d-%02d %s  ", i, d.year, d.month, d.day, weekdays[wd]);
		
		// 标注上午/下午可约状态（简化：都显示可约）
		printf("[上午/下午可约]\n");
	}
	printf("=========================================\n");
}

bool select_appointment_date(DateTime today, DateTime *out_date, TimeSlot *out_slot) {
	// 显示可选日期
	print_available_dates(today);
	
	int choice;
	printf("请选择预约日期（1-7）：");
	while (scanf("%d", &choice) != 1 || choice < 0 || choice > 7) {
		clear_input_buffer();
		printf("请输入 0-7 之间的数字：");
	}
	clear_input_buffer();
	
	if (choice == 0) return false;
	
	*out_date = date_add_days(today, choice);
	
	// 选择时段
	printf("\n请选择就诊时段：\n");
	printf("1. 上午（08:00-11:30）\n");
	printf("2. 下午（13:30-17:30）\n");
	int slot_choice;
	while (scanf("%d", &slot_choice) != 1 || (slot_choice != 1 && slot_choice != 2)) {
		clear_input_buffer();
		printf("请输入 1（上午）或 2（下午）：");
	}
	clear_input_buffer();
	*out_slot = (slot_choice == 1) ? TIME_SLOT_MORNING : TIME_SLOT_AFTERNOON;
	
	return true;
}

/*============================================================
线上预约流程（患者端，提前1-7天）
============================================================*/

static bool select_department(char *dept_buf, size_t buf_size) {
	printf("\n========== 科室列表 ==========\n");
	for (int i = 0; i < DEPT_COUNT; i++) {
		printf("%d. %s\n", i + 1, DEPARTMENT_NAMES[i]);
	}
	printf("0. 取消\n");
	printf("=============================\n");
	
	int choice;
	printf("请选择科室：");
	while (scanf("%d", &choice) != 1 || choice < 0 || choice > DEPT_COUNT) {
		clear_input_buffer();
		printf("请输入 0-%d：", DEPT_COUNT);
	}
	clear_input_buffer();
	
	if (choice == 0) return false;
	strncpy(dept_buf, DEPARTMENT_NAMES[choice - 1], buf_size - 1);
	dept_buf[buf_size - 1] = '\0';
	return true;
}

static void display_doctors_available(Doctor *head_D, Consultation *head_C,
									  char *dept, DateTime date_0, TimeSlot slot) {
	printf("\n========== %s - %s 可预约医生 ==========\n",
		   dept, (slot == TIME_SLOT_MORNING) ? "上午" : "下午");
	printf("%-12s %-10s %-10s %-10s\n", "工号", "姓名", "职称", "剩余号源");
	printf("-------------------------------------------\n");
	
	int found = 0;
	Doctor *d = head_D;
	while (d) {
		if (strcmp(d->department, dept) == 0 && d->staff_status == 1) {
			int wd = Get_current_day_of_the_week((date){date_0.year, date_0.month, date_0.day});
			if (d->schedule[wd][slot - 1] == 1) {
				// 统计该医生该时段已约人数
				int booked = 0;
				Consultation *c = head_C;
				while (c) {
					if (strcmp(c->doctorID, d->staff_id) == 0 &&
						strcmp(c->status, "已撤销") != 0 &&
						c->consultTime_start.year == date_0.year &&
						c->consultTime_start.month == date_0.month &&
						c->consultTime_start.day == date_0.day) {
						int h = c->consultTime_start.hour;
						if ((slot == TIME_SLOT_MORNING && h >= 8 && h < 12) ||
							(slot == TIME_SLOT_AFTERNOON && h >= 13 && h < 18)) {
							booked++;
						}
					}
					c = c->next;
				}
				int remaining = 30 - booked;
				printf("%-12s %-10s %-10s %-10d\n", 
					   d->staff_id, d->name, d->job_title, remaining);
				found++;
			}
		}
		d = d->next;
	}
	
	if (!found) printf("  该时段暂无值班医生\n");
	printf("=========================================\n");
}

static Doctor* pick_doctor_interactive(Doctor *head_D, Consultation *head_C,
									   char *dept, DateTime date_0, TimeSlot slot) {
	char input[20];
	printf("请输入医生工号（0=返回）：");
	while (1) {
		if (fgets(input, sizeof(input), stdin) == NULL) {
			clear_input_buffer();
			continue;
		}
		input[strcspn(input, "\n")] = 0;
		if (strcmp(input, "0") == 0) return NULL;
		
		Doctor *doc = find_doctor(input, head_D);
		if (!doc) {
			printf("  医生不存在，请重新输入：");
			continue;
		}
		if (strcmp(doc->department, dept) != 0) {
			printf("  该医生不在%s，请重新输入：", dept);
			continue;
		}
		int wd = Get_current_day_of_the_week((date){date_0.year, date_0.month, date_0.day});
		if (doc->staff_status != 1 || doc->schedule[wd][slot - 1] != 1) {
			printf("  该医生该时段不可约，请重新输入：");
			continue;
		}
		return doc;
	}
}

void online_booking_flow(Doctor **head_D0, Patient **head_P0,
						 Consultation **head_C0, char *patientID) {
	printf("\n========== 线上预约挂号 ==========\n");
	
	DateTime today = get_current_time();
	
	// --- 选择日期和时段 ---
	DateTime target_date;
	TimeSlot target_slot;
	if (!select_appointment_date(today, &target_date, &target_slot)) {
		printf("已取消预约。\n");
		return;
	}
	
	// --- 选择科室 ---
	char dept[30];
	if (!select_department(dept, sizeof(dept))) {
		printf("已取消。\n");
		return;
	}
	
	// --- 显示医生 ---
	display_doctors_available(*head_D0, *head_C0, dept, target_date, target_slot);
	
	// --- 选择医生 ---
	Doctor *doc = pick_doctor_interactive(*head_D0, *head_C0, dept, target_date, target_slot);
	if (!doc) {
		printf("已取消。\n");
		return;
	}
	
	// --- 确认 ---
	printf("\n预约确认：\n");
	printf("  日期：%d-%02d-%02d %s\n", target_date.year, target_date.month, target_date.day,
		   (target_slot == TIME_SLOT_MORNING) ? "上午" : "下午");
	printf("  科室：%s\n", dept);
	printf("  医生：%s\n", doc->name);
	printf("确认预约？(y/n)：");
	char conf;
	scanf("%c", &conf);
	clear_input_buffer();
	if (conf != 'y' && conf != 'Y') {
		printf("已取消。\n");
		return;
	}
	
	// --- 执行 ---
	execute_booking(head_D0, head_P0, head_C0, patientID,
					doc->staff_id, dept, target_date, target_slot,
					CHANNEL_ONLINE, NULL, 0);
}

/*============================================================
线下挂号流程（护士台，仅当天）
============================================================*/

void offline_booking_flow(Doctor **head_D0, Patient **head_P0,
						  Consultation **head_C0, char *patientID,
						  bool is_walk_in) {
	printf("\n========== 现场挂号 ==========\n");
	
	DateTime today = get_current_time();
	
	// 自动确定时段
	TimeSlot slot;
	int mins = today.hour * 60 + today.minute;
	if (mins >= 480 && mins < 690) {         // 8:00-11:30
		slot = TIME_SLOT_MORNING;
	} else if (mins >= 810 && mins < 1050) {  // 13:30-17:30
		slot = TIME_SLOT_AFTERNOON;
	} else {
		printf("  当前不在挂号时段（上午8:00-11:30，下午13:30-17:30）\n");
		return;
	}
	
	// 选择科室
	char dept[30];
	if (!select_department(dept, sizeof(dept))) {
		printf("已取消。\n");
		return;
	}
	
	// 显示医生
	display_doctors_available(*head_D0, *head_C0, dept, today, slot);
	
	// 选择医生
	Doctor *doc = pick_doctor_interactive(*head_D0, *head_C0, dept, today, slot);
	if (!doc) {
		printf("已取消。\n");
		return;
	}
	
	// 执行
	execute_booking(head_D0, head_P0, head_C0, patientID,
					doc->staff_id, dept, today, slot,
					CHANNEL_OFFLINE, NULL, 0);
}



