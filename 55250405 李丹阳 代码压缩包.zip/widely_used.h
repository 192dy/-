#ifndef widely_used_H
#define widely_used_H
#include"HMS.h"

/*药品函数3：自动检查过期药品，去除对应的库存*/
//辅助函数（处理每单药品）
void check_signal_medicine_status(Medicine *M);
void automatic_check_medicine(Medicine *head_M);


int date_to_int(DateTime dt);

// 计算两个日期之间的天数差（简化版）
int days_between(DateTime a, DateTime b);

// 日期加法（返回新日期）
DateTime date_add_days(DateTime base, int days);

// 时间比较辅助函数：t1<t2返回负数，t1==t2返回0，t1>t2返回正数
int time_compare(DateTime t1, DateTime t2);


//1.清空缓冲区
void clear_input_buffer(void);

//=====基础信息查询接口===//
// 2.1
Patient* find_patient(char* patientID_0,Patient *head_P);
// 2.2
Doctor* find_doctor(char* doctorID,Doctor *head_D);
// 2.3
Nurse* find_nurse(char* nurseID,Nurse *head_N);
// 2.4
Administrator* find_administrator(char* AdministratorID,Administrator *head_A);
//2.5
ExaminationItem* find_by_code(ExaminationItem *head, const char *code);
//===============计算时间函数============//

//3.计算两个日期之间的天数
int days(DateTime time);

//4.1计算住院和出院之间的天数（含8.前后的判断）
int calculate_day(DateTime in,DateTime out);
//4.2 计算住院出院时间差天数
int get_days_between(DateTime start, DateTime end);   
//4.3  计算住院内的一段时间天数
int get_days_between_1(DateTime start, DateTime end);             



//5.比较两个时间段精确到秒若T1>=T2返回true；//要满足天数可以比较大小，或者天数相同时比当天已经度过的秒数就行 
bool constract_two_days(DateTime T1,DateTime T2);//比较两个时间段精确到秒若T1>=T2返回true；（精确到秒款）

//6.检查是否超过了现在的时间；（精确到秒款）
bool check_weather_surpuss_1(DateTime initial);

// 7. date转DateTime（默认时分秒为0）
DateTime date_to_datetime(date day, int hour, int minute, int second);

// 工具函数：将日期转换成 从公元0年开始的总天数（用于计算差值）
int date_to_days(int year, int month, int day);

// 8.辅助函数：得到date对应的星期几（逻辑不变，仅参数更清晰）
int Get_current_day_of_the_week(date day);

//9.获取系统当前时间，返回封装好的DateTime结构体
DateTime get_current_time(void);

//10.辅助函数，获取科室索引
int get_dept_index(const char*input_dept_names);

//11.上线就执行这段时间所有床位的扣费
void auto_deduct_bed_fee_for_all(Bed *head_B);

#endif
