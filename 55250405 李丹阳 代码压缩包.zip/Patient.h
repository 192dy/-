#ifndef Patient_H
#define Patient_H
#include"HMS.h"

static const char*dept_names[7]={"普通内科","骨科","妇产科","儿科","医学检验科","急诊科","影像科"};
//检验挂号限制







/*--------------构建病人系统------------------*/
void patient_system(char *PatientID,Doctor **head_D_0,Patient **head_P,Nurse **head_N,Medicine **head_M,Bed **head_B,Consultation **head_C);
void Register_on_site_system(Doctor **head_D_0,Patient **head_P,Nurse **head_N,Medicine **head_M,Bed **head_B,Consultation **head_C);

/*--------------线上挂号系统（患者自助）------------------*/
// 患者自助线上挂号（含时间限制：每晚19:00放次日号源，截止次日11:30）
void online_registration_system(Doctor **head_D0, Patient **head_P0, Consultation **head_C0, 
								char *patientID);




//辅助函数，获取科室索引
int get_dept_index(const char*input_dept_names);

//辅助函数，计算患者id的哈希值，用于检查当日挂号数相关
int hash_patient_id(const char*patientID);

//辅助函数，计算医生工号哈希值
int hash_doctor_id(const char*doctorID);

/*--------------患者信息管理------------------*/
void change_emergency_connection_information(Patient **head_P, char *patientID);  // 修改紧急联系人
void change_phonenumber(Patient **head_P, char *patientID);                        // 修改电话
void register_new_patient(Patient **head_P0, char *suggested_id);              // 注册新患者

/*----------------患者注册与管理------------------*/
//void generate_patient_id(char *out_patientID);               // 生成新的病历号

/*--------------患者自助查询------------------*/
void view_my_consultations(Consultation *head_C, char *patientID);                 // 查看诊疗记录
void view_my_hospitalization(Bed *head_B, char *patientID);                        // 查看住院信息

/*--------------辅助函数------------------*/
void search_patient_by_name(Patient *head_P, char *name, Patient **results, int *count);  // 按姓名搜索
void display_patient_info(Patient *patient);                                                 // 显示患者信息
void change_login_password(Patient **head_P0, char *patientID);                             // 修改密码

void change_emergency_connection_information(Patient **head_P,char *PatientID);//病人可以修改自己的紧急联系人相关信息
void change_phonenumber(Patient **head_P,char *PatientID);//患者修改自己的电话


int today_doctor_count(Consultation*head_C,char*doctor_id,DateTime today,int time_period);//检查某个医生在一段时间（上午/下午）的已挂号量；

bool line_registration_with_time(Doctor **head_D0, Patient **head_P0, Consultation **head_C0,
																 char *patientID, char *doctorID,char *dept_names,int time_period);//患者选定医生后时间段什么什么都确定了，然后开始检测患者选的这个医生能不能给他/她看病

int today_doctor_count(Consultation*head_C,char*doctor_id,DateTime today,int time_period);//统计医生一天接诊的数量



//辅助函数，计算患者id的哈希值，用于检查当日挂号数相关
int hash_patient_id(const char*patientID);



#endif
