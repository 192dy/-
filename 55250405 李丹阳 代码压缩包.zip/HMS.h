#ifndef HMS_H
#define HMS_H
#include<stdbool.h>

#define Patient_Volume 30

/*-------------------------------------------前期必要数据建构------------------------------------------------------------*/
/*-------------规定时间结构体精确到秒------------*/
typedef struct presise_time{
	int year;
	int month;
	int day;
	int hour;
	int minute;
	int second;
}DateTime;

extern DateTime current_dt;


/*----------出生日期结构体---------*/
typedef struct rough_date{
	int year;
	int month;
	int day;
}date;
/*
//操作日志结构体
typedef struct OperationLog {
char operator_id[20];      // 操作者工号（医生/护士/管理员）
char operator_name[20];    // 操作者姓名
char operator_role[10];     // 角色：医生/护士/管理员/患者
char operation_type[30];    // 操作类型：如"添加药品"、"修改医生职称"
char target_id[20];         // 被操作对象ID（如药品名、医生工号）
char details[200];          // 操作详情（如"将张三职称从医师改为主治医师"）
DateTime operate_time;      // 操作时间
struct OperationLog *next;
} OperationLog;*/


/*---------院长/行政管理人员结构体--------*/
typedef struct administrator_information{
	char name[40];
	char staff_id[20];
	char login_password[20];
	struct administrator_information * next;
}Administrator;
//辅助函数2：管理人员生成函数
Administrator *administrator_maker(char *name,
								   char *staff_id,
								   char *login_password,
								   Administrator *previous
								   );

/*------------构建医生结构体---------------*/
//规定：医生结构体，包含医生基本信息，和他的诊疗记录
typedef struct Doctor_information{
	char name[200];  //姓名
	int age;      //年龄
	char id_card_number[25];     //身份证号
	char gender[10];  //性别
	char phone_number[40];     //电话
	date birthday;   //出生日期
	char department[200];     //科室/部门
	char staff_id[20];        //工号
	char login_password[20];    //登录密码
	char job_title[30];     //职称
	int  staff_status;     //在职状态:1  在职   2  休假   3离职
	int schedule[8][3];    //值班表1-7依次代表周一到周日，抛弃schedul[0]便于后续代码的输出。一天分成三个班，早/下午/晚班用0-2依次代替,上不上1/0
	struct Doctor_information *next;       //链接指针
}Doctor;


/* ==================== 结构体定义 ==================== */

typedef struct ExaminationItem {
	int id;//项目序号
	int dept_id;//对应部门编码1：影像科 2：检验科
	char item_code[50];//项目编码
	char item_name[100];//项目名称
	double price;//单价
	char unit[20];//单位
	int status;//状态，是否可检查，均置为1
	struct ExaminationItem *next;
} ExaminationItem;



/*-------------构建护士结构体------------------*/
typedef struct Nurse_information{
	char name[40];  //姓名
	int age;      //年龄
	char id_card_number[25];     //身份证号
	char gender[10];  //性别
	char phone_number[20];     //电话
	date birthday;   //出生日期
	char department[40];     //科室/部门
	char staff_id[20];        //工号
	char login_password[20];    //登录密码
	char job_title[40];     //职称
	int responsible_number;    //负责最大病人人数
	int  staff_status;     //在职状态:1  在职   2  休假   3离职
	int schedule[8][3];    //值班表1-7依次代表周一到周日，抛弃schedul[0]便于后续代码的输出。一天分成三个班，早/下午/晚班用0-2依次代替
	struct Nurse_information *next;       //链接指针
}Nurse;

//辅助函数4：批量生成护士函数
Nurse *nurse_maker(
				   char *name,  //姓名
				   int age,      //年龄
				   char *id_card_number,     //身份证号
				   char *gender,  //性别
				   char *phone_number_0,
				   date birthday,   //出生日期
				   char *department,     //科室/部门
				   char *staff_id,        //工号
				   char *login_password,    //登录密码
				   char *job_title,     //职称
				   int responsible_number,//负责最大病人人数
				   int  staff_status,     //在职状态:1  在职   2  休假   3离职
				   int schedule[8][3],    //值班表1-7依次代表周一到周日，抛弃schedul[0]便于后续代码的输出。一天分成三个班，早/下午/晚班用0-2依次代替
				   struct Nurse_information *previous);       //链接指针

/*--------------构建病人结构体-------------*/
typedef struct Patient_information{
	char name[40];              //姓名
	int age;                    //年龄
	char id_card_number[45];     //身份证号
	char patientID[40];     //病历号（也具有唯一性）
	char login_password[40];    //登录密码
	char phonenumber[40];        //手机号码
	char gender[10];          //性别
	date birthday;         //出生日期
	char Emergency_contact[20];       //紧急联系人
	char Emergency_contact_phonenumber[40];     //紧急联系人电话
	struct Patient_information *next;         //指向下一个节点
}Patient;
/*辅助函数:5：*/
//批量生产患者信息函数
Patient *patient_maker(char *name_0,
					   int age_0,
					   char* id_card_number_0,
					   char* phonenumber_0,
					   char* patientID_0,
					   char* login_password,
					   char* gender_0,
					   date birthday_0,
					   char *Emergency_contact_0,
					   char *Emergency_contact_phonenumber_0,
					   Patient  *previous);


/*现在我感觉这个创维的结构体十分不合理，我要知道科室，医生，护士，我还要去分开房间类型，状态，可以构建一个链表用123表示房间序号比如1：VIP001，还要有一个来表示床序号,*/
/*-------------------构建住院结构体------------------*/
// 1.住院记录
typedef struct status_information{ 
	char patient_id[40];   // 病人ID
	char doctor_id[40];    // 主治医生ID (这里是业务发生时的指派)
	char nurse_id[40];
	DateTime check_in;
	DateTime check_out;
	float ya_cash;         //押金
	float cost_cash;        //已住院花费！！！廖梓婷注意
	int days;     //拟住院天数
	DateTime last_deduct_day;  // 最后一次自动扣费的日期
	struct status_information *next;
}Admission_information;

// 1. 床位结构体（只描述物理属性）
typedef struct bed_information{
	char department_name[40]; // 所属科室：如 "内科", "骨科" (非常重要，用于筛选)
	char bed_id[40];       // 住的床位ID
	int type;//1:VIP病房  2：二人间 3：三人间
	char Ward_number[40];     //eg.病房号V001,V002
	int  order;            // 床位序号：如 1, 2, 3,4....
	float daily_cost;         //每日住院费用
	Admission_information *status;           // 状态：,否则就往status里输入对应的信息；也用来存储所有（若这个床位是空的就让status=NULL，这种情况就极少，只有在建立新床位的时候才可以）
	struct bed_information *next; //指针指向下一节点
} Bed;

/*辅助函数7*/
//批量生产床位
Bed *bed_all_maker(
//状态数据
char *department_name_0, // 所属科室：如 "内科", "骨科" (非常重要，用于筛选)
char *bed_id_0,       // 住的床位ID
int type_0,//1:VIP病房  2：二人间 3：三人间
char *Ward_number_0,     //eg.病房号V001,V002
int  order,            // 床位序号：如 1, 2, 3,4....
float daily_cost,       //每日花费；
Bed *previous);
//对有病人住的床位进行构建
void bed_excat_maker(char *patient_id_0,   // 病人ID
					 char *doctor_id_0,    // 主治医生ID (这里是业务发生时的指派)
					 char *nurse_id_0,
					 DateTime check_in_0,
					 DateTime check_out_0,
					 float ya_cash_0,
					 float cost_cash,        //已住院花费！！！廖梓婷注意
					 int days,   //拟住院天数
					 DateTime last_deduct_day,  // 最后一次自动扣费的日期
					 //检索用的数据
					 char *bed_id_0,
					 Bed *head_B_0
					 );

/*------规定：诊疗结构体存储所有诊疗信息------*/
typedef struct Medical_Record{
	char department[200];   //对应科室
	char recordID[100];   //唯一挂号单号/记录ID
	char doctorID[50];   //存储医生的工号
	char patientID[50];   //存储病人的病历号
	
	//冗余存储姓名，方便打印时不用再去遍历链表查名字（空间换时间）
	char doctorNAME[50];  //医生姓名
	char patientNAME[50]; //患者姓名
	
	DateTime consultTime_start;   //就诊开始时间
	DateTime consultTime_end;    //就诊结束时间
	
	//1.病人自述
	//对应“主诉”和“现病史”，记录病人说的话
	char chiefComplaint[400];//主诉：比如“头痛三天”
	char presentIllness[500];//现病史：详细描述发病过程
	
	//2.医生判断
	//对应的“体格检查”和“诊断”
	char physicalExam[400];   //查体：比如“咽部充血，体温38度”
	char diagnosis[200];     //诊断结果：比如“急性扁桃体炎”
	
	//3.做的检查
	//对应的“辅助检查”
	char labTests[200];    //检验检查：比如“血常规，胸片”
	//注意：这里只存检查项目名称，不含检查结果的报告单
	
	//4.开的处方
	//对应“治疗意见”
	char treatmentPlan[300];   //治疗计划：比如“建议休息，多喝水”
	char prescription[300];   //具体处方药：比如“阿莫西林 0.5g tid”
	
	char record_of_inhospital[1024];//如果住院的话在出院时形成住院详情；
	
	float cost;      //总花费
	char status[20];    //就诊状态：候诊，完成，已撤销，已住院
	
	struct Medical_Record *next; 
}Consultation;

/*辅助函数1：*/
//批量生产诊疗记录
Consultation *consultation_maker(char *recordID_0,   //唯一挂号单号/记录ID
								 char *doctorID_0,   //存储医生的工号
								 char *patientID_0,   //存储病人的病历号
								 char *department_0,
								 //冗余存储姓名，方便打印时不用再去遍历链表查名字（空间换时间）
								 char *doctorNAME_0,  //医生姓名
								 char *patientNAME_0, //患者姓名
								 
								 DateTime consultTime_start_0,   //就诊开始时间
								 DateTime consultTime_end_0,    //就诊结束时间
								 
								 //1.病人自述
								 //对应“主诉”和“现病史”，记录病人说的话
								 char *chiefComplaint_0,//主诉：比如“头痛三天”
								 char *presentIllness_0,//现病史：详细描述发病过程
								 
								 //2.医生判断
								 //对应的“体格检查”和“诊断”
								 char *physicalExam_0,   //查体：比如“咽部充血，体温38度”
								 char *diagnosis_0,     //诊断结果：比如“急性扁桃体炎”
								 
								 //3.做的检查
								 //对应的“辅助检查”
								 char *labTests_0,    //检验检查：比如“血常规，胸片”
								 //注意：这里只存检查项目名称，不含检查结果的报告单
								 
								 //4.开的处方
								 //对应“治疗意见”
								 char *treatmentPlan_0,   //治疗计划：比如“建议休息，多喝水”
								 char *prescription_0,   //具体处方药：比如“阿莫西林 0.5g tid”
								 
								 
								 float cost,      //总花费
								 char *status_0,    //就诊状态：候诊，完成，已撤销，已住院,已出院
								 
								 Consultation *previous);

/*----------------构建药品结构体----------------------*/


// 重命名并明确语义：药品出入库记录
typedef struct medicine_io_record{
	char operator_id[50];  // 操作人ID（管理员/药师工号）
	DateTime operate_time; // 操作时间
	DateTime deadline_time;  // 药品过期时间（入库时必填）
	int io_type;           // 1-入库 2-出库
	int number;            // 数量
	bool is_valid;         // 记录是否有效（false=作废）
	struct medicine_io_record *next;
} MedicineIORecord;

typedef struct Medicine_information{
	char name[200];
	int stock; // 现有库存（替代 number_all，更语义化）
	float selling_price;    //售价
	float cost_price;   //进价
	MedicineIORecord *io_list; // 出入库记录链表
	struct Medicine_information *next;
}Medicine;

/*辅助函数6：*/
//批量生产药品信息函数
Medicine * medical_maker(char *name_0,//药品的名称
						 int number_0,//药品数量
						 float selling_price_0,   //药品售卖单价
						 float cost_price_0,   //药品成本单价
						 char *Operator_id,
						 DateTime operate_time,
						 DateTime deadline_of_medicine,
						 int operate_type,
						 int number_1,       //这是单次存储对应的药品数量
						 bool is_valid,        // 记录是否有效（false=作废)
						 Medicine *previous);         //连接指针链表尾差法；

#include"Doctor.h"
#include"Patient.h"
#include"Nurse.h"
#include"F4.h"




// 模块1：基础信息查询接口(都需要输入头指针)
Patient* find_patient(char* patientID,Patient *head_P);      // 根据病历号查找患者,没找到就返回NULL✅️main.c
Doctor* find_doctor(char* doctorID,Doctor *head_D);         // 根据工号查找医生，没找到就返回NULL✅️main.c
Nurse* find_nurse(char* nurseID,Nurse *head_N);            // 根据工号查找护士，没找到就返回NULL✅️main.c
Administrator* find_administrator(char* AdministratorID,Administrator *head_A);//根据工号找管理员，没找到就返回NULL✅️main.c
Medicine* find_medicine(char* Medical_name,Medicine *head_M);           //根据药品名找到对应药品，没有找到就返回NUll✅️main.c
MedicineIORecord* find_record(MedicineIORecord *M_Recored);                 //找到药品的记录（根据时间吗？）



/*=============================数据初始区程序结构体大差不差时被替换为文件读取构建函数============================*/
//用来构建初始函数✅️data_maker.c
//@处理构建完是NULL的情况，若D,P,M,,A,B为空则必定出错直接提示对应数据为NULL然后退出系统，因为现在不会构建出这种链表，现在给的数据都是好数据
void initdata_Doctor(Doctor **head_D);
void initdata_Patient(Patient **head_P);
void initdata_Medicine(Medicine **head_M);
void initdata_Consultation(Consultation **head_C);
void initdata_Nurse(Nurse **head_N);
void initdata_Administrator(Administrator **head_A);
void initdata_Bed(Bed **head_B);
/*----------尚未实现--------*/
//1. 全量保存：将医生 / 护士 / 患者 / 药品 / 诊疗记录 / 床位数据写入 txt；
//2. 增量保存：仅保存新增的诊疗记录；
//3. 加载数据：启动时从 txt 恢复所有链表；
//4. 容错处理：读取时校验数据格式（如身份证长度、时间合法性）

/*=====================================构建登录系统==================================*/

/*--------主函数（整个程序的主体内容都在里面）------*/
void login_system(Doctor **head_D0,Patient **head_P0,Medicine **head_M0,Consultation **head_C0,Nurse **head_N0,Administrator **head_A0,Bed **head_B0,ExaminationItem **red,ExaminationItem **lab);
/*-----------------包含函数--------------*/
//检查医生/护士/病人/管理员密码是否正确；✅️main.c
bool check_doctor(char *temp_id,char *temp_password,Doctor *head_D);
bool check_nurse(char *temp_id,char *temp_password,Nurse *head_N);
bool check_patient(char *temp_id,char *temp_password,Patient *head_P);
bool check_administrator(char *temp_id,char *temp_password,Administrator *head_A);



//用于验证的函数
/*void D_N_D(Doctor *head);//用于输出单个数据’
void print_Doctor(Doctor *head);*/


#endif
