#include "HMS.h"
#include "widely_used.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

// ===================== 全局加载所有数据=====================
void load_all_data(Doctor **head_D, Patient **head_P, Medicine **head_M,
				   Consultation **head_C, Nurse **head_N,
				   Administrator **head_A, Bed **head_B,ExaminationItem **red,ExaminationItem **lab,int choice) {
	if (head_D == NULL || head_P == NULL || head_M == NULL || head_C == NULL
		|| head_N == NULL || head_A == NULL || head_B == NULL||red==NULL||lab==NULL) {
		printf("系统数据初始化异常，请重启程序！\n");
		return;
	}
	
	if(choice==0)loadConsultationFromTxt("consultation_information0.txt",head_C);//读取诊疗记录
	else loadConsultationFromTxt("consultation_information.txt",head_C);//读取诊疗记录
	*red=load_from_file("radiology_items.txt");//读取影像科检查项目
	*lab=load_from_file("laboratory_items.txt");//读取检查科信息
	load_doctors_from_file(head_D);//读取医生信息
	loadNurseFromFile(head_N);//读取护士信息
	loadBedFromFile(head_B);//读取床位基本信息
	loadAdmissionHistoryFromFile(*head_B);//读取住院记录
	loadAdministratorFromFile(head_A);//读取管理员信息
	
	loadMedicineFromFile(head_M);//读取药品基本信息
	loadMedicineIOFromFile(*head_M);//读取药品出入记录
	loadPatientFromFile(head_P);//读取患者信息
}

// ===================== 全局保存所有数据（正确版，无&取地址） =====================
void save_all_data(Doctor *head_D0, Patient *head_P0, Medicine *head_M0,
				   Consultation *head_C0, Nurse *head_N0, Bed *head_B0,ExaminationItem *red,ExaminationItem *lab,int choice) {
	printf("开始保存");
	printf("开始保存诊疗记录数据\n");
	if (head_C0 != NULL) {
		if(choice==0)saveConsultationToTxt("consultation_information0.txt",head_C0);//读取诊疗记录
		else saveConsultationToTxt("consultation_information.txt",head_C0);//读取诊疗记录
	}
	save_to_file(red,"radiology_items.txt");
	save_to_file(lab,"laboratory_items.txt");
	printf("开始保存医生数据\n");
	if (head_D0 != NULL)    save_doctors_to_file(head_D0);
	printf("开始保存护士数据\n");
	if (head_N0 != NULL)    saveNurseToFile(head_N0);
	printf("开始保存病人信息\n");
	if(head_P0!=NULL)       savePatientToFile(head_P0);
	printf("开始保存床位数据\n");
	if (head_B0 != NULL) {
		saveBedToFile(head_B0);
		saveAdmissionHistoryToFile(head_B0);
	}
	
	printf("开始保存药品数据数据\n");
	if (head_M0 != NULL)    saveMedicineIOToFile(head_M0);
	saveMedicineToFile(head_M0);
}

/* ==================== 检查项目文件操作 ==================== */
//=================保存数据===============
int save_to_file(ExaminationItem *head, const char *filename) {
	FILE *fp = fopen(filename, "w");
	if (!fp) { printf("无法打开文件 %s\n", filename); return -1; }
	fprintf(fp, "ID|DeptID|Code|Name|Price|Unit|Status\n");
	ExaminationItem *p = head;
	if(p==NULL)printf("链表为NULL！！！！\n");
	for (; p; p = p->next)
		fprintf(fp, "%d|%d|%s|%s|%.2f|%s|%d\n", p->id, p->dept_id, p->item_code, p->item_name, p->price, p->unit, p->status);
	fclose(fp);
	printf("[保存成功] %s\n", filename);
	return 0;
}
//==============读取数据================
ExaminationItem* load_from_file(const char *filename) {
	FILE *fp = fopen(filename, "r");
	if (!fp) { printf("[加载失败] %s 不存在\n", filename); return NULL; }
	ExaminationItem *head = NULL;
	char line[512];
	fgets(line, sizeof(line), fp); // 跳过表头
	while (fgets(line, sizeof(line), fp)) {
		line[strcspn(line, "\n")] = 0;
		int id, dept_id, status;
		char code[20], name[100], unit[20];
		double price;
		if (sscanf(line, "%d|%d|%19[^|]|%99[^|]|%lf|%19[^|]|%d", &id, &dept_id, code, name, &price, unit, &status) == 7)
			insert_tail(&head, create_node(id, dept_id, code, name, price, unit, status));
	}
	fclose(fp);
	printf("[加载成功] %s\n", filename);
	return head;
}

void insert_tail(ExaminationItem **head, ExaminationItem *node) {
	if (!node) return;
	if (!*head) { *head = node; return; }
	ExaminationItem *p = *head;
	while (p->next) p = p->next;
	p->next = node;
}

void free_list(ExaminationItem *head) {
	while (head) {
		ExaminationItem *t = head;
		head = head->next;
		free(t);
	}
}


/* ==================== 链表操作 ==================== */

ExaminationItem* create_node(int id, int dept_id, const char* code, 
							 const char* name, double price, 
							 const char* unit, int status) {
	ExaminationItem *node = (ExaminationItem*)malloc(sizeof(ExaminationItem));
	if (!node) { printf("内存分配失败！\n"); return NULL; }
	node->id = id; node->dept_id = dept_id;
	strcpy(node->item_code,code);
	strcpy(node->item_name, name);
	node->price = price;
	strcpy(node->unit, unit);
	node->status = status;
	node->next = NULL;
	return node;
}



// 医生创建函数
Doctor *doctor_maker(char *name_0, int age_0, char *id_card_number_0, char *gender_0, char *phone_number_0,
					 date birthday_0, char *department_0, char *staff_id_0, char *login_password_0,
					 char *job_title_0, int staff_status_0, int (*schedule_0)[3], Doctor *previous) {
	Doctor *D = (Doctor *)malloc(sizeof(Doctor));
	strcpy(D->name, name_0);
	D->age = age_0;
	strcpy(D->id_card_number, id_card_number_0);
	strcpy(D->gender, gender_0);
	strcpy(D->phone_number, phone_number_0);
	D->birthday = birthday_0;
	strcpy(D->department, department_0);
	strcpy(D->staff_id, staff_id_0);
	strcpy(D->login_password, login_password_0);
	strcpy(D->job_title, job_title_0);
	D->staff_status = staff_status_0;
	for (int i = 1; i < 8; i++) {
		for (int j = 0; j < 3; j++) {
			D->schedule[i][j] = *(schedule_0[i] + j);
		}
	}
	D->next = previous;
	return D;
}

// 医生读取
void load_doctors_from_file(Doctor **head_D) {
	if (head_D == NULL) {
		printf("医生数据初始化失败，请重启程序！\n");
		return;
	}
	
	FILE *fp = fopen("doctor_information.txt", "r");
	if (fp == NULL) {
		printf("未找到医生数据文件，将新建空白数据\n");
		return;
	}
	
	Doctor *tmp;
	while (*head_D != NULL) {
		tmp = *head_D;
		*head_D = (*head_D)->next;
		free(tmp);
	}
	
	char line[1024];
	int warned = 0;
	while (fgets(line, sizeof(line), fp) != NULL) {
		// 去除换行回车，杜绝解析干扰
		size_t len = strlen(line);
		if(len > 0 && (line[len-1] == '\n' || line[len-1] == '\r'))
		line[len-1] = '\0';
		
		char name[20], id_card[25], phone[20], dept[20], staff_id[20], pwd[20], job[20], gender[20];
		int age, by, bm, bd, status;
		int schedule[8][3] = {0};
		
		int ret = sscanf(line,
						 "%[^|]|%d|%[^|]|%[^|]|%[^|]|%d|%d|%d|%[^|]|%[^|]|%[^|]|%[^|]|%d|",
						 name, &age, id_card, gender, phone,
						 &by, &bm, &bd, dept, staff_id, pwd, job, &status);
		
		if (ret != 13) {
			if (!warned) {
				printf("\n【警告】医生数据存在损坏或缺失，是否继续加载？\n1=继续（跳过坏行）  0=退出程序：");
				int ch; scanf("%d", &ch); if (ch == 0) { fclose(fp); exit(0); }
				warned = 1;
			}
			continue;
		}
		
		char *p = line;		
		
	   	for (int i = 0; i < 13; i++) { while (*p && *p != '|')p++; if (*p == '|')p++; }
		int ok = 1;
			for (int i = 1; i <= 7 && ok; i++) {
				for (int j = 0; j < 3; j++) {
				if (sscanf(p, "%d", &schedule[i][j]) != 1) { ok = 0; break; }
			while (*p && *p != ' ')p++;
			while (*p == ' ')p++;
			}
		}
		
		if (!ok) {
			if (!warned) {
				printf("\n【警告】医生值班数据损坏，是否继续？1=继续  0=退出：");
				int ch; scanf("%d", &ch); if (ch == 0) { fclose(fp); exit(0); }
				warned = 1;
			}
			continue;
		}
		
		date bday = (date){by, bm, bd};
		*head_D = doctor_maker(name, age, id_card, gender, phone, bday, dept, staff_id, pwd, job, status, schedule, *head_D);
	}
	
	fclose(fp);
	printf("医生数据加载完成\n");
}


void save_doctors_to_file(Doctor *head_D) {
	FILE *fp = fopen("doctor_information.txt", "w");
	if (fp == NULL) {
		printf("文件打开失败！\n");
		return;
	}
	Doctor *p = head_D;
	while (p != NULL) {
		// 按固定格式写入一行，方便读取
		fprintf(fp, "%s|%d|%s|%s|%s|%d|%d|%d|%s|%s|%s|%s|%d|",
				p->name,
				p->age,
				p->id_card_number,
				p->gender,
				p->phone_number,
				p->birthday.year,
				p->birthday.month,
				p->birthday.day,
				p->department,
				p->staff_id,
				p->login_password,
				p->job_title,
				p->staff_status);
		// 写入值班表
		for (int i = 1; i <= 7; i++) {
			for (int j = 0; j < 3; j++) {
				fprintf(fp, "%d ", p->schedule[i][j]);
			}
		}
		fprintf(fp, "\n");
		p = p->next;
	}
	fclose(fp);
	printf("医生数据已成功保存到 doctor.txt\n");
}






// 护士创建函数
Nurse *nurse_maker(char *name_0, int age_0, char *id_card_number_0, char *gender_0, char *phone_number_0,
				   date birthday_0, char *department_0, char *staff_id_0, char *login_password_0,
				   char *job_title_0, int responsible_number_0, int staff_status_0, int (*schedule_0)[3], Nurse *previous) {
	Nurse *N = (Nurse *)malloc(sizeof(Nurse));
	strcpy(N->name, name_0);
	N->age = age_0;
	strcpy(N->id_card_number, id_card_number_0);
	strcpy(N->gender, gender_0);
	strcpy(N->phone_number, phone_number_0);
	N->birthday.year = birthday_0.year;
	N->birthday.month = birthday_0.month;
	N->birthday.day = birthday_0.day;
	strcpy(N->department, department_0);
	strcpy(N->staff_id, staff_id_0);
	strcpy(N->login_password, login_password_0);
	strcpy(N->job_title, job_title_0);
	N->responsible_number = responsible_number_0;
	N->staff_status = staff_status_0;
	for (int i = 1; i < 8; i++) {
		for (int j = 0; j < 3; j++) {
			N->schedule[i][j] = *(schedule_0[i] + j);
		}
	}
	N->next = previous;
	return N;
}

// 护士读取
void loadNurseFromFile(Nurse **head_N) {
	if (head_N == NULL) {
		printf("护士数据初始化失败，请重启程序！\n");
		return;
	}
	
	FILE *fp = fopen("nurse_information.txt", "r");
	if (!fp) {
		printf("未找到护士数据文件，将新建空白数据\n");
		return;
	}
	
	Nurse *tmp;
	while (*head_N != NULL) {
		tmp = *head_N;
		*head_N = (*head_N)->next;
		free(tmp);
	}
	
	char line[1024];
	int warned = 0;
	
	while (fgets(line, sizeof(line), fp) != NULL) {
		char name[20], id_card[25], phone[20], dept[20], staff_id[20], pwd[20], title[20], gender[10];
		int age, by, bm, bd, resp_num, status;
		int schedule[8][3] = {0};
		
		int ret = sscanf(line,
						 "%[^|]|%d|%[^|]|%[^|]|%[^|]|%d|%d|%d|%[^|]|%[^|]|%[^|]|%[^|]|%d|%d|",
						 name, &age, id_card, gender, phone,
						 &by, &bm, &bd, dept, staff_id, pwd, title, &resp_num, &status);
		
		if (ret != 14) {
			if (!warned) {
				printf("\n【警告】护士数据损坏，是否继续？1=继续 0=退出：");
				int ch; scanf("%d", &ch); if (ch == 0) { fclose(fp); exit(0); } warned = 1;
			}
			continue;
		}
		
		char *p = line;
		for (int i = 0; i < 14; i++) { while (*p && *p != '|')p++; if (*p == '|')p++; }
		int ok = 1;
		for (int i = 1; i <= 7 && ok; i++) {
			for (int j = 0; j < 3; j++) {
				if (sscanf(p, "%d", &schedule[i][j]) != 1) { ok = 0; break; }
				while (*p && *p != '|')p++;
				if (*p == '|')p++;
			}
		}
		
		if (!ok) {
			if (!warned) {
				printf("\n【警告】护士值班数据损坏，是否继续？1=继续 0=退出：");
				int ch; scanf("%d", &ch); if (ch == 0) { fclose(fp); exit(0); } warned = 1;
			}
			continue;
		}
		
		date bday = {by, bm, bd};
		*head_N = nurse_maker(name, age, id_card, gender, phone, bday, dept, staff_id, pwd, title, resp_num, status, schedule, *head_N);
	}
	
	fclose(fp);
	printf("护士数据加载完成\n");
}

// 护士保存
void saveNurseToFile(Nurse *head_N) {
	if (head_N == NULL) {
		printf("暂无护士数据，无需保存\n");
		return;
	}
	
	FILE *fp = fopen("nurse_information.txt", "w");
	if (!fp) {
		printf("护士数据保存失败，请检查文件权限\n");
		return;
	}
	
	Nurse *p = head_N;
	while (p != NULL) {
		fprintf(fp, "%s|%d|%s|%s|%s|%d|%d|%d|%s|%s|%s|%s|%d|%d|",
				p->name, p->age, p->id_card_number, p->gender, p->phone_number,
				p->birthday.year, p->birthday.month, p->birthday.day,
				p->department, p->staff_id, p->login_password, p->job_title,
				p->responsible_number, p->staff_status);
		
		for (int i = 1; i <= 7; i++) {
			for (int j = 0; j < 3; j++) {
				fprintf(fp, "%d|", p->schedule[i][j]);
			}
		}
		fprintf(fp, "\n");
		p = p->next;
	}
	
	fclose(fp);
	printf("护士数据已保存\n");
}


// 床位创建函数
Bed *bed_all_maker(char *department_name_0, char *bed_id_0, int type_0, char *Ward_number_0,
				   int order_0, float daily_cost_0, Bed *previous) {
	Bed *B = (Bed *)malloc(sizeof(Bed));
	B->status = (Admission_information *)malloc(sizeof(Admission_information));
	B->status = NULL;
	strcpy(B->department_name, department_name_0);
	strcpy(B->bed_id, bed_id_0);
	strcpy(B->Ward_number, Ward_number_0);
	B->type = type_0;
	B->order = order_0;
	B->daily_cost = daily_cost_0;
	B->next = previous;
	return B;
}

// 床位读取
void loadBedFromFile(Bed **head_B) {
	if (head_B == NULL) {
		printf("床位数据初始化失败，请重启程序！\n");
		return;
	}
	
	FILE *fp = fopen("bed_basic_information.txt", "r");
	if (!fp) {
		printf("未找到床位数据文件，将新建空白数据\n");
		return;
	}
	
	*head_B = NULL;
	char line[512];
	int warned = 0;
	
	while (fgets(line, sizeof(line), fp) != NULL) {
		char dept[20], bed_id[20], ward[20];
		int type, order;
		float cost;
		
		int ret = sscanf(line, "%[^|]|%[^|]|%d|%[^|]|%d|%f", dept, bed_id, &type, ward, &order, &cost);
		if (ret != 6) {
			if (!warned) {
				printf("\n【警告】床位数据损坏，是否继续？1=继续 0=退出：");
				int ch; scanf("%d", &ch); if (ch == 0) { fclose(fp); exit(0); } warned = 1;
			}
			continue;
		}
		*head_B = bed_all_maker(dept, bed_id, type, ward, order, cost, *head_B);
	}
	
	fclose(fp);
	printf("床位数据加载完成\n");
}

// 床位保存
void saveBedToFile(Bed *head_B) {
	if (head_B == NULL) {
		printf("暂无床位数据，无需保存\n");
		return;
	}
	
	FILE *fp = fopen("bed_basic_information.txt", "w");
	if (!fp) {
		printf("床位数据保存失败，请检查文件权限\n");
		return;
	}
	
	Bed *p = head_B;
	while (p != NULL) {
		fprintf(fp, "%s|%s|%d|%s|%d|%.2f\n",
				p->department_name, p->bed_id, p->type,
				p->Ward_number, p->order, p->daily_cost);
		p = p->next;
	}
	
	fclose(fp);
	printf("床位数据已保存\n");
}

// 住院记录读取
void loadAdmissionHistoryFromFile(Bed *head_B) {
	if (head_B == NULL) {
		printf("暂无床位信息，无法加载住院记录\n");
		return;
	}
	
	FILE *fp = fopen("bed_admission_history.txt", "r");
	if (!fp) {
		printf("未找到住院记录，将新建空白记录\n");
		return;
	}
	
	char line[1024];
	int warned = 0;
	
	while (fgets(line, sizeof(line), fp) != NULL) {
		char bed_id[20], patient[50], doctor[50], nurse[50];
		DateTime in, out, last;
		float ya, cost;
		int days;
		
		int ret = sscanf(line,
						 "%[^|]|%[^|]|%[^|]|%[^|]|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%f|%f|%d",
						 bed_id, patient, doctor, nurse,
						 &in.year, &in.month, &in.day, &in.hour, &in.minute, &in.second,
						 &out.year, &out.month, &out.day, &out.hour, &out.minute, &out.second,
						 &last.year, &last.month, &last.day, &last.hour, &last.minute, &last.second,
						 &ya, &cost, &days);
		
		if (ret != 25) {
			if (!warned) {
				printf("\n【警告】住院记录损坏，是否继续？1=继续 0=退出：");
				int ch; scanf("%d", &ch); if (ch == 0) { fclose(fp); exit(0); } warned = 1;
			}
			continue;
		}
		
		Bed *b = head_B;
		while (b && strcmp(b->bed_id, bed_id) != 0) b = b->next;
		if (!b) continue;
		
		Admission_information *adm = (Admission_information*)malloc(sizeof(Admission_information));
		strcpy(adm->patient_id, patient);
		strcpy(adm->doctor_id, doctor);
		strcpy(adm->nurse_id, nurse);
		adm->check_in = in;
		adm->check_out = out;
		adm->last_deduct_day = last;
		adm->ya_cash = ya;
		adm->cost_cash = cost;
		adm->days = days;
		adm->next = b->status;
		if(b->status==NULL)adm->next=NULL;
		b->status = adm;
	}
	
	fclose(fp);
	printf("住院记录加载完成\n");
}

// 住院记录保存
void saveAdmissionHistoryToFile(Bed *head_B) {
	if (head_B == NULL) {
		printf("暂无床位信息，无需保存住院记录\n");
		return;
	}
	
	FILE *fp = fopen("bed_admission_history.txt", "w");
	if (!fp) {
		printf("住院记录保存失败，请检查文件权限\n");
		return;
	}
	
	Bed *p = head_B;
	while (p != NULL) {
		Admission_information *adm = p->status;
		while (adm != NULL) {
			fprintf(fp, "%s|%s|%s|%s|", p->bed_id, adm->patient_id, adm->doctor_id, adm->nurse_id);
			fprintf(fp, "%d|%d|%d|%d|%d|%d|",
					adm->check_in.year, adm->check_in.month, adm->check_in.day,
					adm->check_in.hour, adm->check_in.minute, adm->check_in.second);
			fprintf(fp, "%d|%d|%d|%d|%d|%d|",
					adm->check_out.year, adm->check_out.month, adm->check_out.day,
					adm->check_out.hour, adm->check_out.minute, adm->check_out.second);
			fprintf(fp, "%d|%d|%d|%d|%d|%d|",
					adm->last_deduct_day.year, adm->last_deduct_day.month, adm->last_deduct_day.day,
					adm->last_deduct_day.hour, adm->last_deduct_day.minute, adm->last_deduct_day.second);
			fprintf(fp, "%.2f|%.2f|%d\n", adm->ya_cash, adm->cost_cash, adm->days);
			adm = adm->next;
		}
		p = p->next;
	}
	
	fclose(fp);
	printf("住院记录已保存\n");
}


// 管理员创建函数
Administrator *administrator_maker(char *name_0, char *staff_id_0, char *login_password_0, Administrator *previous) {
	Administrator *A = (Administrator *)malloc(sizeof(Administrator));
	strcpy(A->name, name_0);
	strcpy(A->staff_id, staff_id_0);
	strcpy(A->login_password, login_password_0);
	A->next = previous;
	return A;
}

// 管理员读取
void loadAdministratorFromFile(Administrator **head_A) {
	if (head_A == NULL) {
		printf("管理员数据初始化失败，请重启程序！\n");
		return;
	}
	
	FILE *fp = fopen("administrator_information.txt", "r");
	if (!fp) {
		printf("未找到管理员数据，将新建空白数据\n");
		return;
	}
	
	*head_A = NULL;
	char line[256];
	int warned = 0;
	
	while (fgets(line, sizeof(line), fp) != NULL) {
		char name[20], staff_id[20], pwd[20];
		int ret = sscanf(line, "%[^|]|%[^|]|%s", name, staff_id, pwd);
		if (ret != 3) {
			if (!warned) {
				printf("\n【警告】管理员数据损坏，是否继续？1=继续 0=退出：");
				int ch; scanf("%d", &ch); if (ch == 0) { fclose(fp); exit(0); } warned = 1;
			}
			continue;
		}
		*head_A = administrator_maker(name, staff_id, pwd, *head_A);
	}
	
	fclose(fp);
	printf("管理员数据加载完成\n");
}

// 管理员保存
void saveAdministratorToFile(Administrator *head_A) {
	if (head_A == NULL) {
		printf("暂无管理员数据，无需保存\n");
		return;
	}
	
	FILE *fp = fopen("administrator_information.txt", "w");
	if (!fp) {
		printf("管理员数据保存失败，请检查文件权限\n");
		return;
	}
	
	Administrator *p = head_A;
	while (p != NULL) {
		fprintf(fp, "%s|%s|%s\n", p->name, p->staff_id, p->login_password);
		p = p->next;
	}
	
	fclose(fp);
	printf("管理员数据已保存\n");
}



// ===================== 保存药品基础信息到 medicine.txt =====================
void saveMedicineToFile(Medicine *head_M) {
	FILE *fp = fopen("medicine.txt", "w");
	if (!fp) {
		printf("写入药品文件失败！\n");
		return;
	}
	
	Medicine *p = head_M;
	Medicine *temp=p;
	while (p != NULL) {
		fprintf(fp, "%s|%d|%.2f|%.2f\n",
				p->name,
				p->stock,
				p->selling_price,
				p->cost_price);
		temp=p;
		p = p->next;
		free(temp);
	}
	
	fclose(fp);
	printf("药品基础数据已保存到 medicine.txt\n");
}

// ===================== 保存出入库记录到 medicine_io.txt =====================
void saveMedicineIOToFile(Medicine *head_M) {
	FILE *fp = fopen("medicine_io.txt", "w");
	if (!fp) {
		printf("写入出入库记录文件失败！\n");
		return;
	}
	
	Medicine *p = head_M;
	while (p != NULL) {
		MedicineIORecord *io = p->io_list;
		MedicineIORecord *temp=io;
		while (io != NULL) {
			fprintf(fp, "%s|%s|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d\n",
					p->name,                    // 药品名称（关联键）
					io->operator_id,
					io->operate_time.year,
					io->operate_time.month,
					io->operate_time.day,
					io->operate_time.hour,
					io->operate_time.minute,
					io->operate_time.second,
					io->deadline_time.year,
					io->deadline_time.month,
					io->deadline_time.day,
					io->deadline_time.hour,
					io->deadline_time.minute,
					io->deadline_time.second,
					io->io_type,
					io->number,
					io->is_valid ? 1 : 0);
			temp=io;
			io = io->next;
			free(temp);
		}
		p = p->next;
	}
	
	fclose(fp);
	printf("出入库记录已保存到 medicine_io.txt\n");
}

// ===================== 从 medicine.txt 读取药品基础信息 =====================
void loadMedicineFromFile(Medicine **head_M) {
	FILE *fp = fopen("medicine.txt", "r");
	if (fp == NULL) {
		printf("药品文件不存在或读取失败！\n");
		return;
	}
	
	// 清空原有药品链表（不释放 io_list，由 loadMedicineIOFromFile 处理或单独释放）
	Medicine *del_med;
	while (*head_M != NULL) {
		del_med = *head_M;
		*head_M = (*head_M)->next;
		// 注意：这里不释放 io_list，假设会重新加载或已释放
		free(del_med);
	}
	
	char buf[256];
	while (fgets(buf, sizeof(buf), fp) != NULL) {
		// 去掉末尾换行符
		buf[strcspn(buf, "\n")] = '\0';
		
		Medicine *node = (Medicine *)malloc(sizeof(Medicine));
		node->io_list = NULL;  // 初始化，等待关联出入库记录
		node->next = NULL;
		
		sscanf(buf, "%[^|]|%d|%f|%f",
			   node->name,
			   &node->stock,
			   &node->selling_price,
			   &node->cost_price);
		
		// 头插法
		node->next = *head_M;
		*head_M = node;
	}
	
	fclose(fp);
	printf("药品基础信息已从 medicine.txt 读取完成！\n");
}

// ===================== 从 medicine_io.txt 读取出入库记录并关联到药品 =====================
void loadMedicineIOFromFile(Medicine *head_M) {
	FILE *fp = fopen("medicine_io.txt", "r");
	if (fp == NULL) {
		printf("出入库记录文件不存在或读取失败！\n");
		return;
	}
	
	// 先清空所有药品现有的 io_list
	Medicine *p = head_M;
	while (p != NULL) {
		MedicineIORecord *io = p->io_list;
		while (io != NULL) {
			MedicineIORecord *del = io;
			io = io->next;
			free(del);
		}
		p->io_list = NULL;
		p = p->next;
	}
	
	char buf[512];
	while (fgets(buf, sizeof(buf), fp) != NULL) {
		buf[strcspn(buf, "\n")] = '\0';
		
		char med_name[200];
		MedicineIORecord *io = (MedicineIORecord *)malloc(sizeof(MedicineIORecord));
		
		int valid;
		sscanf(buf, "%[^|]|%[^|]|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d",
			   med_name,
			   io->operator_id,
			   &io->operate_time.year,
			   &io->operate_time.month,
			   &io->operate_time.day,
			   &io->operate_time.hour,
			   &io->operate_time.minute,
			   &io->operate_time.second,
			   &io->deadline_time.year,
			   &io->deadline_time.month,
			   &io->deadline_time.day,
			   &io->deadline_time.hour,
			   &io->deadline_time.minute,
			   &io->deadline_time.second,
			   &io->io_type,
			   &io->number,
			   &valid);
		
		io->is_valid = (valid == 1);
		io->next = NULL;
		
		// 查找对应药品并头插法添加
		Medicine *med = find_medicine(med_name, head_M);
		if (med != NULL) {
			io->next = med->io_list;
			med->io_list = io;
		} else {
			printf("警告：找不到药品 [%s]，该出入库记录将被丢弃\n", med_name);
			free(io);
		}
	}
	
	fclose(fp);
	printf("出入库记录已从 medicine_io.txt 读取并关联完成！\n");
}


// ===================== 诊疗记录 保存 =====================
void saveConsultationToTxt(char *file,Consultation *head) {
	FILE *fp = fopen(file, "w");
	if (fp == NULL) {
		printf("文件打开失败！\n");
		return;
	}
	
	Consultation *p = head;
	while (p != NULL) {
		fprintf(fp, "%s|%s|%s|%s|%s|%s|",
				p->department, p->recordID, p->doctorID, p->patientID, p->doctorNAME, p->patientNAME);
		fprintf(fp, "%d|%d|%d|%d|%d|%d|",
				p->consultTime_start.year, p->consultTime_start.month, p->consultTime_start.day,
				p->consultTime_start.hour, p->consultTime_start.minute, p->consultTime_start.second);
		fprintf(fp, "%d|%d|%d|%d|%d|%d|",
				p->consultTime_end.year, p->consultTime_end.month, p->consultTime_end.day,
				p->consultTime_end.hour, p->consultTime_end.minute, p->consultTime_end.second);
		fprintf(fp, "%s|%s|%s|%s|%s|%s|%s|%s|%s|%.1f\n",
				p->chiefComplaint, p->presentIllness, p->physicalExam, p->diagnosis,
				p->labTests, p->treatmentPlan, p->prescription, p->record_of_inhospital,
				p->status, p->cost);
		p = p->next;
	}
	fclose(fp);
	printf("诊疗记录已保存到 txt 文件！\n");
}

// ===================== 诊疗记录 读取 =====================
void loadConsultationFromTxt(char *file,Consultation **head) {
	FILE *fp = fopen(file,"r");
	if (fp == NULL) {
		printf("文件不存在或打开失败！\n");
		return;
	}
	Consultation *del;
	while (*head != NULL) {
		del = *head;
		*head = (*head)->next;
		free(del);
	}
	Consultation *tail = NULL;
	char buf[4096];
	while (fgets(buf, sizeof(buf), fp) != NULL) {
		if (strlen(buf) < 10) continue;
		Consultation *node = (Consultation *)malloc(sizeof(Consultation));
		node->next = NULL;
		int ret = sscanf(buf,
						 "%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|"
						 "%d|%d|%d|%d|%d|%d|"
						 "%d|%d|%d|%d|%d|%d|"
						 "%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%f",
						 
						 node->department, node->recordID, node->doctorID, node->patientID,
						 node->doctorNAME, node->patientNAME,
						 
						 &node->consultTime_start.year, &node->consultTime_start.month, &node->consultTime_start.day,
						 &node->consultTime_start.hour, &node->consultTime_start.minute, &node->consultTime_start.second,
						 
						 &node->consultTime_end.year, &node->consultTime_end.month, &node->consultTime_end.day,
						 &node->consultTime_end.hour, &node->consultTime_end.minute, &node->consultTime_end.second,
						 
						 node->chiefComplaint, node->presentIllness, node->physicalExam, node->diagnosis,
						 node->labTests, node->treatmentPlan, node->prescription, node->record_of_inhospital,
						 node->status, &node->cost);
		if (ret < 28) { free(node);printf("有数据出错！！！\n"); continue; }
		
		if (*head == NULL) { *head = node; tail = node; }
		else { tail->next = node; tail = node; }
	}
	
	fclose(fp);
	printf("从 txt 文件读取诊疗记录完成！\n");
}


// 病人读取
void loadPatientFromFile(Patient **head_P) {
	FILE *fp = fopen("patient_information4.txt", "r");
	if (!fp) {
		printf("读取病人文件失败！\n");
		return;
	}
	
	*head_P = NULL;
	Patient *last = NULL;
	
	char name[20], id_card[25], patientID[20], pwd[20], phone[20], gender[10];
	char emergency[20], emergency_phone[20];
	int age, by, bm, bd;
	
	while (fscanf(fp, "%[^|]|%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%d|%d|%d|%[^|]|%[^\n]\n",
				  name, &age, id_card, patientID, pwd, phone, gender, &by, &bm, &bd, emergency, emergency_phone) == 12)
	{
		Patient *new = (Patient*)malloc(sizeof(Patient));
		strcpy(new->name, name);
		new->age = age;
		strcpy(new->id_card_number, id_card);
		strcpy(new->patientID, patientID);
		strcpy(new->login_password, pwd);
		strcpy(new->phonenumber, phone);
		strcpy(new->gender, gender);
		new->birthday.year = by;
		new->birthday.month = bm;
		new->birthday.day = bd;
		strcpy(new->Emergency_contact, emergency);
		strcpy(new->Emergency_contact_phonenumber, emergency_phone);
		new->next = NULL;
		
		if (*head_P == NULL) {
			*head_P = new;
			last = new;
		} else {
			last->next = new;
			last = new;
		}
	}
	
	fclose(fp);
}


void savePatientToFile(Patient *head_P) {
	FILE *fp = fopen("patient_information4.txt", "w");
	if (!fp) {
		printf("写入病人文件失败！\n");
		return;
	}
	
	Patient *p = head_P;
	while (p != NULL) {
		fprintf(fp, "%s|%d|%s|%s|%s|%s|%s|%d|%d|%d|%s|%s\n",
				p->name,
				p->age,
				p->id_card_number,
				p->patientID,
				p->login_password,
				p->phonenumber,
				p->gender,
				p->birthday.year,
				p->birthday.month,
				p->birthday.day,
				p->Emergency_contact,
				p->Emergency_contact_phonenumber);
		p = p->next;
	}
	
	fclose(fp);
}

