
#include"HMS.h"
#include"widely_used.h"
#include"registration.h"
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<stdbool.h>
#include <time.h>   // 通用时间头文件




// 全局变量：记录当日挂号数
extern int daily_total_reg;
// 每日总号源400
extern int doc_reg_count[100];
// 医生当日挂号数（索引对应工号哈希，简化）
extern int pat_reg_count[100]; 
// 患者当日挂号数
extern int pat_dept_reg[100][7];

// 注册新患者
void register_new_patient(Patient **head_P0, char *suggested_id) {
	
	printf("\n========== 新患者注册 ==========\n");
	
	Patient *new_patient = (Patient*)malloc(sizeof(Patient));
	if(new_patient == NULL) {
		printf(" 内存分配失败！\n");
		return ;
	}
	
	
	printf("请输入姓名：");
	fgets(new_patient->name, sizeof(new_patient->name), stdin);
	new_patient->name[strcspn(new_patient->name, "\n")] = 0;
	
	printf("请输入年龄：");
	scanf("%d", &new_patient->age);
	clear_input_buffer();
	
	printf("请输入身份证号：");
	fgets(new_patient->id_card_number, sizeof(new_patient->id_card_number), stdin);
	new_patient->id_card_number[strcspn(new_patient->id_card_number, "\n")] = 0;
	
	printf("请输入性别（男/女）：");
	while(scanf("%s", new_patient->gender)!=1||(strcmp(new_patient->gender,"女")!=0&&strcmp(new_patient->gender,"男")!=0)){
		printf("请输入你的性别“男/女”\n");
		
	}
	clear_input_buffer();
	
	printf("请输入手机号码：");
	fgets(new_patient->phonenumber, sizeof(new_patient->phonenumber), stdin);
	new_patient->phonenumber[strcspn(new_patient->phonenumber, "\n")] = 0;
	
	printf("请输入出生日期（格式：年 月 日）：");
	scanf("%d %d %d", &new_patient->birthday.year, 
		  &new_patient->birthday.month, &new_patient->birthday.day);
	clear_input_buffer();
	
	printf("请输入紧急联系人姓名：");
	fgets(new_patient->Emergency_contact, sizeof(new_patient->Emergency_contact), stdin);
	new_patient->Emergency_contact[strcspn(new_patient->Emergency_contact, "\n")] = 0;
	
	printf("请输入紧急联系人电话：");
	fgets(new_patient->Emergency_contact_phonenumber, 
		  sizeof(new_patient->Emergency_contact_phonenumber), stdin);
	new_patient->Emergency_contact_phonenumber[strcspn(new_patient->Emergency_contact_phonenumber, "\n")] = 0;
	
	strcpy(new_patient->patientID, suggested_id);

	
	strcpy(new_patient->login_password, "123456");
	
	new_patient->next = *head_P0;
	*head_P0 = new_patient;
	
	printf("\n 患者注册成功！\n");
	printf("病历号：%s\n", new_patient->patientID);
	printf("默认密码：123456\n");
	printf("================================\n");
	
	return ;
}


// 显示患者信息
void display_patient_info(Patient *patient) {
	if(patient == NULL) return;
	
	printf("\n========== 患者信息 ==========\n");
	printf("病历号：%s\n", patient->patientID);
	printf("姓名：%s\n", patient->name);
	printf("性别：%s\n", patient->gender);
	printf("年龄：%d\n", patient->age);
	printf("身份证号：%s\n", patient->id_card_number);
	printf("出生日期：%d-%02d-%02d\n", 
		   patient->birthday.year, patient->birthday.month, patient->birthday.day);
	printf("手机号码：%s\n", patient->phonenumber);
	printf("紧急联系人：%s (%s)\n", 
		   patient->Emergency_contact, patient->Emergency_contact_phonenumber);
	printf("===============================\n");
}

// 修改紧急联系人信息
void change_emergency_connection_information(Patient **head_P0, char *patientID) {
	Patient *head_P = *head_P0;
	Patient *patient = find_patient(patientID, head_P);
	
	if(patient == NULL) {
		printf(" 患者信息不存在！\n");
		return;
	}
	
	printf("\n========== 修改紧急联系人 ==========\n");
	printf("当前紧急联系人：%s\n", patient->Emergency_contact);
	printf("当前紧急联系人电话：%s\n", patient->Emergency_contact_phonenumber);
	
	clear_input_buffer();
	
	printf("请输入新的紧急联系人姓名（留空保持不变）：");
	char new_contact[20];
	fgets(new_contact, sizeof(new_contact), stdin);
	new_contact[strcspn(new_contact, "\n")] = 0;
	if(strlen(new_contact) > 0) {
		strcpy(patient->Emergency_contact, new_contact);
	}
	
	printf("请输入新的紧急联系人电话（留空保持不变）：");
	char new_phone[20];
	fgets(new_phone, sizeof(new_phone), stdin);
	new_phone[strcspn(new_phone, "\n")] = 0;
	if(strlen(new_phone) > 0) {
		strcpy(patient->Emergency_contact_phonenumber, new_phone);
	}
	
	printf("\n 紧急联系人信息已更新！\n");
}

// 修改手机号码
void change_phonenumber(Patient **head_P0, char *patientID) {
	Patient *head_P = *head_P0;
	Patient *patient = find_patient(patientID, head_P);
	
	if(patient == NULL) {
		printf(" 患者信息不存在！\n");
		return;
	}
	
	printf("\n========== 修改手机号码 ==========\n");
	printf("当前手机号码：%s\n", patient->phonenumber);
	
	clear_input_buffer();
	
	printf("请输入新的手机号码：");
	char new_phone[20];
	fgets(new_phone, sizeof(new_phone), stdin);
	new_phone[strcspn(new_phone, "\n")] = 0;
	
	if(strlen(new_phone) > 0) {
		strcpy(patient->phonenumber, new_phone);
		printf("\n 手机号码已更新！\n");
	} else {
		printf("\n 未做修改\n");
	}
}

// 修改登录密码
void change_login_password(Patient **head_P0, char *patientID) {
	Patient *head_P = *head_P0;
	Patient *patient = find_patient(patientID, head_P);
	
	if(patient == NULL) {
		printf(" 患者信息不存在！\n");
		return;
	}
	
	printf("\n========== 修改登录密码 ==========\n");
	
	clear_input_buffer();
	
	printf("请输入当前密码：");
	char old_password[20];
	fgets(old_password, sizeof(old_password), stdin);
	old_password[strcspn(old_password, "\n")] = 0;
	
	if(strcmp(old_password, patient->login_password) != 0) {
		printf(" 当前密码错误！\n");
		return;
	}
	
	printf("请输入新密码：");
	char new_password[20];
	fgets(new_password, sizeof(new_password), stdin);
	new_password[strcspn(new_password, "\n")] = 0;
	
	printf("请确认新密码：");
	char confirm_password[20];
	fgets(confirm_password, sizeof(confirm_password), stdin);
	confirm_password[strcspn(confirm_password, "\n")] = 0;
	
	if(strcmp(new_password, confirm_password) != 0) {
		printf(" 两次输入的密码不一致！\n");
		return;
	}
	
	strcpy(patient->login_password, new_password);
	printf("\n 密码修改成功！\n");
}


//统计患者当日某科室挂号数

int today_patient_dept_reg_count(Consultation*head_C,char*patient_id,const char*dept_name,DateTime today)
{
	int count=0;
	Consultation *curr=head_C;
	while(curr != NULL)
	{
		if( strcmp(curr->patientID,patient_id) == 0 &&//是否是该患者
		   curr->consultTime_start.year == today.year &&
		   curr->consultTime_start.month == today.month &&
		   curr->consultTime_start.day == today.day )//从医生信息中获取科室，磁珠通过医生工号进行查找
		{
			count++;
		}
		curr=curr->next;	
	}
	return count;
}


//辅助函数，计算患者id的哈希值，用于检查当日挂号数相关

int hash_patient_id(const char*patientID)
{
	int hash=0;
	for(int i=1;patientID[i] != '\0';i++)
	{
		hash=(hash*31+patientID[i])%100;
	}
	return hash;
}



//患者选定医生后时间段什么什么都确定了，然后开始检测患者选的这个医生能不能给他/她看病

bool line_registration_with_time(Doctor **head_D0, Patient **head_P0, Consultation **head_C0,
						  char *patientID, char *doctorID,char *dept_names,int time_period) {
	Doctor *head_D = *head_D0;
	Patient *head_P = *head_P0;
	Consultation *head_C = *head_C0;
	
	// 线下挂号：就诊时间就是当前时间
	DateTime visit_time = get_current_time();
	
	// ==================== 1. 查找并验证患者信息 ====================
	Patient *patient = find_patient(patientID, head_P);
	if(patient == NULL) {
		printf(" 患者信息不存在！\n");
		return false;
	}
	
	// ==================== 2. 查找并验证医生信息 ====================
	Doctor *doctor = find_doctor(doctorID, head_D);
	if(doctor == NULL) {
		printf(" 医生信息不存在！\n");
		return false;
	}
	
	// ==================== 3. 验证医生在职状态 ====================
	// 只有在职的医生才能接诊
	if(!doctor_active(doctor)) {
		printf(" 该医生当前不在职（休假或离职），无法挂号！\n");
		return false;
	}
	
	// ==================== 4. 验证医生当日是否排班 ====================
	// 医生今日不值班则不能挂号
	if(!doctor_on_duty(doctor, visit_time,time_period)) {
		printf(" 该医生今日不值班，请选择其他医生2！\n");
		return false;
	}
	
	
	// ==================== 5. 执行四重号源限制校验 ====================
	CheckResult check = check_reg_restriction(head_C, doctor, patientID, visit_time,time_period);
	switch(check) {
	case CHECK_FAIL_TOTAL:
		printf(" 今日总号源已满（400个），请明日再来！\n");
		return false;
	case CHECK_FAIL_DOCTOR:
		printf(" 该医生今日号源已满，请选择其他医生！\n");
		return false;
	case CHECK_FAIL_PATIENT:
		printf(" 您今日挂号数已达上限（5个），无法继续挂号！\n");
		return false;
	case CHECK_FAIL_DEPT:
		printf(" 您今日已在该科室挂过号（同科室每日限1次），无法重复挂号！\n");
		return false;
	default:
		// CHECK_PASS，继续执行
		break;
	}
	
	// ==================== 6. 生成唯一的挂号单号 ====================
	char recordID[30];
	generate_record_ID(visit_time, doctorID, daily_total_reg, recordID);
	// ==================== 7. 创建新的诊疗记录 ====================
	Consultation *new_cons = (Consultation*)malloc(sizeof(Consultation));
	if(new_cons == NULL) {
		printf(" 内存分配失败！\n");
		return false;
	}
	
	// 初始化诊疗记录的各项字段
	strcpy(new_cons->recordID, recordID);              // 挂号单号
	strcpy(new_cons->doctorID, doctorID);              // 医生工号
	strcpy(new_cons->patientID, patientID);            // 患者病历号
	strcpy(new_cons->doctorNAME, doctor->name);        // 医生姓名（冗余存储，便于显示）
	strcpy(new_cons->patientNAME, patient->name);      // 患者姓名（冗余存储，便于显示）
	strcpy(new_cons->department,dept_names);
	new_cons->consultTime_start = visit_time;          // 就诊开始时间（当前时间）
	new_cons->consultTime_end = visit_time;            // 结束时间初始与开始时间相同
	strcpy(new_cons->chiefComplaint, "(空)");              // 主诉（待医生填写）
	strcpy(new_cons->presentIllness, "(空)");              // 现病史（待医生填写）
	strcpy(new_cons->physicalExam, "(空)");                // 体格检查（待医生填写）
	strcpy(new_cons->diagnosis, "(空)");                   // 诊断结果（待医生填写）
	strcpy(new_cons->labTests, "(空)");                    // 检查项目（待医生填写）
	strcpy(new_cons->treatmentPlan, "(空)");               // 治疗计划（待医生填写）
	strcpy(new_cons->prescription, "(空)");                // 处方（待医生填写）
	strcpy(new_cons->record_of_inhospital, "(空)");        // 住院详情（出院时填写）
	new_cons->cost = 0.0;                              // 总费用初始为0
	strcpy(new_cons->status, "候诊");                   // 初始状态为"候诊"
	
	// ==================== 8. 头插法将新记录加入链表 ====================
	new_cons->next = *head_C0;
	*head_C0 = new_cons;
	
	// ==================== 9. 更新全局挂号计数器 ====================
	daily_total_reg++;                                  // 全院总挂号数+1
	
	// 更新医生当日挂号数
	int doc_hash = hash_doctor_id(doctorID);
	doc_reg_count[doc_hash]++;
	
	// 更新患者当日挂号数
	int pat_hash = hash_patient_id(patientID);
	pat_reg_count[pat_hash]++;
	
	// 更新患者当日科室挂号数（用于同科室限号校验）
	int dept_idx = get_dept_index(doctor->department);
	pat_dept_reg[pat_hash][dept_idx]++;
	
	// ==================== 10. 输出挂号成功信息 ====================
	printf("\n线下挂号成功！\n");
	printf("挂号单号：%s\n", recordID);
	printf("就诊科室：%s\n", doctor->department);
	printf("就诊医生：%s\n", doctor->name);
	printf("当前时间：%d-%02d-%02d %02d:%02d\n", 
		   visit_time.year, visit_time.month, visit_time.day,
		   visit_time.hour, visit_time.minute);
	printf("当前状态：候诊\n");
	printf("请耐心等待叫号...\n");
	
	return true;
}


/*============================线上挂号系统=====================================*/

void online_registration_system(Doctor **head_D0, Patient **head_P0, Consultation **head_C0, 
								char *patientID) {
	Doctor *head_D = *head_D0;
	Patient *head_P = *head_P0;
	Consultation *head_C=*head_C0;
	
	printf("\n========== 线上自助挂号 ==========\n");
	
	
	//现在不在挂号时间判断，不在时间就直接退出
	
	Patient *patient = find_patient(patientID, head_P);
	if(patient == NULL) {
		printf(" 患者信息异常！\n");
		return;
	}
	
	// 检查个人信息是否完善（这个比较总要所以要完善）
	if(strlen(patient->Emergency_contact) == 0 || 
	   strlen(patient->Emergency_contact_phonenumber) == 0) {
		printf(" 您的紧急联系人信息不完整，请先完善信息\n");
		change_emergency_connection_information(head_P0, patientID);
	}
	
	//算出明天的时间
	DateTime current_time = get_current_time();
	//不在规定时间内挂号的用户，退出系统；
	int current_minutes = current_time.hour*60+current_time.minute;
	int T_11_30_minutes=11*60+30;
	int T_19_00_minutes=19*60;
	if((current_minutes<T_19_00_minutes)&&(current_minutes>T_11_30_minutes)) {
		printf("放号规则：每晚19:00开放次日号源，截止至次日11:30\n");
		printf("正在退出线上挂号...\n");
		return;
	}
	DateTime tomorrow = current_time;
	//处理对应的预约时间：晚上就把时间调到下一天，否则时间就不变
	if(tomorrow.hour<12);
	else {
		int month[13]={0,31,28,31,30,31,30,31,31,30,31,30};
		int year=tomorrow.year;
		if((year%4==0&&year%100!=0)||year%400==0)month[2]=29;
		if(++tomorrow.day>month[tomorrow.month]){
			tomorrow.month++;
			tomorrow.day=1;
			if(tomorrow.month==13){
				tomorrow.year++;
				tomorrow.month=1;
			}
		}
	}
	
	printf("将要预约%d-%d-%d的号源\n",tomorrow.year,tomorrow.month,tomorrow.day);
	//选择科室
	char dept_name[20];
	printf("1.普通内科 2.骨科 3.妇产科\n");
	printf("4.儿科 5.急诊科 6.影像科 7.医学检验科(化验)\n");
	int choice;
	int sure=0;
	while(sure==0){
		while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5&&choice!=6&&choice!=7)){
			while (getchar() != '\n');	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("请输入正确的选项：\n");
		}
		switch (choice) {
			case 1:strcpy( dept_name,"普通内科");break;
			case 2:strcpy( dept_name,"骨科");break;
			case 3:strcpy( dept_name,"妇产科");break;
			case 4:strcpy( dept_name,"儿科");break;
			case 5:strcpy( dept_name,"急诊科");break;
			case 6:strcpy( dept_name,"影像科");break;
			case 7:strcpy( dept_name,"医学检验科(化验)");break;
		}
		while (getchar() != '\n');	// 清除输入缓冲区垃圾（回车、多余字符）
		printf("你想要挂号的科室是:%s\n",dept_name);
		printf("确认请按：1   重新输入请按：0\n");
		while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
			while (getchar() != '\n');	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("请输入正确的选项：\n");
		}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
		while (getchar() != '\n');	// 清除输入缓冲区垃圾（回车、多余字符）
	}
	
	
	////////////////////
	///////////
	/////////
	//@@@到时候直接喂给AI让他帮我处理挂号，使得这个上午挂的号只能挂下午的号
	// 选择就诊时段
	printf("\n 请选择就诊时段：\n");
	printf("1. 上午（08:00-11:30）\n");
	printf("2. 下午（13:30-17:30）\n");
	printf("请输入选项：");
	int time_slot;
	while(scanf("%d", &time_slot)!=1||(time_slot!=1&&time_slot!=2)){
		printf("请输入正确选项：（1.上午/2.下午）\n");
	}
	
	clear_input_buffer();
	
	// 显示该科室明天值班的医生
	display_doctors_by_dept(head_D,head_C, dept_name, tomorrow,time_slot);
	printf("请选择医生工号（输入0退出挂号）:");
	char doc_id[20];
	fgets(doc_id, sizeof(doc_id), stdin);
	doc_id[strcspn(doc_id, "\n")] = 0;
	
	if(strcmp(doc_id,"0")==0){
		printf("正在退出线上挂号...\n");
		return ;
	}
	
	while(!find_doctor(doc_id,head_D)){
		printf("无法查找到对应医生，请重新输入工号：\n");
		fgets(doc_id, sizeof(doc_id), stdin);
		doc_id[strcspn(doc_id, "\n")] = 0;
	}
	
	clear_input_buffer();
	
	// 构建预约时间
	DateTime appointment_time;
	appointment_time.year = tomorrow.year;
	appointment_time.month = tomorrow.month;
	appointment_time.day = tomorrow.day;
	appointment_time.minute = 0;
	appointment_time.second = 0;
	appointment_time.hour = (time_slot == 1) ? 8 : 13;
	
	// 校验时间限制
	bool success = line_registration_with_time(head_D0,head_P0,head_C0, 
												  patientID, doc_id,dept_name,time_slot);
	
	if(success) {
		printf("\n 预约成功！请于 %d-%02d-%02d %s 前往医院就诊\n",
			   appointment_time.year, appointment_time.month, appointment_time.day,
			   time_slot == 1 ? "上午" : "下午");
	}
	else printf("挂号失败，正在返回系统主页\n");
	
	
	// 计算排队位置和预计就诊时间
	bool is_morning = (appointment_time.hour < 12);
	
	// 统计该医生该时段已有几人（包含自己）
	int position = 0;
	Consultation *c = *head_C0;
	while(c != NULL) {
		if(strcmp(c->doctorID, doc_id) == 0 &&
		   strcmp(c->status, "已撤销") != 0 &&
		   c->consultTime_start.year == appointment_time.year &&
		   c->consultTime_start.month == appointment_time.month &&
		   c->consultTime_start.day == appointment_time.day) {
			
			bool c_is_morning = (c->consultTime_start.hour >= 8 && c->consultTime_start.hour < 12);
			if(is_morning == c_is_morning) {
				position++;
				// 找到自己
				if(strcmp(c->patientID, patientID) == 0) {
					break;
				}
			}
		}
		c = c->next;
	}
	
	printf("就诊日期：%d-%02d-%02d\n", 
		   appointment_time.year, appointment_time.month, appointment_time.day);
	printf("就诊时段：%s\n", is_morning ? "上午 (8:00-11:30)" : "下午 (13:30-17:30)");
	printf("排队序号：第 %d 位\n", position);
	
	// 计算预计就诊时间
	int start_hour = is_morning ? 8 : 13;
	int start_minute = is_morning ? 0 : 30;
	int wait_minutes = (position - 1) * 8;
	int total_minutes = start_hour * 60 + start_minute + wait_minutes;
	int est_hour = total_minutes / 60;
	int est_minute = total_minutes % 60;
	
	printf("预计就诊时间：%02d:%02d（每位患者约8分钟）\n", est_hour, est_minute);
	printf("请提前10分钟到达医院候诊\n");//写挺好
}

/*==============================患者就诊记录查询===================================*/

void view_my_consultations(Consultation *head_C, char *patientID) {
	printf("\n========== 我的诊疗记录 ==========\n");
	
	Consultation *c = head_C;
	int count = 0;
	while(c != NULL) {
		if(strcmp(c->patientID, patientID) == 0) {
			count++;
			printf("\n--- 记录 %d ---\n", count);
			printf("挂号单号：%s\n", c->recordID);
			printf("就诊时间：%d-%02d-%02d %02d:%02d\n",
				   c->consultTime_start.year, c->consultTime_start.month,
				   c->consultTime_start.day, c->consultTime_start.hour,
				   c->consultTime_start.minute);
			printf("就诊医生：%s\n", c->doctorNAME);
			printf("主诉：%s\n", c->chiefComplaint);
			printf("诊断：%s\n", c->diagnosis);
			printf("处方：%s\n", c->prescription);
			printf("总费用：%.2f 元\n", c->cost);
			printf("状态：%s\n", c->status);
		}
		c = c->next;
	}
	
	if(count == 0) {
		printf("暂无诊疗记录\n");
	}
	printf("================================\n");
}

void view_my_hospitalization(Bed *head_B, char *patientID) {
	printf("\n========== 住院信息 ==========\n");
	
	Bed *b = head_B;
	int found = 0;
	while(b != NULL) {
		Admission_information *p=b->status;
		while(p!=NULL){
			if(p != NULL && strcmp(p->patient_id, patientID) == 0) {
				found = 1;
				printf("床位号：%s\n", b->bed_id);
				printf("科室：%s\n", b->department_name);
				printf("病房号：%s\n", b->Ward_number);
				printf("病房类型：%s\n", 
					   b->type == 1 ? "VIP病房" : (b->type == 2 ? "2人间" : "3人间"));
				printf("入院时间：%d-%02d-%02d %02d:%02d\n",
					   b->status->check_in.year, b->status->check_in.month,
					   b->status->check_in.day, b->status->check_in.hour,
					   b->status->check_in.minute);
				if(p->check_out.year==0)
					printf("住院中\n");
				else printf("出院时间：%d-%02d-%02d %02d:%02d\n",
							b->status->check_out.year, b->status->check_out.month,
							b->status->check_out.day, b->status->check_out.hour,
							b->status->check_out.minute);
				printf("主治医生ID：%s\n", b->status->doctor_id);
				printf("负责护士ID：%s\n", b->status->nurse_id);
				printf("当前押金：%.2f 元\n", b->status->ya_cash);
				printf("每日费用：%.2f 元\n", b->daily_cost);
			}
			p=p->next;
		}
		b = b->next;
	}
	
	if(!found) {
		printf("您当前未住院\n");
	}
	printf("===============================\n");
}

//修改密码函数
// 修改患者登录密码
void change_login_passport(Patient *head_P, char *PatientID) {
	printf("\n========== 修改登录密码 ==========\n");
	
	// 1. 查找患者是否存在
	Patient *p = head_P;
	while (p != NULL) {
		if (strcmp(p->patientID, PatientID) == 0) {
			break;
		}
		p = p->next;
	}
	
	if (p == NULL) {
		printf("未找到您的信息，无法修改密码！\n");
		return;
	}
	
	// 2. 验证旧密码
	char old_pwd[20];
	printf("请输入当前旧密码：");
	scanf("%s", old_pwd);
	
	if (strcmp(p->login_password, old_pwd) != 0) {
		printf(" 旧密码错误，修改失败！\n");
		return;
	}
	printf(" 旧密码验证成功！\n");
	
	// 3. 输入新密码
	char new_pwd[20];
	printf("请输入新密码：");
	scanf("%s", new_pwd);
	
	// 4. 确认新密码
	char confirm_pwd[20];
	printf("请再次输入新密码：");
	scanf("%s", confirm_pwd);
	
	if (strcmp(new_pwd, confirm_pwd) != 0) {
		printf(" 两次输入的新密码不一致，修改失败！\n");
		return;
	}
	
	// 5. 修改密码
	strcpy(p->login_password, new_pwd);
	printf(" 密码修改成功！请牢记新密码！\n");
}

//这个函数的意思是计算某个病人所有的诊疗记录的总开销，不算住院费用
float get_medical_fee(Consultation *head_C, char *patientID) {
	float total = 0.0;
	Consultation *c = head_C;
	while(c != NULL) {
		if(strcmp(c->patientID, patientID) == 0 &&
		   (strcmp(c->status, "已完成") == 0 || strcmp(c->status, "已住院") == 0)) {
			total += c->cost;
		}
		c = c->next;
	}
	return total;
}


/*===========================患者系统主函数===================================*/

void patient_system(char *PatientID,Doctor **head_D0,Patient **head_P0,Nurse **head_N0,Medicine **head_M0,Bed **head_B0,Consultation **head_C0)
{

	Patient *current_patient = find_patient(PatientID,*head_P0);
	if(current_patient == NULL)
	{
		printf(" 患者信息错误！\n");
		return;
	}
	
	printf("\n欢迎，%s!\n",current_patient->name);
	
	int choice;
	while(1) 
	{
		printf("\n========== 患者系统 ==========\n");
		printf("1. 线上自助挂号\n");
		printf("2. 查看我的诊疗记录\n");
		printf("3. 查看住院信息\n");
		printf("4. 查看个人信息\n");
		printf("5. 修改紧急联系人\n");
		printf("6. 修改手机号码\n");
		printf("7. 修改登录密码\n");
		printf("0. 退出患者系统\n");
		printf("==================================\n");
		printf("请输入操作选项：");
		
		if(scanf("%d",&choice) != 1)
		{
			clear_input_buffer();
			printf("输入无效，请重新选择\n");
			return;
		}
		clear_input_buffer();
		
		switch(choice)
		{
		case 1:
			online_booking_flow(head_D0, head_P0,
								head_C0, PatientID);
			break;
		case 2:
			view_my_consultations(*head_C0,PatientID);
			break;
		case 3:
			view_my_hospitalization(*head_B0,PatientID);
			break;
		case 4:
			display_patient_info(current_patient);
			break;
		case 5:
			change_emergency_connection_information(head_P0,PatientID);
			current_patient = find_patient(PatientID,*head_P0);
			break;
		case 6:
			change_phonenumber(head_P0,PatientID);
			current_patient = find_patient(PatientID,*head_P0);
			break;
		case 7:
			change_login_passport(*head_P0,PatientID);
			break;
		case 0:
			printf("正在退出患者系统...\n");
			return;
		default:
			printf("无效选项，请重新选择");
		}
	}
}	


