#ifndef F4_H
#define F4_H
#include"HMS.h"


// ===================== 全局加载/保存 =====================
void load_all_data(Doctor **head_D,Patient **head_P,Medicine **head_M,Consultation **head_C,Nurse **head_N,Administrator **head_A,Bed **head_B,ExaminationItem **red,ExaminationItem **lab,int choice);
void save_all_data(Doctor *head_D0,Patient *head_P0,Medicine *head_M0,Consultation *head_C0,Nurse *head_N0,Bed *head_B0,ExaminationItem *red,ExaminationItem *lab,int choice);

//=========================检查项目==========================
/* -------------- 单个链节创建 ------------- */
ExaminationItem* create_node(int id, int dept_id, const char* code, 
							 const char* name, double price, 
							 const char* unit, int status);
void insert_tail(ExaminationItem **head, ExaminationItem *node);//链接新生成的数据点和链表
//=================保存数据===============
int save_to_file(ExaminationItem *head, const char *filename);
//==============读取数据================
ExaminationItem* load_from_file(const char *filename);



// ===================== 医生 =====================
Doctor *doctor_maker(char *name_0,int age_0,char *id_card_number_0,char *gender_0,char *phone_number_0,date birthday_0,char *department_0,char *staff_id_0,char *login_password_0,char *job_title_0,int staff_status_0,int (*schedule_0)[3],Doctor *previous);
void load_doctors_from_file(Doctor **head_D);
void save_doctors_to_file(Doctor *head_D);

// ===================== 护士 =====================
Nurse *nurse_maker(char *name_0,int age_0,char *id_card_number_0,char *gender_0,char *phone_number_0,date birthday_0,char *department_0,char *staff_id_0,char *login_password_0,char *job_title_0,int responsible_number_0,int staff_status_0,int (*schedule_0)[3],Nurse *previous);
void loadNurseFromFile(Nurse **head_N);
void saveNurseToFile(Nurse *head_N);

// ===================== 床位 + 住院记录 =====================
Bed *bed_all_maker(char *department_name_0,char *bed_id_0,int type_0,char *Ward_number_0,int order_0,float daily_cost_0,Bed *previous);//单节点创建
void loadBedFromFile(Bed **head_B);//读取床位基本信息
void saveBedToFile(Bed *head_B);//保存床位基本信息
void loadAdmissionHistoryFromFile(Bed *head_B);//读取住院信息
void saveAdmissionHistoryToFile(Bed *head_B);//保存住院信息

// ===================== 管理员 =====================
Administrator *administrator_maker(char *name_0,char *staff_id_0,char *login_password_0,Administrator *previous);//单节点创建
void loadAdministratorFromFile(Administrator **head_A);//读取管理员信息
void saveAdministratorToFile(Administrator *head_A);//保存管理员信息

// ===================== 药品 =====================

// ===================== 从 medicine.txt 读取药品基础信息 =====================
void loadMedicineFromFile(Medicine **head_M);
// ------------ 保存药品基础信息到 medicine.txt ------------
void saveMedicineToFile(Medicine *head_M);

// ===================== 从 medicine_io.txt 读取出入库记录并关联到药品 =====================
void loadMedicineIOFromFile(Medicine *head_M);
// ----------- 保存出入库记录到 medicine_io.txt ------------
void saveMedicineIOToFile(Medicine *head_M);

// ===================== 诊疗记录 =====================
void loadConsultationFromTxt(char *file,Consultation **head);
void saveConsultationToTxt(char *file,Consultation *head);

// ===================== 病人 =====================
void loadPatientFromFile(Patient **head_P);
void savePatientToFile(Patient *head_P);
#endif
