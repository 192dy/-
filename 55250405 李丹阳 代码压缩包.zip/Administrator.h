#ifndef Administritor_H
#define Administritor_H
#include"HMS.h"


/*=====================构建超级管理员系统✅️Administrator.c=====================*/
void administrator_system(char *AdministratorID,Doctor **head_D0,Patient **head_P0,Medicine **head_M0,Consultation **head_C0,Nurse **head_N0,Administrator **head_A0,Bed **head_B0);


/*-----------辅助函数（公用）-------------*/


bool check_name(char* name);//检查这个姓名里有没有数字和|||这些非法的符号✅️Administrator.c

bool check_id_card_number(char *id_card);//检查这个身份证号是否合理即除了0-9和X其他的都不要；✅️Administrator.c

bool check_phone_number(char *phone_number);//检查这个电话号码是否合理✅️Administrator.c



//功能全封装，完成功能在函数末尾提示“....功能已完成”




/*——————————————————————————————————————————————药品管理————————————————————————————————————————————————*/
// 模糊查询药品（按 药名 匹配）
// 返回值：匹配结果的数量；results：输出匹配的药品列表（需提前分配内存）
int fuzzy_search_medicine_administraror(Medicine *head, const char *keyword, Medicine **results, int max_results);

// 展示模糊查询结果并让用户选择
// 返回值：用户选中的医生节点（NULL表示取消/退出）
Medicine *select_medicine_by_fuzzy_search(Medicine *head);

void check_signal_medicine_status(Medicine *head_M);//辅助函数：处理单个药品过期的情况✅️Administrator.c


void add_new_kind_medicine(char *AdministratorID,Medicine **head_M);//增加新品种的药✅️Administrator.c

void add_medicine_stock(char *AdministratorID,Medicine *head_M);//增加某种已有药品的数量✅️Administrator.c
/*————————————————————————————————————————————————————————————————————————————————————————————————————————*/



/*-————————————————————————————————————————————————————————————————————————— 财政or流水管理—————————————————————————————————————————————————————————————————————————*/
/*--辅助函数--*/
float calculate_period_revenue(Consultation *head_C, Bed *head_B,Medicine *head_M,DateTime detect_time);//计算单个时间点的费用✅️Administrator.c 
/*--主函数--*/
void calculate_total_revenue(Consultation *head_C, Bed *head_B,Medicine *head_M);// 统计总营业额（可以按照日/周/月来进行统计）//在内部输入时间然后利用时间函数来操作✅️Administrator.c

/*--辅助函数--*/
// 1. date转DateTime（默认时分秒为0）
DateTime date_to_datetime(date day, int hour, int minute, int second);
// 辅助函数：得到date对应的星期几（逻辑不变，仅参数更清晰）
int Get_current_day_of_the_week(date day);
/*---------------*/


/*=====================*/
/*辅助函数：统计医生总流水（统计单个时间点之前所有的流水）✅️Administrator.c*/
float calculate_period_revenue_doctor(Consultation *head_C, Bed *head_B,DateTime detect_time,char *DoctorID);
/*--主函数--*/
void Transaction_History_of_doctor(Consultation *head_C, Bed *head_B,Doctor *head_D);//统计每位医生一段时间内的流水✅️Administrator.c
/*=====================*/



/*=====================*/
/*辅助函数：统计科室总流水（统计单个时间点之前所有的流水）✅️Administrator.c*/
float calculate_period_revenue_department(Consultation *head_C, Bed *head_B,DateTime detect_time,char *departmentID);

void Transaction_History_of_department(Consultation *head_C, Bed *head_B,Medicine *head_M);//统计每个科室一段时间内的流水✅️Administrator.c
/*=====================*/


/*——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————*/



/*—————————————————————————————————————————————————————————————————————————工作效益统计 —————————————————————————————————————————————————————————————————————————*/
//辅助函数1：
void count_the_business_of_the_doctor(Consultation *head_C,Doctor *head_D,Doctor *D,date day);//统计某位医生一天繁忙程度（接诊量 / 限号数）实际上采用了日期+（接诊量 / 限号数）+百分比+程度评价的方式✅️Administrator.c
//辅助函数2：
int Get_current_day_of_the_week(date day);//得到date对应的日期是多少；✅️Administrator.c
//辅助函数3：
date day_add_one(date day);//计算day+1后对应的日期；✅️Administrator.c

int count_recipient_of_doctor(Doctor *head_D);//统计每位医生接诊量✅️Administrator.c//算出这个医生总的接诊量（默认这段时间医生的值班表没有发生改变）；
//功能函数1：
void Doctor_recepient_Patient_Count(Consultation *head_C,Doctor *head_D);//统计指定医生指定日期接诊量\n✅️Administrator.
//功能函数2:
void count_days_business_of_the_doctor(Consultation *head_C,Doctor *head_D);//统计医生一段时间的工作繁忙程度✅️Administrator.cc
//功能函数3：
void print_hospitalized_report(Bed *head_B,Patient *head_P,Doctor *head_D,Nurse *head_N);// 生成住院患者报表，生成住院患者报表：床位：患者：主治医生：科室




/*——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————*/


/*—————————————————————————————————————————————————————————————————————————医生管理—————————————————————————————————————————————————————————————————————————*/
/*辅助1：*/
// 模糊查询医生（按 工号/姓名/科室 匹配）
// 返回值：匹配结果的数量；results：输出匹配的医生列表（需提前分配内存）
int fuzzy_search_doctor(Doctor *head, const char *keyword, Doctor **results, int max_results);
/*辅助2：*/
// 展示模糊查询结果并让用户选择
// 返回值：用户选中的医生节点（NULL表示取消/退出）
Doctor *select_doctor_by_fuzzy_search(Doctor *head);

bool check_staff_id_doctor(char *staff_id,Doctor *head_D);//检验医生工号有没有和其他医生的工号重复✅️Administrator.c


void update_doctor_title(Doctor *head_D);//修改多名医生职称✅️Administrator.c

void update_D_schedule(Doctor *head_D);//修改医生值班表✅️Administrator.c

void add_new_doctor(Doctor **head_D);//添加新医生✅️Administrator.c

void change_status_doctor(Doctor *head_D);//修改医生在职状态：在职，离职，休假✅️Administrator.c

void change_department_doctor(Doctor *head_D);//修改医生所在的科室✅️Administrator.c

/*——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————*/



/*—————————————————————————————————————————————————————————————————————————护士管理—————————————————————————————————————————————————————————————————————————*/
// 模糊查询护士（按 工号/姓名/科室 匹配）
// 返回值：匹配结果的数量；results：输出匹配的护士列表（需提前分配内存）
int fuzzy_search_nurse(Nurse *head, const char *keyword, Nurse **results, int max_results);

// 展示模糊查询结果并让用户选择
// 返回值：用户选中的护士节点（NULL表示取消/退出）
Nurse *select_nurse_by_fuzzy_search(Nurse *head);

bool check_staff_id_nurse(char *staff_id,Nurse *head_N);//检验护士工号有没有和其他护士的工号重复✅️Administrator.c

void update_nurse_title(Nurse *head_N);//修改多名护士职称✅️Administrator.c

void update_N_schedule(Nurse *head_N);//修改护士值班表✅️Administrator.c

void add_new_nurse(Nurse *head_N);//添加新护士✅️Administrator.c

void change_status_nurse(Nurse *head_N);//修改护士在职状态✅️Administrator.c

void change_department_nurse(Nurse *head_N);//修改护士所在的科室✅️Administrator.c
/*——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————————*/


















/*-----------------------------------药品-----------------------------------------*/



#endif
