#include"HMS.h"
#include"Doctor.h"
#include"Patient.h"
#include"Administrator.h"
#include"Nurse.h"
#include"widely_used.h"
#include"F4.h"
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<stdbool.h>

void administrator_system(char *AdministratorID,Doctor **head_D0,Patient **head_P0,Medicine **head_M0,Consultation **head_C0,Nurse **head_N0,Administrator **head_A0,Bed **head_B0){
	Doctor *head_D=*head_D0;
	Patient *head_P=*head_P0;
	Medicine *head_M=*head_M0;
	Consultation *head_C=*head_C0;
	Nurse *head_N=*head_N0;
	Administrator *head_A=*head_A0;
	Bed *head_B=*head_B0;
	Administrator *A=find_administrator(AdministratorID,head_A);
	printf("欢迎进入管理员系统%s\n",A->name);
	
	while(1){//一级菜单
		printf("===== 管理员系统 =====\n");
		printf("1. 药品管理\n");
		printf("2. 人员管理\n");
		printf("3. 财政or流水管理\n");
		printf("4. 工作效益统计\n");
		printf("0. 退出管理员系统\n");
		printf("=======================\n");
		printf("请输入操作选项：");
		int choice;
		//选项确认操作
		while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=0)){
			printf("请输入正确的操作选项：\n");
			while(getchar()!='\n');//清掉错误输入
		}
		while(getchar()!='\n');//吃掉回车
		
		/*----进入药品管理区----*/
		while(choice==1){
			printf("===== 药品管理 =====\n");
			printf("1. 进新药（新增药品种类）\n");
			printf("2. 增加已有药品数量（补货）\n");
			printf("0. 返回上一级菜单\n");
			printf("=====================\n");
			printf("请输入操作选项：");
			int option;
			while(scanf("%d",&option)!=1||(option!=1&&option!=2&&option!=0)){
				printf("请输入正确的操作选项\n");
				while(getchar()!='\n');
			}
			while(getchar()!='\n');
			
			switch(option){
				case 1:add_new_kind_medicine(AdministratorID,head_M0);
				printf("操作完成！\n");
				break;
				case 2:add_medicine_stock(AdministratorID,*head_M0);
				printf("操作完成！\n");
				break;
			case 0:
				printf("正在返回上一级菜单...\n");
				choice=-1;//跳出药品管理while
				break;
			}
		}
		
		/*----进入人员管理区----*/		
		while(choice==2){
			printf("===== 人员管理 =====\n");
			printf("1. 医生管理\n");
			printf("2. 护士管理\n");
			printf("0. 返回上一级菜单\n");
			printf("===================\n");
			printf("请输入操作选项：");
			int option;
			while(scanf("%d",&option)!=1||(option!=1&&option!=2&&option!=0)){
				printf("请输入正确的操作选项\n");
				while(getchar()!='\n');
			}
			while(getchar()!='\n');
			
			/*----医生管理----*/
			while(option==1){
				printf("===== 医生管理 =====\n");
				printf("1. 修改医生职称\n");
				printf("2. 调整医生工作表（排班）\n");
				printf("3. 修改医生在职状态（在职or离职or休假）\n");
				printf("4. 添加新的医生信息\n");
				printf("5. 修改医生所在科室\n");
				printf("0. 返回上一级菜单\n");
				printf("===================\n");
				printf("请输入操作选项：");
				int select;
				while(scanf("%d",&select)!=1||(select!=1&&select!=2&&select!=3&&select!=4&&select!=5&&select!=0)){
					printf("请输入正确的操作选项\n");
					while(getchar()!='\n');
				}
				while(getchar()!='\n');
				
				switch(select){
					case 1: update_doctor_title(*head_D0);
					printf("操作完成！\n");
					break;
					case 2: update_D_schedule(*head_D0);
					printf("操作完成！\n");
					break;
					case 3: change_status_doctor(*head_D0);
					printf("操作完成！\n");
					break;
					case 4: add_new_doctor(head_D0);
					printf("操作完成！\n");
					break;
					case 5: change_department_doctor(*head_D0);
					printf("操作完成！\n");
					break;
				case 0:
					printf("正在返回人员管理菜单...\n");
					option=-1;//跳出医生管理while
					break;
				}
			}
			
			/*----护士管理----*/
			while(option==2){
				printf("===== 护士管理 =====\n");
				printf("1. 添加新的护士信息\n");
				printf("2. 调整护士工作表（排班）\n");
				printf("3. 修改护士在职状态（在职or离职or休假）\n");
				printf("4. 修改护士职称\n");
				printf("5. 修改护士所在科室\n");
				printf("0. 返回上一级菜单\n");
				printf("===================\n");
				printf("请输入操作选项：");
				int select;
				while(scanf("%d",&select)!=1||(select!=1&&select!=2&&select!=3&&select!=4&&select!=5&&select!=0)){
					printf("请输入正确的操作选项\n");
					while(getchar()!='\n');
				}
				while(getchar()!='\n');
				
				switch(select){
					case 1: add_new_nurse(*head_N0);
					printf("操作完成！\n");
					break;
					case 2: update_N_schedule(*head_N0);
					printf("操作完成！\n");
					break;
					case 3: change_status_nurse(*head_N0);
					printf("操作完成！\n");
					break;
					case 4: update_nurse_title(*head_N0);
					printf("操作完成！\n");
					break;
					case 5: change_department_nurse(*head_N0);
					printf("操作完成！\n");
					break;
				case 0:
					printf("正在返回人员管理菜单...\n");
					option=-1;//跳出护士管理while
					break;
				}
			}
			if(option==0){
				printf("正在返回管理员系统主菜单...\n");
				choice=-1;//跳出人员管理while
			}
		}
		/*----进入财政or流水管理区----*/	
		while(choice==3){
			printf("===== 财政or流水管理 =====\n");
			printf("1. 查看全院周or月or年总流水\n");
			printf("2. 查看指定医生指定日期流水\n");
			printf("3. 查看指定科室指定日期流水\n");
			printf("0. 返回上一级菜单\n");
			printf("=========================\n");
			printf("请输入操作选项：");
			int option;
			while(scanf("%d",&option)!=1||(option!=1&&option!=2&&option!=3&&option!=0)){
				printf("请输入正确的操作选项\n");
				while(getchar()!='\n');
			}
			while(getchar()!='\n');
			
			switch(option){
				case 1: calculate_total_revenue(head_C,head_B,head_M);
				printf("操作完成！\n");
				break;
				case 2: Transaction_History_of_doctor(head_C,head_B,head_D);
				printf("操作完成！\n");
				break;
				case 3: Transaction_History_of_department(head_C,head_B,head_M);
				printf("操作完成！\n");
				break;
			case 0:
				printf("正在返回上一级菜单...\n");
				choice=-1;//跳出财政管理while
				break;
			}
		}
		
		/*----进入工作效益统计区----*/	
		while(choice==4){
			printf("===== 工作效益统计 =====\n");
			printf("1. 统计指定医生指定日期接诊量\n");
			printf("2. 统计指定医生繁忙程度（接诊量or限号数）\n");
			printf("3. 生成住院患者报表\n");
			printf("0. 返回上一级菜单\n");
			printf("=========================\n");
			printf("请输入操作选项：");
			int option;
			while(scanf("%d",&option)!=1||(option!=1&&option!=2&&option!=3&&option!=0)){
				printf("请输入正确的操作选项\n");
				while(getchar()!='\n');
			}
			while(getchar()!='\n');
			
			switch(option){
				case 1: Doctor_recepient_Patient_Count(head_C,head_D);
				printf("操作完成！\n");
				break;
				case 2: count_days_business_of_the_doctor(head_C,head_D);
				printf("操作完成！\n");
				break;
				case 3: print_hospitalized_report(head_B,head_P,head_D,head_N);
				printf("操作完成！\n");
				break;
			case 0:
				printf("正在返回上一级菜单...\n");
				choice=-1;//跳出工作效益统计while
				break;
			}
		}
		
		if(choice==0){
			printf("正在退出管理员系统...\n");
			break;
		}
	}
}



/*--------------------工作效益统计 -------------------------*/

void print_hospitalized_report(Bed *head_B, Patient *head_P, Doctor *head_D, Nurse *head_N) {
	printf("\n========== 床位完整信息 ==========\n");
	Bed *B = head_B;
	
	while (B != NULL) {
		// 1. 先打印床位基本信息（每个床位都要有这个）
		printf("床位号：%s | 类型：%s | 科室：%s | 日费：%.2f\n",
			   B->bed_id,
			   B->type == 1 ? "VIP" : (B->type == 2 ? "2人间" : "3人间"),  // ← 这里改 B->type
			   B->department_name,
			   B->daily_cost);
		
		Admission_information *bed = B->status;
		int has_patient = 0;  // 标记是否有人住
		
		// 2. 遍历该床位所有历史住院记录
		while (bed != NULL) {
			if (bed->check_out.year == 0) {
				// 找到一条没出院的记录 = 当前有人住
				has_patient = 1;
				
				// 查患者
				Patient *pat = find_patient(bed->patient_id, head_P);
				if (pat) {
					printf("\n  ----- 患者信息 -----\n");
					printf("  病历号：%s | 姓名：%s | 性别：%s | 年龄：%d | 电话：%s\n",
						   pat->patientID, pat->name, pat->gender, pat->age, pat->phonenumber);
				}
				
				// 查医生
				Doctor *doc = find_doctor(bed->doctor_id, head_D);
				if (doc) {
					printf("\n  ----- 主治医生 -----\n");
					printf("  工号：%s | 姓名：%s | 性别：%s | 电话：%s\n",
						   doc->staff_id, doc->name, doc->gender, doc->phone_number);
					printf("  科室：%s | 职称：%s\n",
						   doc->department, doc->job_title);
				}
				
				// 查护士
				Nurse *nur = find_nurse(bed->nurse_id, head_N);
				if (nur) {
					printf("\n  ----- 负责护士 -----\n");
					printf("  工号：%s | 姓名：%s | 性别：%s | 年龄：%d | 电话：%s\n",
						   nur->staff_id, nur->name, nur->gender, nur->age, nur->phone_number);
					printf("  科室：%s\n", nur->department);
				}
				
				// 住院信息
				printf("\n  ----- 住院信息 -----\n");
				printf("  入院时间：%d-%02d-%02d | 押金余额：%.2f 元\n",
					   bed->check_in.year, bed->check_in.month, bed->check_in.day,
					   bed->ya_cash);
				
				break;  // 找到当前入住的了，后面不用再看
			}
			bed = bed->next;
		}
		
		// 3. 遍历完所有记录，都没找到 check_out.year == 0 的
		if (!has_patient) {
			printf("  状态：空闲\n");
		}
		
		printf("\n----------------------------------------\n");
		B = B->next;
	}
}


//辅助函数1：统计某位医生一天繁忙程度（接诊量 / 限号数）
void count_day_business_of_the_doctor(Consultation *head_C,Doctor *head_D,Doctor *D,date day){
	int Patient_Volume_0=0;
	int check_number=0;
	//得到今天是星期几
	int the_day_of_the_week=Get_current_day_of_the_week(day);
	//算出这个医生总的接诊量（默认这段时间医生的值班表没有发生改变）；
	if(D->schedule[the_day_of_the_week][0]==1)Patient_Volume_0+=Patient_Volume;
	if(D->schedule[the_day_of_the_week][1]==1)Patient_Volume_0+=Patient_Volume;
	//开始计算这一天他看了多少个病人；
	Consultation *p=head_C;
	while(p!=NULL){
		
		if(strcmp(D->staff_id,p->doctorID)==0&&p->consultTime_start.year==day.year&&p->consultTime_start.month==day.month&&p->consultTime_start.day==day.day//确认病人看诊的时间是这一天
		   &&strcmp(p->status,"已撤销")!=0)//确保这条诊疗记录有效
		{
			check_number++;
		}
		p=p->next;
	}
	//计算医生的忙碌情况(百分比只包含%前的数值)
	float business_percent=0;
	if(Patient_Volume_0==0) business_percent=0;
	else business_percent=check_number/(float)Patient_Volume_0*100;
	//记录医生的繁忙程度
	char busy_extent[10];
	if(business_percent>=80)strcpy(busy_extent,"高");
	else if(business_percent>=50)strcpy(busy_extent,"中等");
	else if(business_percent==0)strcpy(busy_extent,"休息中");
	else strcpy(busy_extent,"轻松");
	printf("|  %02d-%02d-%02d   |    %03d/%03d    |    %0.2f%%     |      %s     |\n",day.year,day.month,day.day,check_number,Patient_Volume_0,business_percent,busy_extent);
	printf("|_______________________________________________________________|\n");
	
}

//计算day+1后对应的日期
date day_add_one(date day){
	//定义好所有的月份的天数
	int monthly[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	//处理好闰年的情况
	if((day.year%4==0&&day.year%100!=0)||day.year%400==0) monthly[2]=29;
	//加一天如果超过月份最多的天数，月份加一，天数为1；
	if(++day.day>monthly[day.month]){
		day.month++;
		day.day=1;
	}
	if(day.month>12){
		day.month=1;
		day.year++;
	}
	return day;
}
//主函数：统计医生一段时间的工作繁忙程度
void count_days_business_of_the_doctor(Consultation *head_C,Doctor *head_D){
	//输入两个时间段，调用函数算出对应时间点的总营业额再想减，最后要防止输入时间超过实际时间的问题(天)；
	//完成初始化使起始时间是从一天的凌晨开始，结束时间是在一天的23.59.59结束
	DateTime initial;
	DateTime final;
	//初始化好时间跨度：确保当天所有的诊疗记录都被包含在内；
	initial.hour=initial.minute=initial.second=0;
	final.hour=23;final.minute=59;final.second=59;
	//输入医生工号
	int number = 1;
	while (number) {
		// 1. 模糊查询选择医生
		Doctor *target= select_doctor_by_fuzzy_search(head_D);
		if (target == NULL) { // 用户取消查询
			break;
		}
		int sure=0;
		while(sure==0){
			//输入查询时间段：默认是起始是从0:00:00开始，结束是在23:59:59；
			printf("请输入你想要查询的时间段\n");
			
			printf("请输入起始时间点(按照：年.月.日  的格式输入)：\n");
			while(1){
				if(scanf("%d.%d.%d",&initial.year,&initial.month,&initial.day)==3&&check_weather_surpuss_1(initial)) break;
				if(check_weather_surpuss_1(initial)==false){
					clear_input_buffer();
					printf("输入时间尚未发生请重新输入：\n");	
				} 
				else
					printf("请输入你想要输入时间点1对应的数字:\n");
			}
			
			printf("请输入终止时间点(按照：年.月.日  的格式输入):\n");
			while(1){
				if(scanf("%d.%d.%d",&final.year,&final.month,&final.day)==3&&check_weather_surpuss_1(final)) break;
				if(check_weather_surpuss_1(final)==false){
					clear_input_buffer();				
					printf("输入时间尚未发生请重新输入：\n");
				}
				else
					printf("请输入你想要输入时间点2对应的数字:\n");
			}
			if(constract_two_days(final,initial)!=true){
				printf("输入的结束时间点早于开始时间点,请重新输入\n");
			}
			else{
				printf("你输入的时间段是%d.%d.%d--%d.%d.%d\n",
					   initial.year,initial.month,initial.day,
					   final.year,final.month,final.day);
				//固定让用户确认输入操作
				printf("确认请按：1  重新输入请按：0\n");
				while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
					printf("请输入正确的选项：\n");
					clear_input_buffer();
				}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
				clear_input_buffer();
			}
		}
		
		
		//上面的是用来得到起止时间和医生的工号：
		//下面来输出：日期 ，接诊量/限号量，繁忙程度，工作强度评价
		printf("/------------------%s医生的忙碌情况-----------------/\n",target->name);
		printf("|     %s      | %s |    %s   |  %s |\n","日期","接诊量/限号量","繁忙程度","工作强度评价");
		printf("|_______________________________________________________________|\n");
		date day;
		day.year=initial.year;
		day.month=initial.month;
		day.day=initial.day;
		DateTime temp=initial;
		while(constract_two_days(final,temp)){
			count_day_business_of_the_doctor(head_C,head_D,target,day);
			day=day_add_one(day);//下一天
			temp=date_to_datetime(day,0,0,0);//把已经移动到下一天的日期转换为秒精度，便于和截止日期比较，同时加上了时间00:00:00从而使得final和temp（中间过渡变量）是同一天也能统计这天的看诊数量；
			
		}
		
		printf("已成功统计该名医生的工作繁忙程度，是否继续查询其他医生的工作繁忙程度?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			printf("请输入正确的操作选项\n");
			clear_input_buffer();
		}
		
		
	}
	
}



//1. 统计指定医生指定日期接诊量\n
void Doctor_recepient_Patient_Count(Consultation *head_C,Doctor *head_D){
	
	//输入两个时间段，调用函数算出对应时间点的总营业额再想减，最后要防止输入时间超过实际时间的问题(天)；
	//完成初始化使起始时间是从一天的凌晨开始，结束时间是在一天的23.59.59结束
	DateTime initial;
	DateTime final;
	//初始化好时间跨度：确保当天所有的诊疗记录都被包含在内；
	initial.hour=initial.minute=initial.second=0;
	final.hour=23;final.minute=59;final.second=59;
	int number = 1;
	while (number) {
		int count=0;//初始化总接诊量
		// 1. 模糊查询选择医生
		Doctor *target= select_doctor_by_fuzzy_search(head_D);
		if (target == NULL) { // 用户取消查询
			break;
		}
		int sure=0;
		while(sure==0){
			//输入查询时间段：默认是起始是从0:00:00开始，结束是在23:59:59；
			
			printf("请输入你想要查询的时间段\n");
			printf("请输入起始时间点(按照：年.月.日  的格式输入)：\n");
			while(1){
				if(scanf("%d.%d.%d",&initial.year,&initial.month,&initial.day)==3&&check_weather_surpuss_1(initial)) break;
				if(check_weather_surpuss_1(initial)==false){
					clear_input_buffer();
					printf("输入时间尚未发生请重新输入：\n");
				}
				else
					printf("请输入你想要输入时间点1对应的数字:\n");
			}
			clear_input_buffer();
			printf("请输入终止时间点(按照：年.月.日  的格式输入):\n");
			while(1){
				if(scanf("%d.%d.%d",&final.year,&final.month,&final.day)==3&&check_weather_surpuss_1(final)) break;
				if(check_weather_surpuss_1(final)==false){
					clear_input_buffer();
					printf("输入时间尚未发生请重新输入：\n");
				}
				else
					printf("请输入终止时间点:\n");
			}
			if(constract_two_days(final,initial)!=true){
				printf("输入的结束时间点早于开始时间点,请重新输入\n");
			}
			else{
				printf("你输入的时间段是%d.%d.%d--%d.%d.%d\n",
					   initial.year,initial.month,initial.day,
					   final.year,final.month,final.day);
				//固定让用户确认输入操作
				printf("确认请按：1  重新输入请按：0\n");
				while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
					printf("请输入正确的选项：\n");
					clear_input_buffer();
				}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
				clear_input_buffer();
			}
		}
		
		//就是从head_C直接开始遍历
		//@要确定是这个医生
		//@我还要确定这个病人是在我检索的这个时间段里被接诊的,起始时间<=病人看诊时间<=结束时间，一般就是输入两个时间段，这个就精确到天数就可以了
		Consultation *c = head_C;
		while(c != NULL){
			if(strcmp(c->doctorID, target->staff_id) == 0 
			   && constract_two_days(c->consultTime_start, initial)
			   && constract_two_days(final, c->consultTime_end))
				count++;
			c = c->next;
		}
		
		printf("%s医生在%d.%d.%d--%d.%d.%d时间段内接诊的患者数量为:%d\n",target->name,initial.year,initial.month,initial.day,final.year,final.month,final.day,count);
		
		//上面的是用来得到起止时间和医生的工号：
		//下面来输出：日期 ，接诊量/限号量，繁忙程度，工作强度评价
		
		printf("已成功统计该名医生的工作繁忙程度，是否继续查询其他医生的工作繁忙程度?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			printf("请输入正确的操作选项\n");
			clear_input_buffer();
		}	
	}
}


/*--------------------------- 财政or流水管理-------------------------------*/
//辅助函数1：
//@遍历诊疗记录然后求出一个营业额，但是有一点是这个药品进货的价格也要记得减去
//@先建立一个辅助函数（负责一个时间点总营业额的统计，这里我们要求用户输入要输入年月日时分秒
/*@现在已经出院，但是统计开始时间的时候已住院但还没有出院
|-------|（开始查询时间）————————————————|（住院结束时间）
（住院的总天数-已经住的）*住院费用，再从诊疗记录统计的总费用里减去*/   //这些天数套用days函数即可以得到

/*@一直没出院|----------|（开始查询时间）————————————————|还在住院
（那就直接：开始时间-入院时间=这段时间的住院天数）*住院单天费用（+）*/

/* 统计总营业额（统计单个时间点之前所有的营业额）*/


float calculate_period_revenue(Consultation *head_C, Bed *head_B, Medicine *head_M, DateTime detect_time){
// 用局部指针遍历，不要动原来的 head
	Consultation *c = head_C;
	float all_cost = 0;
	while(c != NULL){
		if(constract_two_days(detect_time, c->consultTime_end))  // 确认这个方向是对的
			all_cost += c->cost;
		c = c->next;
	}
	
// 床位处理也要用局部指针
	float havent_in_days_cost = 0;
	float have_in_days_cost = 0;
	Bed *B1 = head_B;
	while(B1 != NULL){
		Admission_information *status_0 = B1->status;  // 用局部指针！不要动 B1->status
		while(status_0 != NULL){
			if(status_0->check_out.year == 0) {
				// 未出院病人
				if(constract_two_days(detect_time, status_0->check_in)) {
					int exact_in = calculate_day(status_0->check_in, detect_time);
					have_in_days_cost += exact_in * B1->daily_cost;
				}
			} else {
				// 已出院病人
				if(constract_two_days(detect_time, status_0->check_in) 
				   && constract_two_days(status_0->check_out, detect_time) ) {
					int haven_in = calculate_day(status_0->check_in, status_0->check_out) - calculate_day(status_0->check_in, detect_time);
					havent_in_days_cost += haven_in * B1->daily_cost;
				}
			}
			status_0 = status_0->next;  // 修改局部指针
		}
		B1 = B1->next;
	}
	
// 药品成本只算到 detect_time 之前的（如果你要算这段时间的净利润）
// 但你的逻辑是 "总营业额 - 总成本"，这个要看业务需求
	float medicine_cost = 0;
	Medicine *m = head_M;
	while(m != NULL){
		MedicineIORecord *record = m->io_list;
		int number = 0;
		while(record != NULL){
			if(record->is_valid == true && record->io_type == 1 && constract_two_days(detect_time, record->operate_time)){
				number += record->number;
			}
			record = record->next;
		}
		medicine_cost += number * m->cost_price;
		m = m->next;
	}
	
	return all_cost - medicine_cost - havent_in_days_cost + have_in_days_cost;
}

/*财政or流水函数1：满足对所有时间段营业额的查询*/
void calculate_total_revenue(Consultation *head_C, Bed *head_B,Medicine *head_M){
	DateTime initial;
	DateTime final;
	int number=1;
	while(number){
		int sure=0;
		while(sure==0){
			// ---------- 输入起始时间 ----------
			clear_input_buffer();
			printf("请输入起始时间点(按照：年.月.日.时:分:秒  的格式输入，如2025.3.3.8:0:0)：\n");
			while(1){
				 // 先清缓冲区，防止上次残留
				if(scanf("%d.%d.%d.%d:%d:%d",&initial.year,&initial.month,&initial.day,&initial.hour,&initial.minute,&initial.second)==6){
					if(check_weather_surpuss_1(initial)) break;  // 合法就退出
					else printf("输入时间尚未发生，请重新输入起始时间：\n");
				}
				else{
					clear_input_buffer(); 
					printf("格式错误，请按 年.月.日.时:分:秒 格式重新输入起始时间：\n");
				}
			}
			
			// ---------- 输入终止时间 ----------
			clear_input_buffer();
			printf("请输入终止时间点(按照：年.月.日.时:分:秒  的格式输入，如2025.5.12.8:0:0)：\n");
			while(1){
				clear_input_buffer();  // 先清缓冲区
				if(scanf("%d.%d.%d.%d:%d:%d",&final.year,&final.month,&final.day,&final.hour,&final.minute,&final.second)==6){
					if(check_weather_surpuss_1(final)) break;  // ✅ 这里是 final！
					else printf("输入时间尚未发生，请重新输入终止时间：\n");
				}
				else{
					printf("格式错误，请按 年.月.日.时:分:秒 格式重新输入终止时间：\n");
				}
			}
			
			// ---------- 校验时间顺序 ----------
			if(constract_two_days(final,initial)!=true){
				printf("输入的结束时间点早于开始时间点,请重新输入\n");
			}
			else{
				printf("你输入的时间段是%d.%d.%d.%d:%d:%d--%d.%d.%d.%d:%d:%d\n",
					   initial.year,initial.month,initial.day,initial.hour,initial.minute,initial.second,
					   final.year,final.month,final.day,final.hour,final.minute,final.second);
				printf("确认请按：1  重新输入请按：0\n");
				while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
					printf("请输入正确的选项：\n");
					clear_input_buffer();
				}
				clear_input_buffer();
			}
		}
		
		// ---------- 计算营业额 ----------
		float profit=0;
		profit=calculate_period_revenue(head_C,head_B,head_M,final)-calculate_period_revenue(head_C,head_B,head_M,initial);
		printf("在%d.%d.%d.%d:%d:%d--%d.%d.%d.%d:%d:%d这段时间的营业额是：%.2f元\n",
			   initial.year,initial.month,initial.day,initial.hour,initial.minute,initial.second,
			   final.year,final.month,final.day,final.hour,final.minute,final.second,profit);
		
		printf("已成功统计这段时间医院的营业额，是否继续统计其他时间段的营业额?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			printf("请输入正确的操作选项\n");
			clear_input_buffer();
		}
		clear_input_buffer();
	}
}

/* 统计单个医生时间点之前所有的营业额 */
/* 统计单个医生时间点之前所有的营业额 */
float calculate_period_revenue_doctor(Consultation *head_C, Bed *head_B,DateTime detect_time,char *DoctorID){
	
//@计算这个时刻之前完成诊断的所有人的费用
	float all_cost=0;
	Consultation *c=head_C;  // ✅ 用局部指针
	
	while(c!=NULL){
		if(constract_two_days(detect_time,c->consultTime_end)&&strcmp(c->doctorID,DoctorID)==0)
			all_cost+=c->cost;
		c=c->next;
	}
//处理查询的没住的天数（-后期出院）和已经住的天数（-后期还没出院）
	float havent_in_days_cost=0;//@查询时还没住的天数，但是后期会住；(-)
	float have_in_days_cost=0;//@查询时已经住的天数，实际上还没出院(+)
//开始去除所有已经出院但是查询时间点还没有出院
	Bed *B1=head_B;
	while(B1!=NULL){
		Admission_information *status_0=B1->status;  // ✅ 用局部指针
		while(status_0!=NULL){
//默认没出院的时候check的时间是2000.1.1这样就进入到else if里去了
			if(status_0->check_out.year == 0) {
				// 未出院病人
				if(constract_two_days(detect_time, status_0->check_in) && strcmp(status_0->doctor_id, DoctorID)==0) {
					int exact_in = calculate_day(status_0->check_in, detect_time);
					have_in_days_cost += exact_in * B1->daily_cost;
				}
			} else {
				// 已出院病人
				if(constract_two_days(detect_time, status_0->check_in) 
				   && constract_two_days(status_0->check_out, detect_time) 
				   && strcmp(status_0->doctor_id, DoctorID)==0) {
					int haven_in = calculate_day(status_0->check_in, status_0->check_out) - calculate_day(status_0->check_in, detect_time);
					havent_in_days_cost += haven_in * B1->daily_cost;
				}
			}
			
			
			status_0=status_0->next;  // ✅ 修改局部指针
		}
		B1=B1->next;
	}
	return all_cost-havent_in_days_cost+have_in_days_cost;
}

/*财政or流水函数2：查看指定医生指定日期（时间段）流水*/
void Transaction_History_of_doctor(Consultation *head_C, Bed *head_B,Doctor *head_D){
	//输入两个时间段，调用函数算出对应时间点的总营业额再想减，最后要防止输入时间超过实际时间的问题；
	DateTime initial;
	DateTime final;
	
	int number=1;
	while(number){
		int sure=0;			
		// 1. 模糊查询选择医生
		Doctor *target= select_doctor_by_fuzzy_search(head_D);
		if (target == NULL) { // 用户取消查询
			break;
		}
		
		printf("请输入你想要查询的时间段\n");
		while(sure==0){
			clear_input_buffer();
			printf("请输入起始时间点(按照：年.月.日.时.分.秒  的格式输入，如2025.3.3.8.0.0)：\n");
			while(1){
				clear_input_buffer();
				if(scanf("%d.%d.%d.%d.%d.%d",&initial.year,&initial.month,&initial.day,&initial.hour,&initial.minute,&initial.second)==6){
					if(check_weather_surpuss_1(initial)) break;
					else printf("输入时间尚未发生，请重新输入起始时间：\n");
				}
				else{
					printf("格式错误，请按 年.月.日.时.分.秒 格式重新输入起始时间：\n");
				}
			}
			clear_input_buffer();
			printf("请输入终止时间点(按照：年.月.日.时.分.秒  的格式输入，如2025.5.12.8.0.0)：\n");
			while(1){
				clear_input_buffer();
				if(scanf("%d.%d.%d.%d.%d.%d",&final.year,&final.month,&final.day,&final.hour,&final.minute,&final.second)==6){
					if(check_weather_surpuss_1(final)) break;  // ✅ 这里是 final 不是 initial
					else printf("输入时间尚未发生，请重新输入终止时间：\n");
				}
				else{
					printf("格式错误，请按 年.月.日.时.分.秒 格式重新输入终止时间：\n");
				}
			}
			
			if(constract_two_days(final,initial)!=true){
				printf("输入的结束时间点早于开始时间点,请重新输入\n");
			}
			else{
				printf("你输入的时间段是%d.%d.%d.%d.%d.%d--%d.%d.%d.%d.%d.%d\n",
					   initial.year,initial.month,initial.day,initial.hour,initial.minute,initial.second,
					   final.year,final.month,final.day,final.hour,final.minute,final.second);
				//固定让用户确认输入操作
				printf("确认请按：1  重新输入请按：0\n");
				while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
					printf("请输入正确的选项：\n");
					clear_input_buffer();
				}
				clear_input_buffer();
			}
		}
		
		float profit=0;
		profit=calculate_period_revenue_doctor(head_C,head_B,final,target->staff_id)-calculate_period_revenue_doctor(head_C,head_B,initial,target->staff_id);
		printf("在%d.%d.%d.%d.%d.%d--%d.%d.%d.%d.%d.%d这段时间%s医生的流水是：%.2f元\n",initial.year,initial.month,initial.day,initial.hour,initial.minute,initial.second,
			   final.year,final.month,final.day,final.hour,final.minute,final.second,target->name,profit);
		
		printf("已成功查看该名医生的流水，是否继续查看其他医生的流水?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			printf("请输入正确的操作选项\n");
			clear_input_buffer();
		}
		clear_input_buffer();
	}
}

/*财政or流水函数3：查看指定科室指定日期（时间段）流水*/
//依旧只加限制条件，床位可以直接限制，诊疗记录也可以直接用科室限制
float calculate_period_revenue_department(Consultation *head_C, Bed *head_B, DateTime detect_time,char *departmentID){
	
	//@计算这个时刻之前完成诊断的所有人的费用
	float all_cost=0;
	Consultation *c=head_C;  // ✅ 用局部指针
	while(c!=NULL){
		if(constract_two_days(detect_time,c->consultTime_end)&&strcmp(c->department,departmentID)==0)
			all_cost+=c->cost;
		c=c->next;
	}
	
	//处理查询的没住的天数（-后期出院）和已经住的天数（-后期还没出院）
	float havent_in_days_cost=0;//@查询时还没住的天数，但是后期会住；(-)
	float have_in_days_cost=0;//@查询时已经住的天数，实际上还没出院(+)
	//开始去除所有已经出院但是查询时间点还没有出院
	Bed *B1=head_B;
	while(B1!=NULL){
		Admission_information *status_0=B1->status;  // ✅ 用局部指针
		if(strcmp(B1->department_name,departmentID)!=0){
			B1=B1->next;
			continue;
		}
		while(status_0!=NULL){
			if(status_0->check_out.year == 0) {
				// 未出院病人
				if(constract_two_days(detect_time, status_0->check_in) ) {
					int exact_in = calculate_day(status_0->check_in, detect_time);
					have_in_days_cost += exact_in * B1->daily_cost;
				}
			} else {
				// 已出院病人
				if(constract_two_days(detect_time, status_0->check_in) 
				   && constract_two_days(status_0->check_out, detect_time) ) {
					int haven_in = calculate_day(status_0->check_in, status_0->check_out) - calculate_day(status_0->check_in, detect_time);
					havent_in_days_cost += haven_in * B1->daily_cost;
				}
			}
			status_0=status_0->next;  // ✅ 修改局部指针
		}
		B1=B1->next;
	}
	return all_cost-havent_in_days_cost+have_in_days_cost;
}

void Transaction_History_of_department(Consultation *head_C, Bed *head_B,Medicine *head_M){
	//输入两个时间段，调用函数算出对应时间点的总营业额再想减，最后要防止输入时间超过实际时间的问题；
	DateTime initial;
	DateTime final;
	//输入对应的科室采用选择法减少可能的选择错误
	char departmentID[20];
	printf("请选择你想要查询的科室\n");
	printf("1.普通内科 2.骨科 3.妇产科\n");
	printf("4.儿科 5.急诊科 6.影像科 7.医学检验科(化验)\n");
	int sure=0;
	int choice;
	while(sure==0){
		while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5&&choice!=6&&choice!=7)){
			clear_input_buffer();
			printf("请输入正确的选项：\n");
		}
		switch (choice) {
			case 1:strcpy( departmentID,"普通内科");break;
			case 2:strcpy( departmentID,"骨科");break;
			case 3:strcpy( departmentID,"妇产科");break;
			case 4:strcpy( departmentID,"儿科");break;
			case 5:strcpy( departmentID,"急诊科");break;
			case 6:strcpy( departmentID,"影像科");break;
			case 7:strcpy( departmentID,"医学检验科(化验)");break;
		}
		clear_input_buffer();
		printf("你选择的科室是：%s\n", departmentID);
		printf("确认请按：1  重新输入请按：0\n");
		while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
			clear_input_buffer();
			printf("请输入正确的选项：\n");
		}
		clear_input_buffer();
	}
	
	
	while(1){
		printf("请输入你想要查询的时间段\n");
		int sure=0;
		while(sure==0){
			printf("请输入起始时间点(按照：年.月.日.时.分.秒  的格式输入，如2025.3.3.8.0.0)：\n");
			while(1){
				clear_input_buffer();
				if(scanf("%d.%d.%d.%d.%d.%d",&initial.year,&initial.month,&initial.day,&initial.hour,&initial.minute,&initial.second)==6){
					if(check_weather_surpuss_1(initial)) break;
					else printf("输入时间尚未发生，请重新输入起始时间：\n");
				}
				else{
					printf("格式错误，请按 年.月.日.时.分.秒 格式重新输入起始时间：\n");
				}
			}
			
			printf("请输入终止时间点(按照：年.月.日.时.分.秒  的格式输入，如2025.5.12.8.0.0)：\n");
			while(1){
				clear_input_buffer();
				if(scanf("%d.%d.%d.%d.%d.%d",&final.year,&final.month,&final.day,&final.hour,&final.minute,&final.second)==6){
					if(check_weather_surpuss_1(final)) break;  // ✅ 这里是 final 不是 initial
					else printf("输入时间尚未发生，请重新输入终止时间：\n");
				}
				else{
					printf("格式错误，请按 年.月.日.时.分.秒 格式重新输入终止时间：\n");
				}
			}
			
			if(constract_two_days(final,initial)!=true){
				printf("输入的结束时间点早于开始时间点,请重新输入\n");
			}
			else{
				printf("你输入的时间段是%d.%d.%d.%d.%d.%d--%d.%d.%d.%d.%d.%d\n",
					   initial.year,initial.month,initial.day,initial.hour,initial.minute,initial.second,
					   final.year,final.month,final.day,final.hour,final.minute,final.second);
				//固定让用户确认输入操作
				printf("确认请按：1  重新输入请按：0\n");
				while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
					clear_input_buffer();
					printf("请输入正确的选项：\n");
				}
				clear_input_buffer();
			}
		}
		float profit=0;
		profit=calculate_period_revenue_department(head_C,head_B,final,departmentID)-calculate_period_revenue_department(head_C,head_B,initial,departmentID);
		printf("%s在%d.%d.%d.%d.%d.%d--%d.%d.%d.%d.%d.%d这段时间的流水是：%.2f元\n",departmentID,initial.year,initial.month,initial.day,initial.hour,initial.minute,initial.second,
			   final.year,final.month,final.day,final.hour,final.minute,final.second,profit);
		
		printf("是否继续查询其他科室？1=继续 0=返回：");
		int cont;
		while(scanf("%d", &cont) != 1 || (cont != 0 && cont != 1)){
			clear_input_buffer();
			printf("请输入0或1：");
		}
		clear_input_buffer();
		if(cont == 0) break;
	}
	return ; 
}


/*----------------------------药品类函数-----------------------------*/


// 模糊查询药品（按 药名 匹配）
// 返回值：匹配结果的数量；results：输出匹配的药品列表（需提前分配内存）
int fuzzy_search_medicine_administrator(Medicine *head, const char *keyword, Medicine **results, int max_results) {
	if (head == NULL || keyword == NULL || strlen(keyword) == 0) {
		return 0;
	}
	int count = 0;
	Medicine *current = head;
	while (current != NULL && count < max_results) {
		// 匹配规则：关键词是工号/姓名/科室的子串（不区分大小写可加tolower，此处简化）
		if (strstr(current->name, keyword) != NULL) {
			results[count++] = current;
		}
		current = current->next;
	}
	return count;
}

// 展示模糊查询结果并让用户选择
// 返回值：用户选中的医生节点（NULL表示取消/退出）
Medicine *select_medicine_by_fuzzy_search(Medicine *head) {
	char keyword[50];
	const int MAX_RESULTS = 20; // 最大展示20条结果
	Medicine *results[MAX_RESULTS];
	
	while (1) {
		// 1. 输入查询关键词
		printf("\n===== 药品模糊查询 =====\n");
		printf("请输入查询关键词（药品名，输入0返回上一级）：");
		scanf("%s", keyword);
		clear_input_buffer(); // 清除回车
		
		// 2. 退出查询
		if (strcmp(keyword, "0") == 0) {
			printf("退出查询...\n");
			return NULL;
		}
		
		// 3. 执行模糊查询
		int match_count = fuzzy_search_medicine_administrator(head, keyword, results, MAX_RESULTS);
		
		// 4. 无匹配结果
		if (match_count == 0) {
			printf("未找到包含「%s」的药品信息！\n", keyword);
			printf("是否重新查询？(1=重新查询，0=返回上一级)：");
			int choice;
			while (scanf("%d", &choice) != 1 || (choice != 0 && choice != 1)) {
				clear_input_buffer();
				printf("输入错误！请输入1(重新查询)或0(返回)：");
			}
			clear_input_buffer();
			if (choice == 0) {
				return NULL;
			}
			continue; // 重新查询
		}
		
		// 5. 展示匹配结果
		printf("\n===== 匹配结果（共%d条）=====\n", match_count);
		for (int i = 0; i < match_count; i++) {
			printf("[%d] 药品名：%s | 库存：%d \n",
				   i+1, results[i]->name,results[i]->stock);
		}
		
		// 6. 选择结果
		printf("\n请选择操作：\n");
		printf("1~%d = 选中对应药品 | 0 = 重新查询 | -1 = 返回上一级\n", match_count);
		int select;
		while (1) {
			printf("请输入选项：");
			if (scanf("%d", &select) != 1) {
				clear_input_buffer();
				printf("输入错误！请输入数字！\n");
				continue;
			}
			clear_input_buffer();
			if (select == 0) {
				break; // 重新查询
			} else if (select == -1) {
				return NULL; // 返回上一级
			} else if (select >= 1 && select <= match_count) {
				return results[select-1]; // 返回选中的医生
			} else {
				printf("输入超出范围！请输入1~%d、0或-1\n", match_count);
			}
		}
	}
}




/*药品函数1：增加多种新品种的药*/
/*
@输入对应药品名
@用gettime得到进药时间
@手动输入过期时间
@进货的数量
@手动写入进价售价
@依旧头插法
*/
void add_new_kind_medicine(char *AdministratorID,Medicine **head_M){
	int number=1;
	while(number){
		Medicine *M=(Medicine*)malloc(sizeof(Medicine));
		M->io_list = (MedicineIORecord*)malloc(sizeof(MedicineIORecord));
		printf("请输入药品名称:\n");
		int sure=0;
		//输入药品名
		while(sure!=1){
			while(scanf("%s",M->name)!=1){
				clear_input_buffer();
				printf("请输入正确的药品名称:\n");
			}
			clear_input_buffer();
			printf("你输入的名称是：%s\n",M->name);
			printf("确认请按：1  从新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();		
		}
		//得到进货时间
		M->io_list->operate_time=get_current_time();
		//输入药品有效期至
		sure=0;
		while(sure!=1){
			printf("请输入的药品的有效期至（年 月 日 时 分）:\n");
			while(scanf("%d %d %d %d %d",&M->io_list->deadline_time.year,&M->io_list->deadline_time.month,&M->io_list->deadline_time.day,&M->io_list->deadline_time.hour,&M->io_list->deadline_time.minute)!=5){
				clear_input_buffer();
				printf("请输入正确药品有效期至（年 月 日 时 分）:\n");
			}
			clear_input_buffer();
			printf("你输入的药品的有效期至：%d.%d.%d.%d.%d\n",M->io_list->deadline_time.year,M->io_list->deadline_time.month,M->io_list->deadline_time.day,M->io_list->deadline_time.hour,M->io_list->deadline_time.minute);
			printf("确认请按：1  重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		sure=0;
		printf("请输入本次进货药品的数量（盒or剂or瓶）:\n");
		while(sure!=1){
			while(scanf("%d",&M->io_list->number)!=1){
				clear_input_buffer();
				printf("请输入正确的药品数量:\n");
			}
			clear_input_buffer();
			printf("你输入的药品数量为：%d\n",M->io_list->number);
			printf("确认请按：1  重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		//将进货的量传入stock里
		M->stock=M->io_list->number;
		//输入进货单价
		sure=0;
		printf("请输入本次进货药品的进货单价:\n");
		while(sure!=1){
			while(scanf("%f",&M->cost_price)!=1){
				clear_input_buffer();
				printf("请输入正确的药品进货单价:\n");
			}
			clear_input_buffer();
			printf("你输入的药品的进货单价为：%f\n",M->cost_price);
			printf("确认请按：1  重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		
		//输入售货单价
		sure=0;
		printf("请输入本次进货药品的售货单价:\n");
		while(sure!=1){
			while(scanf("%f",&M->selling_price)!=1){
				clear_input_buffer();
				printf("请输入正确的药品售货单价:\n");
			}
			clear_input_buffer();
			printf("你输入的药品的售货单价为：%f\n",M->selling_price);
			printf("确认请按：1  重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		//传入操作者Id
		strcpy(M->io_list->operator_id,AdministratorID);
		//确认状态是入库
		M->io_list->io_type=1;
		//记录是否有效
		M->io_list->is_valid=true;
		M->next=*head_M;
		*head_M=M;
		printf("已成功存入新药品，是否继续添加新药品?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			printf("请输入正确的操作选项\n");
			clear_input_buffer();
		}
		clear_input_buffer();
	}
}

/*药品函数2：增加已有药品数量（补货）*/
void add_medicine_stock(char *AdministratorID,Medicine *head_M){
	int number=1;
	while(number){
		//输入此次进货的药品名称
		int sure=0;			
		// 1. 模糊查询选择药品
		Medicine *target= select_medicine_by_fuzzy_search(head_M);
		if (target == NULL) { // 用户取消查询
			break;
		}
		//找到对应指针并申请新的记录空间&&完成链表连接；
		MedicineIORecord *new_record=(MedicineIORecord*)malloc(sizeof(MedicineIORecord));
		new_record->next=target->io_list;
		target->io_list=new_record;
		//得到进货时间
		new_record->operate_time=get_current_time();
		//输入药品有效期至
		printf("请输入的药品的有效期至（年 月 日 时 分）:\n");
		while(sure!=1){
			while(scanf("%d %d %d %d %d",&new_record->deadline_time.year,&new_record->deadline_time.month,&new_record->deadline_time.day,&new_record->deadline_time.hour,&new_record->deadline_time.minute)!=5){
				clear_input_buffer();
				printf("请输入正确药品有效期至（年 月 日 时 分）:\n");
			}
			clear_input_buffer();
			printf("你输入的药品的有效期至：%d.%d.%d.%d.%d\n",new_record->deadline_time.year,new_record->deadline_time.month,new_record->deadline_time.day,new_record->deadline_time.hour,new_record->deadline_time.minute);
			printf("确认请按：1  重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
//输入药品进货的数量	
		sure=0;
		printf("请输入本次进货药品的数量（盒or剂or瓶）:\n");
		while(sure!=1){
			while(scanf("%d",&new_record->number)!=1){
				clear_input_buffer();
				printf("请输入正确的药品数量:\n");
			}
			clear_input_buffer();
			printf("你输入的药品数量为：%d\n",new_record->number);
			printf("确认请按：1  重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
//将进货的量传入stock里
		target->stock+=new_record->number;
		
//传入操作者Id
		strcpy(new_record->operator_id,AdministratorID);
//确认状态是入库
		new_record->io_type=1;
//记录是否有效
		new_record->is_valid=true;
		printf("已成功完成此次补货，是否继续进行补货操作?\n");
		printf("继续补货请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			printf("请输入正确的操作选项\n");
			clear_input_buffer();
		}
		clear_input_buffer();
	}
}


/*-----------------------医生系统函数-----------------------*/
//医生函数4的辅助函数
//确认输入字符是否是中文
int is_chinese(char ch) {
	return (unsigned char)ch >= 0x80?1:0;  // GBK编码下，中文最高位为1
}
//检查名字是否全是中文和·
bool check_name(char *name){
	char *p=name;
	int length=strlen(name);
	for(int i=0;i<length;i++){
		if(is_chinese(*(p+i)))continue;
		if(strncmp(p + i, "·", 2) == 0)//这个·是中文字符占2个字节，只能这样比较
		{
			continue;
		}
		return false;
	}
	return true;
}
//确认身份证号是否只含有数字和X
bool check_id_card_number(char *id_card){
	int length = strlen(id_card);
	for(int i = 0; i < length; i++){
		char c = id_card[i];
		// 必须是数字或X
		if(!(c >= '0' && c <= '9') && c != 'X'){
			return false;
		}
	}
	return true;
}
//确认电话号码是否只含有数字，并且检查位数
bool check_phone_number(char *phone_number){
	int length = strlen(phone_number);
	for(int i = 0; i < length; i++){
		if(phone_number[i] < '0' || phone_number[i] > '9'){
			return false;
		}
	}
	return true;
}

//检查输入工号是否重复
bool check_staff_id_doctor(char *staff_id,Doctor *head_D){
	while(head_D!=NULL){
		if(strcmp(staff_id,head_D->staff_id)==0)return false;
		head_D=head_D->next;
	}
	return true;
}
bool check_staff_id_nurse(char *staff_id,Nurse *head_N){
	while(head_N!=NULL){
		if(strcmp(staff_id,head_N->staff_id)==0)return false;
		head_N=head_N->next;
	}
	return true;
}
/*医生函数4：添加一名或多名新医生*/
void  add_new_doctor(Doctor **head_D){
	int number=1;
	while(number){
		Doctor *new_D=(Doctor*)malloc(sizeof(Doctor));
		//	char name[20];  //姓名
		printf("请输入新来的医生的姓名：\n");
		int sure=0;
		while(sure==0){
			while(scanf("%s",new_D->name)!=1||!check_name(new_D->name)){
				clear_input_buffer();
				if(check_name(new_D->name)==false){
					printf("%s",new_D->name);
					printf("输入名字里包含非法字符请重新输入：\n");
				}
				else
					printf("请输入正确的格式：\n");
			}
			clear_input_buffer();
			printf("这位新医生的姓名是：%s\n",new_D->name);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		//年龄	
		sure=0;
		printf("请输入的年龄数字:\n");
		while(sure==0){
			while(scanf("%d",&new_D->age)!=1||new_D->age>=130||new_D->age<=18){
				clear_input_buffer();
				printf("请输入正确的年龄数字:\n");
			}
			clear_input_buffer();
			printf("这位新医生的年龄是：%d\n",new_D->age);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		//身份证号
		sure=0;
		printf("请输入这新医生的身份证号：\n");
		while(sure==0){
			while(scanf("%s",new_D->id_card_number)!=1||!check_id_card_number(new_D->id_card_number)){
				clear_input_buffer();
				printf("输入身份证号包含除“0-9”和‘X’以外的非法字符!\n请重新输入:\n");
			}
			clear_input_buffer();
			printf("这位新医生的身份证号是%s：\n",new_D->id_card_number);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		//性别
		sure=0;
		printf("请输入这新医生的性别：(女士输入：女 男士输入：男)\n");
		while(sure==0){
			char G[10];
			while(scanf("%s",G)!=1||(strcmp(G,"女")!=0&&strcmp(G,"男")!=0)){ //不区分大小写使输入更具有普遍性
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的性别(女/男):\n");
			}
			clear_input_buffer();
			strcpy(new_D->gender,G);
			printf("这位新医生的性别是:%s\n",new_D->gender);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		//电话
		sure=0;
		printf("请输入这新医生的电话号码：\n");
		while(sure==0){
			while(scanf("%s",new_D->phone_number)!=1||!check_phone_number(new_D->phone_number)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("输入电话号码包含除“0-9”以外的非法字符!\n请重新输入:\n");
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位新医生的电话号码是:%s\n",new_D->phone_number);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		//输入科室
		sure=0;
		clear_input_buffer();
		printf("请输入这新医生的对应科室的编码：\n");
		printf("1.普通内科 2.骨科 3.妇产科\n");
		printf("4.儿科 5.急诊科 6.影像科 7.医学检验科(化验)\n");
		int choice;
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5&&choice!=6&&choice!=7)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:strcpy( new_D->department,"普通内科");break;
				case 2:strcpy( new_D->department,"骨科");break;
				case 3:strcpy( new_D->department,"妇产科");break;
				case 4:strcpy( new_D->department,"儿科");break;
				case 5:strcpy( new_D->department,"急诊科");break;
				case 6:strcpy( new_D->department,"影像科");break;
				case 7:strcpy( new_D->department,"医学检验科(化验)");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位新医生的科室是:%s\n",new_D->department);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		//生日
		sure=0;
		while(sure!=1){
			clear_input_buffer();
			printf("请输入新来的医生的出生日期（年 月 日）:\n");
			while(scanf("%d %d %d",&new_D->birthday.year,&new_D->birthday.month,&new_D->birthday.day)!=3){
				clear_input_buffer();
				printf("请输入正确的医生出生日期（年 月 日）:\n");
			}
			clear_input_buffer();
			printf("你输入的医生的出生日期：%d.%d.%d\n",new_D->birthday.year,new_D->birthday.month,new_D->birthday.day);
			printf("确认请按：1  重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();
		}
		//工号
		sure=0;
		clear_input_buffer();
		printf("请输入这新医生的工号\n");
		while(sure==0){
			scanf("%s",new_D->staff_id);
			clear_input_buffer();
			printf("这位新医生的工号是:%s\n",new_D->staff_id);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			//加这个函数确保工号的唯一性
			if(check_staff_id_doctor(new_D->staff_id,*head_D)==false){
				printf("警告：该工号已被使用，请重新输入工号\n");
				sure=0;
			}
		}
		//登陆密码
		sure=0;
		clear_input_buffer();
		printf("请输入这新医生账号的登陆密码：\n");
		while(sure==0){
			scanf("%s",new_D->login_password);
			clear_input_buffer();
			printf("这位新医生的登陆密码是:%s\n",new_D->login_password);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				printf("请输入正确的选项：\n");
				clear_input_buffer();
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
		}
		
		sure=0;
		clear_input_buffer();
		printf("请输入这新医生的对应的职称：\n");
		printf("1.主任  2.医师 \n");
		printf("3.副主任医师 4.主治医师 5.住院医师 \n");
		choice=0;
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:strcpy( new_D->job_title,"主任");break;
				case 2:strcpy( new_D->job_title,"医师");break;
				case 3:strcpy( new_D->job_title,"副主任医师");break;
				case 4:strcpy( new_D->job_title,"主治医师");break;
				case 5:strcpy( new_D->job_title,"住院医师");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位新医生的职称是:%s\n",new_D->job_title);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		
		//在职状态:1  在职   2  休假   3离职
		sure=0;
		clear_input_buffer();
		printf("请输入这新医生的在职状态：\n");
		printf("1.在职 2.休假 3.离职\n");
		choice=0;
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:new_D->staff_status=1;printf("这位新医生的在职状态是:在职\n");break;
				case 2:new_D->staff_status=2;printf("这位新医生的在职状态是:休假\n");break;
				case 3:new_D->staff_status=3;printf("这位新医生的在职状态是:离职\n");break;
			}
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		
		//工作时间表		
		//值班表1-7依次代表周一到周日，抛弃schedul[0]便于后续代码的输出。一天分成三个班，早/下午/晚班用0-2依次代替,上不上1/0
		int temp;
		int valid_input; // 标记输入是否有效
		
		printf("=== 医生排班录入系统 ===\n");
		printf("规则：输入三位数字，1=上班，0=休息\n");
		printf("示例：101 代表 上午班+晚班\n\n");
		sure=0;
		while(sure==0){
			for (int i = 1; i <= 7; i++) {
				valid_input = 0; // 重置标记
				while (!valid_input) {
					printf("请输入周%d的排班: ", i);
					// 1. 尝试读取一个整数
					// scanf 返回 1 代表成功读取了一个整数
					if (scanf("%d", &temp) == 1) {
						// 2. 范围检查：必须是 0 到 111 之间的数
						// 防止输入 1234 或 -5
						if (temp >= 0 && temp <= 111) {
							
							// 3. 位数值检查：每一位只能是 0 或 1
							// 百位 (temp/100), 十位 ((temp/10)%10), 个位 (temp%10)
							int h = temp / 100;
							int t = (temp / 10) % 10;
							int o = temp % 10;
							
							if ((h == 0 || h == 1) && (t == 0 || t == 1) && (o == 0 || o == 1)) {
								// --- 数据合法，存入数组 ---
								new_D->schedule[i][0] = h;
								new_D->schedule[i][1] = t;
								new_D->schedule[i][2] = o;
								valid_input = 1; // 跳出 while 循环
							} else {
								printf(" 错误：数字只能包含 0 或 1 (例如 101)。\n");
							}
						} else {
							printf(" 错误：请输入 0 到 111 之间的数字。\n");
						}
					} else {
						// 4. 处理非数字输入（如输入了字母 'a'）
						printf(" 错误：请输入有效的数字！\n");
						// 关键步骤：清空输入缓冲区
						// 如果不加这段代码，错误的字符会留在缓冲区，导致死循环
						int c;
						while ((c = getchar()) != '\n' && c != EOF);
					}
				}
			}
			// --- 输出验证结果 ---
			printf("\n=== 排班录入成功 ===\n");
			printf("-----------------------------------------------------------------------------------------\n");
			printf("|                                        排班表                                         |\n");
			printf("-----------------------------------------------------------------------------------------\n");
			
			printf("|-------日期-------|--------上午--------|-------下午---------|-----------晚班-----------|\n");
			printf("_________________________________________________________________________________________\n");
			for(int i=1; i<=7; i++){
				printf("|         周%d      |          %d         |         %d          |            %d             |\n", i, new_D->schedule[i][0], new_D->schedule[i][1], new_D->schedule[i][2]);
				printf("_________________________________________________________________________________________\n");
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		//链接链表
		new_D->next=*head_D;
		*head_D=new_D;
		printf("已成功存入该名医生的信息，是否继续输入下一名新医生的信息?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			printf("请输入正确的操作选项\n");
			clear_input_buffer();
		}
	}
}

// 模糊查询医生（按 工号/姓名/科室 匹配）
// 返回值：匹配结果的数量；results：输出匹配的医生列表（需提前分配内存）
int fuzzy_search_doctor(Doctor *head, const char *keyword, Doctor **results, int max_results) {
	if (head == NULL || keyword == NULL || strlen(keyword) == 0) {
		return 0;
	}
	int count = 0;
	Doctor *current = head;
	while (current != NULL && count < max_results) {
		// 匹配规则：关键词是工号/姓名/科室的子串（不区分大小写可加tolower，此处简化）
		if (strstr(current->staff_id, keyword) != NULL ||
			strstr(current->name, keyword) != NULL ||
			strstr(current->department, keyword) != NULL) {
			results[count++] = current;
		}
		current = current->next;
	}
	return count;
}

// 展示模糊查询结果并让用户选择
// 返回值：用户选中的医生节点（NULL表示取消/退出）
Doctor *select_doctor_by_fuzzy_search(Doctor *head) {
	char keyword[50];
	const int MAX_RESULTS = 20; // 最大展示20条结果
	Doctor *results[MAX_RESULTS];
	
	while (1) {
		// 1. 输入查询关键词
		printf("\n===== 医生模糊查询 =====\n");
		clear_input_buffer();
		printf("请输入查询关键词（工号/姓名/科室，输入0返回上一级）：");
		scanf("%s", keyword);
		clear_input_buffer(); // 清除回车
		
		// 2. 退出查询
		if (strcmp(keyword, "0") == 0) {
			printf("退出查询，返回上一级菜单...\n");
			return NULL;
		}
		
		// 3. 执行模糊查询
		int match_count = fuzzy_search_doctor(head, keyword, results, MAX_RESULTS);
		
		// 4. 无匹配结果
		if (match_count == 0) {
			printf("未找到包含 【%s】 的医生信息！\n", keyword);
			clear_input_buffer();
			printf("是否重新查询？(1=重新查询，0=返回上一级)：");
			int choice;
			while (scanf("%d", &choice) != 1 || (choice != 0 && choice != 1)) {
				clear_input_buffer();
				printf("输入错误！请输入1(重新查询)或0(返回)：");
			}
			clear_input_buffer();
			if (choice == 0) {
				return NULL;
			}
			continue; // 重新查询
		}
		
		// 5. 展示匹配结果
		printf("\n===== 匹配结果（共%d条）=====\n", match_count);
		for (int i = 0; i < match_count; i++) {
			printf("[%d] 工号：%s | 姓名：%s | 科室：%s\n",
				   i+1, results[i]->staff_id, results[i]->name, results[i]->department);
		}
		
		// 6. 选择结果
		printf("\n请选择操作：\n");
		printf("1~%d = 选中对应医生 | 0 = 重新查询 | -1 = 返回上一级\n", match_count);
		int select;
		while (1) {
			clear_input_buffer();
			printf("请输入选项：");
			if (scanf("%d", &select) != 1) {
				clear_input_buffer();
				printf("输入错误！请输入数字！\n");
				continue;
			}
			clear_input_buffer();
			if (select == 0) {
				break; // 重新查询
			} else if (select == -1) {
				return NULL; // 返回上一级
			} else if (select >= 1 && select <= match_count) {
				return results[select-1]; // 返回选中的医生
			} else {
				printf("输入超出范围！请输入1~%d、0或-1\n", match_count);
			}
		}
	}
}



/*医生函数1:修改医生职称*///⚠️这里可以到时候再加塞一个是否和原职称一样
void update_doctor_title(Doctor *head_D){
	int number = 1;
	while (number) {
		// 1. 模糊查询选择医生
		Doctor *target= select_doctor_by_fuzzy_search(head_D);
		if (target == NULL) { // 用户取消查询
			break;
		}
		printf("接下来将要修改%s的职称\n",target->name);
		clear_input_buffer();
		printf("请选择这位医生对应的新职称：\n");
		printf("1.主任  2.医师 \n");
		printf("3.副主任医师 4.主治医师 5.住院医师 \n");
		
		int choice=0;
		int sure=0;
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:strcpy( target->job_title,"主任");break;
				case 2:strcpy( target->job_title,"医师");break;
				case 3:strcpy( target->job_title,"副主任医师");break;
				case 4:strcpy( target->job_title,"主治医师");break;
				case 5:strcpy( target->job_title,"住院医师");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位医生对应的新职称是:%s\n",target->job_title);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		printf("已成功修改该名医生的职称，是否继续修改其他医生的职称?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
	}
}


/*医生函数2：修改医生值班表*/
void update_D_schedule(Doctor *head_D){
	int number=1;
	while(number){
		int sure=0;
		int temp;
		int valid_input; // 标记输入是否有效
		// 1. 模糊查询选择医生
		Doctor *target= select_doctor_by_fuzzy_search(head_D);
		if (target == NULL) { // 用户取消查询
			break;
		}
		
		printf("接下来将要修改%s的值班表\n",target->name);
		printf("=== 医生排班录入系统 ===\n");
		printf("规则：输入三位数字，1=上班，0=休息\n");
		printf("示例：101 代表 上午班+晚班\n\n");
		clear_input_buffer();
		printf("请输入修改后的值班表:\n");
		while(!sure){
			for (int i = 1; i <= 7; i++) {
				valid_input = 0; // 重置标记
				while (!valid_input) {
					clear_input_buffer();
					printf("请输入周%d的排班: ", i);
					// 1. 尝试读取一个整数
					// scanf 返回 1 代表成功读取了一个整数
					if (scanf("%d", &temp) == 1) {
						// 2. 范围检查：必须是 0 到 111 之间的数
						// 防止输入 1234 或 -5
						if (temp >= 0 && temp <= 111) {
							
							// 3. 位数值检查：每一位只能是 0 或 1
							// 百位 (temp/100), 十位 ((temp/10)%10), 个位 (temp%10)
							int h = temp / 100;
							int t = (temp / 10) % 10;
							int o = temp % 10;
							
							if ((h == 0 || h == 1) && (t == 0 || t == 1) && (o == 0 || o == 1)) {
								// --- 数据合法，存入数组 ---
								target->schedule[i][0] = h;
								target->schedule[i][1] = t;
								target->schedule[i][2] = o;
								valid_input = 1; // 跳出 while 循环
							} else {
								printf(" 错误：数字只能包含 0 或 1 (例如 101)。\n");
							}
						} else {
							printf(" 错误：请输入 0 到 111 之间的数字。\n");
						}
					} else {
						// 4. 处理非数字输入（如输入了字母 'a'）
						printf(" 错误：请输入有效的数字！\n");
						// 关键步骤：清空输入缓冲区
						// 如果不加这段代码，错误的字符会留在缓冲区，导致死循环
						int c;
						while ((c = getchar()) != '\n' && c != EOF);
					}
				}
			}
			// --- 输出验证结果 ---
			printf("\n=== 排班录入成功 ===\n");
			printf("-----------------------------------------------------------------------------------------\n");
			printf("|                                        排班表                                         |\n");
			printf("-----------------------------------------------------------------------------------------\n");
			
			printf("|-------日期-------|--------上午--------|-------下午---------|-----------晚班-----------|\n");
			printf("_________________________________________________________________________________________\n");
			for(int i=1; i<=7; i++){
				printf("|         周%d      |          %d         |         %d          |            %d             |\n", i,target->schedule[i][0], target->schedule[i][1], target->schedule[i][2]);
				printf("_________________________________________________________________________________________\n");
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		
		printf("已成功修改该名医生的值班表，是否继续修改其他医生的值班表?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
		
		
	}
	
}

/*医生函数3：修改医生在职状态（在职or离职or休假）*/
void change_status_doctor(Doctor *head_D){
	int number=1;
	int choice=0;
	
	while(number){
		//每次循环都将sure重置
		int sure=0;
		// 1. 模糊查询选择医生
		Doctor *target= select_doctor_by_fuzzy_search(head_D);
		if (target == NULL) { // 用户取消查询
			break;
		}
		clear_input_buffer();
		printf("接下来将要修改%s的在职状态\n",target->name);
		printf("请选择这位医生的更新后的在职状态：\n");
		printf("1.在职 2.休假 3.离职\n");
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:target->staff_status=1;printf("这位新医生的在职状态是:在职");break;
				case 2:target->staff_status=2;printf("这位新医生的在职状态是:休假");break;
				case 3:target->staff_status=3;printf("这位新医生的在职状态是:离职");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		
		printf("已成功修改该名医生的在职状态，是否继续修改其他医生的在职状态?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
	}
}


/*医生函数5：修改医生所在科室*/
void change_department_doctor(Doctor* head_D){
	int number=1;
	
	while(number){
		int choice=0;
		int sure=0;			
		// 1. 模糊查询选择医生
		Doctor *target= select_doctor_by_fuzzy_search(head_D);
		if (target == NULL) { // 用户取消查询
			break;
		}
		
		printf("接下来将要修改%s的所在的科室\n",target->name);
		printf("请输入该医生的对应的新科室的编码：\n");
		printf("1.普通内科 2.骨科 3.妇产科\n");
		printf("4.儿科 5.急诊科 6.影像科 7.医学检验科(化验)\n");
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5&&choice!=6&&choice!=7)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:strcpy( target->department,"普通内科");break;
				case 2:strcpy( target->department,"骨科");break;
				case 3:strcpy( target->department,"妇产科");break;
				case 4:strcpy( target->department,"儿科");break;
				case 5:strcpy( target->department,"急诊科");break;
				case 6:strcpy( target->department,"影像科");break;
				case 7:strcpy( target->department,"医学检验科(化验)");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位新医生的科室是:%s\n",target->department);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}	
		
		printf("已成功修改该名医生的所属科室，是否继续修改其他医生的所属科室?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
	}
	
}

/*----------------------护士信息修改系统----------------------------------*/

// 模糊查询护士（按 工号/姓名/科室 匹配）
// 返回值：匹配结果的数量；results：输出匹配的护士列表（需提前分配内存）
int fuzzy_search_nurse(Nurse *head, const char *keyword, Nurse **results, int max_results) {
	if (head == NULL || keyword == NULL || strlen(keyword) == 0) {
		return 0;
	}
	int count = 0;
	Nurse *current = head;
	while (current != NULL && count < max_results) {
		// 匹配规则：关键词是工号/姓名/科室的子串（不区分大小写可加tolower，此处简化）
		if (strstr(current->staff_id, keyword) != NULL ||
			strstr(current->name, keyword) != NULL ||
			strstr(current->department, keyword) != NULL) {
			results[count++] = current;
		}
		current = current->next;
	}
	return count;
}

// 展示模糊查询结果并让用户选择
// 返回值：用户选中的护士节点（NULL表示取消/退出）
Nurse *select_nurse_by_fuzzy_search(Nurse *head) {
	char keyword[50];
	const int MAX_RESULTS = 20; // 最大展示20条结果
	Nurse *results[MAX_RESULTS];
	
	while (1) {
		// 1. 输入查询关键词
		printf("\n===== 护士模糊查询 =====\n");
		printf("请输入查询关键词（工号/姓名/科室，输入0返回上一级）：");
		scanf("%s", keyword);
		clear_input_buffer(); // 清除回车
		
		// 2. 退出查询
		if (strcmp(keyword, "0") == 0) {
			printf("退出查询，返回上一级菜单...\n");
			return NULL;
		}
		
		// 3. 执行模糊查询
		int match_count = fuzzy_search_nurse(head, keyword, results, MAX_RESULTS);
		
		// 4. 无匹配结果
		if (match_count == 0) {
			printf("未找到包含「%s」的护士信息！\n", keyword);
			printf("是否重新查询？(1=重新查询，0=返回上一级)：");
			int choice;
			while (scanf("%d", &choice) != 1 || (choice != 0 && choice != 1)) {
				clear_input_buffer();
				printf("输入错误！请输入1(重新查询)或0(返回)：");
			}
			clear_input_buffer();
			if (choice == 0) {
				return NULL;
			}
			continue; // 重新查询
		}
		
		// 5. 展示匹配结果
		printf("\n===== 匹配结果（共%d条）=====\n", match_count);
		for (int i = 0; i < match_count; i++) {
			printf("[%d] 工号：%s | 姓名：%s | 科室：%s\n",
				   i+1, results[i]->staff_id, results[i]->name, results[i]->department);
		}
		
		// 6. 选择结果
		printf("\n请选择操作：\n");
		printf("1~%d = 选中对应医生 | 0 = 重新查询 | -1 = 返回上一级\n", match_count);
		int select;
		while (1) {
			printf("请输入选项：");
			if (scanf("%d", &select) != 1) {
				clear_input_buffer();
				printf("输入错误！请输入数字！\n");
				continue;
			}
			clear_input_buffer();
			if (select == 0) {
				break; // 重新查询
			} else if (select == -1) {
				return NULL; // 返回上一级
			} else if (select >= 1 && select <= match_count) {
				return results[select-1]; // 返回选中的医生
			} else {
				printf("输入超出范围！请输入1~%d、0或-1\n", match_count);
			}
		}
	}
}

/*护士函数4：修改多名护士职称*/
void update_nurse_title(Nurse *head_N){
	int number=1;
	while(number){
		int choice=0;
		int sure=0;			
		// 1. 模糊查询选择护士
		Nurse *target= select_nurse_by_fuzzy_search(head_N);
		if (target == NULL) { // 用户取消查询
			break;
		}
		
		printf("接下来将要修改%s的职称\n",target->name);
		clear_input_buffer();
		printf("请选择这位护士对应的新职称：\n");
		printf("1.护士  2.护师 \n");
		printf("3.主管护师 4.副主任护师 5.主任护士 \n");
		sure=0;
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:strcpy( target->job_title,"护士");break;
				case 2:strcpy( target->job_title,"护师");break;
				case 3:strcpy( target->job_title,"主管护师");break;
				case 4:strcpy( target->job_title,"副主任护师");break;
				case 5:strcpy( target->job_title,"主任护士");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位医生对应的新职称是:%s\n",target->job_title);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		printf("已成功修改该名护士的职称，是否继续修改其他护士的职称?\n");
		clear_input_buffer();
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
	}
}


/*护士函数1：添加新护士*/
void add_new_nurse(Nurse *head_N){
	int number=1;
	while(number){
		Nurse *new_N=(Nurse*)malloc(sizeof(Nurse));
		clear_input_buffer();
		printf("请输入新来的护士的姓名：\n");
		int sure=0;
		while(sure==0){
			while(scanf("%s",new_N->name)!=1||!check_name(new_N->name)){
				if(check_name(new_N->name)==false){
					printf("%s",new_N->name);
					clear_input_buffer();
					printf("输入名字里包含非法字符请重新输入：\n");
				}
				else
					printf("请输入正确的格式：\n");
			}
			clear_input_buffer();
			printf("这位新护士的姓名是：%s\n",new_N->name);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
		}
		//年龄	
		sure=0;
		printf("请输入新护士的年龄数字:\n");
		while(sure==0){
			while(scanf("%d",&new_N->age)!=1||new_N->age>=130||new_N->age<=18){
				clear_input_buffer();
				printf("请输入正确的年龄数字:\n");
			}
			clear_input_buffer();
			printf("这位新护士的年龄是：%d\n",new_N->age);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
		}
		//身份证号
		sure=0;
		clear_input_buffer();
		printf("请输入这新护士的身份证号：\n");
		while(sure==0){
			while(scanf("%s",new_N->id_card_number)!=1||!check_id_card_number(new_N->id_card_number)){
				clear_input_buffer();
				printf("输入身份证号包含除“0-9”和‘X’以外的非法字符!\n请重新输入:\n");
			}
			clear_input_buffer();
			printf("这位新护士的身份证号是%s：\n",new_N->id_card_number);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
		}
		//性别
		sure=0;
		printf("请输入这新护士的性别：(女士输入：女 男士输入：男)\n");
		while(sure==0){
			char G[10];
			while(scanf("%s",G)!=1||(strcmp(G,"女")!=0&&strcmp(G,"男")!=0)){ //不区分大小写使输入更具有普遍性
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的性别\n:");
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			strcpy(new_N->gender,G);
			printf("这位新医生的性别是:%s\n",new_N->gender);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
		}
		
		
		
		//电话
		sure=0;
		printf("请输入这新护士的电话号码：\n");
		while(sure==0){
			while(scanf("%s",new_N->phone_number)!=1||!check_phone_number(new_N->phone_number)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("输入电话号码包含除“0-9”以外的非法字符!\n请重新输入:\n");
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位新护士的电话号码是:%s\n",new_N->phone_number);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		//输入科室
		sure=0;
		printf("请输入这新护士的对应科室的编码：\n");
		printf("1.普通内科 2.骨科 3.妇产科\n");
		printf("4.儿科 5.急诊科 6.影像科 7.医学检验科(化验)\n");
		int choice;
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5&&choice!=6&&choice!=7)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:strcpy( new_N->department,"普通内科");break;
				case 2:strcpy( new_N->department,"骨科");break;
				case 3:strcpy( new_N->department,"妇产科");break;
				case 4:strcpy( new_N->department,"儿科");break;
				case 5:strcpy( new_N->department,"急诊科");break;
				case 6:strcpy( new_N->department,"影像科");break;
				case 7:strcpy( new_N->department,"医学检验科(化验)");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位新护士的科室是:%s\n",new_N->department);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		//生日
		sure=0;
		while(sure!=1){
			printf("请输入新来的护士的出生日期（年 月 日）:\n");
			while(scanf("%d %d %d",&new_N->birthday.year,&new_N->birthday.month,&new_N->birthday.day)!=3){
				clear_input_buffer();
				printf("请输入正确的医生出生日期（年 月 日）:\n");
			}
			clear_input_buffer();
			printf("你输入的护士的出生日期：%d.%d.%d\n",new_N->birthday.year,new_N->birthday.month,new_N->birthday.day);
			printf("确认请按：1  重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
		}
		//工号
		sure=0;
		printf("请输入这新护士的工号\n");
		while(sure==0){
			scanf("%s",new_N->staff_id);
			clear_input_buffer();
			printf("这位新护士的身份证号是:%s\n",new_N->staff_id);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			//加这个函数确保工号的唯一性
			if(check_staff_id_nurse(new_N->staff_id,head_N)==false){
				printf("警告：该工号已被使用，请重新输入工号\n");
				sure=0;
			}
		}
		//登陆密码
		sure=0;
		printf("请输入这新护士账号的登陆密码：\n");
		while(sure==0){
			scanf("%s",new_N->login_password);
			clear_input_buffer();
			printf("这位新护士的登陆密码是:%s\n",new_N->login_password);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
		}
		
		sure=0;
		clear_input_buffer();
		printf("请输入这新护士的对应的职称：\n");
		printf("1.护士  2.护师 \n");
		printf("3.主管护师 4.副主任护师 5.主任护士 \n");
		choice=0;
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:strcpy( new_N->job_title,"护士");break;
				case 2:strcpy( new_N->job_title,"护师");break;
				case 3:strcpy( new_N->job_title,"主管护师");break;
				case 4:strcpy( new_N->job_title,"副主任护师");break;
				case 5:strcpy( new_N->job_title,"主任护士");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位新护士的职称是:%s\n",new_N->job_title);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		
		//在职状态:1  在职   2  休假   3离职
		sure=0;
		printf("请输入这新护士的在职状态：\n");
		printf("1.在职 2.休假 3.离职\n");
		choice=0;
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:new_N->staff_status=1;printf("这位新护士的在职状态是:在职");break;
				case 2:new_N->staff_status=2;printf("这位新护士的在职状态是:休假");break;
				case 3:new_N->staff_status=3;printf("这位新护士的在职状态是:离职");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		
		//工作时间表		
		//值班表1-7依次代表周一到周日，抛弃schedul[0]便于后续代码的输出。一天分成三个班，早/下午/晚班用0-2依次代替,上不上1/0
		int temp;
		int valid_input; // 标记输入是否有效
		
		printf("=== 护士排班录入系统 ===\n");
		printf("规则：输入三位数字，1=上班，0=休息\n");
		printf("示例：101 代表 上午班+晚班\n\n");
		sure=0;
		while(sure==0){
			for (int i = 1; i <= 7; i++) {
				valid_input = 0; // 重置标记
				while (!valid_input) {
					clear_input_buffer();
					printf("请输入周%d的排班: ", i);
					// 1. 尝试读取一个整数
					// scanf 返回 1 代表成功读取了一个整数
					if (scanf("%d", &temp) == 1) {
						// 2. 范围检查：必须是 0 到 111 之间的数
						// 防止输入 1234 或 -5
						if (temp >= 0 && temp <= 111) {
							
							// 3. 位数值检查：每一位只能是 0 或 1
							// 百位 (temp/100), 十位 ((temp/10)%10), 个位 (temp%10)
							int h = temp / 100;
							int t = (temp / 10) % 10;
							int o = temp % 10;
							
							if ((h == 0 || h == 1) && (t == 0 || t == 1) && (o == 0 || o == 1)) {
								// --- 数据合法，存入数组 ---
								new_N->schedule[i][0] = h;
								new_N->schedule[i][1] = t;
								new_N->schedule[i][2] = o;
								valid_input = 1; // 跳出 while 循环
							} else {
								printf(" 错误：数字只能包含 0 或 1 (例如 101)。\n");
							}
						} else {
							printf(" 错误：请输入 0 到 111 之间的数字。\n");
						}
					} else {
						// 4. 处理非数字输入（如输入了字母 'a'）
						printf(" 错误：请输入有效的数字！\n");
						// 关键步骤：清空输入缓冲区
						// 如果不加这段代码，错误的字符会留在缓冲区，导致死循环
						int c;
						while ((c = getchar()) != '\n' && c != EOF);
					}
				}
			}
			// --- 输出验证结果 ---
			printf("\n=== 排班录入成功 ===\n");
			printf("-----------------------------------------------------------------------------------------\n");
			printf("|                                        排班表                                         |\n");
			printf("-----------------------------------------------------------------------------------------\n");
			
			printf("|-------日期-------|--------上午--------|-------下午---------|-----------晚班-----------|\n");
			printf("_________________________________________________________________________________________\n");
			for(int i=1; i<=7; i++){
				printf("|         周%d      |          %d         |         %d          |            %d             |\n", i, new_N->schedule[i][0], new_N->schedule[i][1], new_N->schedule[i][2]);
				printf("_________________________________________________________________________________________\n");
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		//链接链表
		new_N->next = head_N;
		head_N = new_N;
		
		printf("已成功存入该名护士的信息，是否继续输入下一名新护士的信息?\n");
		clear_input_buffer();
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
	}
}

/*护士函数3：修改护士在职状态*/
void change_status_nurse(Nurse *head_N){
	int number=1;
	while(number){
		int choice=0;
		int sure=0;			
		// 1. 模糊查询选择护士
		Nurse *target= select_nurse_by_fuzzy_search(head_N);
		if (target == NULL) { // 用户取消查询
			break;
		}
		printf("接下来将要修改%s的在职状态\n",target->name);
		clear_input_buffer();
		printf("请选择这位护士的更新后的在职状态：\n");
		printf("1.在职 2.休假 3.离职\n");
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:target->staff_status=1;printf("这位新护士的在职状态是:在职");break;
				case 2:target->staff_status=2;printf("这位新护士的在职状态是:休假");break;
				case 3:target->staff_status=3;printf("这位新护士的在职状态是:离职");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		
		clear_input_buffer();
		printf("已成功修改该名护士的在职状态，是否继续修改其他护士的在职状态?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
	}
}
/*护士函数2：修改护士值班表*/
void update_N_schedule(Nurse *head_N){
	int number=1;
	while(number){
		int temp;
		int valid_input; // 标记输入是否有效
		int sure=0;			
		// 1. 模糊查询选择护士
		Nurse *target= select_nurse_by_fuzzy_search(head_N);
		if (target == NULL) { // 用户取消查询
			break;
		}
		printf("接下来将要修改%s的值班表\n",target->name);
		printf("=== 护士排班录入系统 ===\n");
		printf("规则：输入三位数字，1=上班，0=休息\n");
		printf("示例：101 代表 上午班+晚班\n\n");
		clear_input_buffer();
		printf("请输入修改后的值班表:\n");
		sure=0;
		while(sure==0){
			for (int i = 1; i <= 7; i++) {
				valid_input = 0; // 重置标记
				while (!valid_input) {
					clear_input_buffer();
					printf("请输入周%d的排班: ", i);
					// 1. 尝试读取一个整数
					// scanf 返回 1 代表成功读取了一个整数
					if (scanf("%d", &temp) == 1) {
						// 2. 范围检查：必须是 0 到 111 之间的数
						// 防止输入 1234 或 -5
						if (temp >= 0 && temp <= 111) {
							
							// 3. 位数值检查：每一位只能是 0 或 1
							// 百位 (temp/100), 十位 ((temp/10)%10), 个位 (temp%10)
							int h = temp / 100;
							int t = (temp / 10) % 10;
							int o = temp % 10;
							
							if ((h == 0 || h == 1) && (t == 0 || t == 1) && (o == 0 || o == 1)) {
								// --- 数据合法，存入数组 ---
								target->schedule[i][0] = h;
								target->schedule[i][1] = t;
								target->schedule[i][2] = o;
								valid_input = 1; // 跳出 while 循环
							} else {
								printf(" 错误：数字只能包含 0 或 1 (例如 101)。\n");
							}
						} else {
							printf(" 错误：请输入 0 到 111 之间的数字。\n");
						}
					} else {
						// 4. 处理非数字输入（如输入了字母 'a'）
						printf(" 错误：请输入有效的数字！\n");
						// 关键步骤：清空输入缓冲区
						// 如果不加这段代码，错误的字符会留在缓冲区，导致死循环
						int c;
						while ((c = getchar()) != '\n' && c != EOF);
					}
				}
			}
			// --- 输出验证结果 ---
			printf("\n=== 排班录入成功 ===\n");
			printf("-----------------------------------------------------------------------------------------\n");
			printf("|                                        排班表                                         |\n");
			printf("-----------------------------------------------------------------------------------------\n");
			
			printf("|-------日期-------|--------上午--------|-------下午---------|-----------晚班-----------|\n");
			printf("_________________________________________________________________________________________\n");
			for(int i=1; i<=7; i++){
				printf("|         周%d      |          %d         |         %d          |            %d             |\n", i,target->schedule[i][0], target->schedule[i][1], target->schedule[i][2]);
				printf("_________________________________________________________________________________________\n");
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}
		
		printf("已成功修改该名护士的排班，是否继续修改其他护士的排班?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
		
		
	}
	
}
/*护士函数5：修改护士所在的科室*/
void change_department_nurse(Nurse *head_N){
	int number=1;
	while(number){
		int choice=0;
		int sure=0;		
		// 1. 模糊查询选择护士
		Nurse *target= select_nurse_by_fuzzy_search(head_N);
		if (target == NULL) { // 用户取消查询
			break;
		}
		printf("接下来将要修改%s的所在的科室\n",target->name);
		printf("请输入该护士的对应的新科室的编码：\n");
		printf("1.普通内科 2.骨科 3.妇产科\n");
		printf("4.儿科 5.急诊科 6.影像科 7.医学检验科(化验)\n");
		while(sure==0){
			while(scanf("%d",&choice)!=1||(choice!=1&&choice!=2&&choice!=3&&choice!=4&&choice!=5&&choice!=6&&choice!=7)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}
			switch (choice) {
				case 1:strcpy( target->department,"普通内科");break;
				case 2:strcpy( target->department,"骨科");break;
				case 3:strcpy( target->department,"妇产科");break;
				case 4:strcpy( target->department,"儿科");break;
				case 5:strcpy( target->department,"急诊科");break;
				case 6:strcpy( target->department,"影像科");break;
				case 7:strcpy( target->department,"医学检验科(化验)");break;
			}
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
			printf("这位护士修改后所在的科室是:%s\n",target->department);
			printf("确认请按：1   重新输入请按：0\n");
			while(scanf("%d",&sure)!=1||(sure!=1&&sure!=0)){
				clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
				printf("请输入正确的选项：\n");
			}//这样能退出while的情况只可能是sure为0或者为1，如果是1则退出循环，若是0则接着循环即重新输入；
			clear_input_buffer();	// 清除输入缓冲区垃圾（回车、多余字符）
		}	
		
		clear_input_buffer();
		printf("已成功存入改名护士的信息，是否继续输入下一名新护士的信息?\n");
		printf("继续存入请输入：1   完成输入请输入0：\n");
		while(scanf("%d",&number)!=1||(number!=1&&number!=0)){
			clear_input_buffer();
			printf("请输入正确的操作选项\n");
		}
	}
	
}

