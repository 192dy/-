#ifndef REGISTRATION_H
#define REGISTRATION_H
#include"HMS.h"
#include<time.h>
#include<stdio.h>


/*---------- 预约渠道 ----------*/
typedef enum {
	CHANNEL_ONLINE = 1,     // 线上预约（提前1-7天）
	CHANNEL_OFFLINE = 2     // 线下现场挂号（仅当天）
} BookingChannel;

/*---------- 时段枚举（上午/下午）----------*/
typedef enum {
	TIME_SLOT_MORNING = 1,   // 上午 08:00-11:30
	TIME_SLOT_AFTERNOON = 2  // 下午 13:30-17:30
} TimeSlot;

/*---------- 模糊时段（不给精确分钟，只给区间）----------*/
typedef enum {
	FUZZY_MORNING_EARLY,      // 上午前半段 08:00-09:30
	FUZZY_MORNING_LATE,       // 上午后半段 09:30-11:30
	FUZZY_AFTERNOON_EARLY,    // 下午前半段 13:30-15:00
	FUZZY_AFTERNOON_LATE,     // 下午后半段 15:00-17:30
	FUZZY_UNKNOWN             // 无法确定
} FuzzyTimeSlot;

/*---------- 优先级 ----------*/
typedef enum {
	PRIORITY_APPOINTMENT = 1,   // 预约患者（高优先级）
	PRIORITY_WALK_IN = 2        // 现场挂号（低优先级）
} QueuePriority;

/*---------- 限号检查结果 ----------*/
typedef enum {
	CHECK_PASS = 0,
	CHECK_FAIL_TOTAL,        // 全院400满
	CHECK_FAIL_DOCTOR,       // 医生30满
	CHECK_FAIL_PATIENT,      // 患者5次满
	CHECK_FAIL_DEPT,         // 同科室重复
	CHECK_FAIL_DOCTOR_OFF,   // 医生不值班
	CHECK_FAIL_DATE_INVALID  // 日期不符合预约规则
} CheckResult;

/*---------- 排队信息结构体 ----------*/
typedef struct {
	int appointment_queue_pos;   // 预约队列位置（0=不在预约队列）
	int walkin_queue_pos;        // 现场队列位置（0=不在现场队列）
	int total_queue_pos;         // 合并后总位置
	FuzzyTimeSlot fuzzy_slot;    // 模糊时段
	QueuePriority priority;      // 优先级类型
	const char* fuzzy_desc;      // 模糊描述文字
} QueueInfo;

/*============================================================
函数声明
============================================================*/

// 日期有效性
bool is_date_bookable_online(DateTime today, DateTime target_date);
bool is_date_bookable_offline(DateTime today, DateTime target_date);

// 模糊时段转换
FuzzyTimeSlot precise_to_fuzzy(TimeSlot slot, int queue_position);
const char* fuzzy_slot_description(FuzzyTimeSlot slot);

// 核心排队逻辑
QueueInfo calculate_queue_info(Consultation *head_C, char *doctorID,
							   DateTime target_date, TimeSlot time_slot,
							   BookingChannel channel);

// 限号检查
CheckResult check_booking_quota(Consultation *head_C, Doctor *doctor,
								 char *patientID, DateTime today,
								DateTime target_date, TimeSlot time_slot,
								BookingChannel channel);

// 挂号执行
bool execute_booking(Doctor **head_D0, Patient **head_P0, Consultation **head_C0,
					 char *patientID,  char *doctorID,
					 char *dept_name, DateTime target_date,
					 TimeSlot time_slot, BookingChannel channel,
					 char *out_recordID, size_t recordID_size);

// 交互流程
void online_booking_flow(Doctor **head_D0, Patient **head_P0,
						 Consultation **head_C0, char *patientID);
void offline_booking_flow(Doctor **head_D0, Patient **head_P0,
						  Consultation **head_C0, char *patientID,
						  bool is_walk_in);

// 叫号（医生端，预约优先）
void reading_waiting_info_v2(Consultation **head_C0, Patient **head_P0,
							 char *doctorID);

// 患者查看挂号记录
void view_my_appointments(Consultation *head_C, char *patientID);
void cancel_appointment_flow(Consultation **head_C0, char *patientID);

// 护士查看队列
void view_doctor_queue_status(Doctor *head_D, Consultation *head_C);

// 患者系统主函数
void patient_system_v2(char *PatientID, Doctor **head_D0, Patient **head_P0,
					   Nurse **head_N0, Medicine **head_M0,
					   Bed **head_B0, Consultation **head_C0);

// 收集该医生该时段所有已挂号和现场挂号记录
void display_queue_detail(Consultation *head_C, const char *doc_id,
						  DateTime date, TimeSlot slot);





/*辅助函数：线上挂号时间检验
bool check_online_registration_time(DateTime current_time,DateTime appointment_time);


// 全局挂号计数器（封装访问）
void reset_daily_counters(void);           // 每日清零
bool is_new_day(DateTime last_reset);      // 检测日期切换
int get_daily_total_reg(void);             // 获取当日总挂号数

// 核心挂号函数
bool offline_registration(Doctor **head_D, Patient **head_P, Consultation **head_C,
						  char *patientID, char *doctorID, int time_period);
bool online_registration(Doctor **head_D, Patient **head_P, Consultation **head_C,
						 char *patientID, char *doctorID, DateTime appointment_time, int time_period);

typedef enum
{
CHECK_PASS = 0,// 通过
CHECK_FAIL_TOTAL = -1,// 总号源不足
CHECK_FAIL_DOCTOR = -2,// 医生号源不足
CHECK_FAIL_PATIENT = -3,// 患者挂号数超限
CHECK_FAIL_DEPT = -4// 科室挂号数超限
} CheckResult;

CheckResult check_reg_restriction(Consultation *head_C, Doctor *target_doctor, 
								  char *patientID, DateTime today, int time_period);

// 排队与时间管理
int calculate_queue_position(Consultation *head_C, char *doctorID,
							 DateTime appointment_date, bool is_morning);
void generate_record_ID(DateTime sign_in_time, char *doctorID, int seq, char *out);
void estimate_visit_time(DateTime base_time, int position, DateTime *out_time);

// 医生值班查询（从 doctor 模块查询，但在这里封装使用）
bool is_doctor_available(Doctor *doc, DateTime when, int time_period);*/

#endif

