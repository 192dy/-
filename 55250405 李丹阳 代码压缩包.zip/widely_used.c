#include"HMS.h"
#include"Doctor.h"
#include"Patient.h"
#include"Administrator.h"
#include"Nurse.h"
#include"F4.h"
#include"widely_used.h"
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<stdbool.h>
#include <time.h>   // 通用时间头文件
#include <windows.h>// Windows额外头文件

/*药品函数3：自动检查过期药品，去除对应的库存*/
//辅助函数（处理每单药品）
void check_signal_medicine_status(Medicine *M){
	MedicineIORecord *record=M->io_list;
	DateTime current=get_current_time();
	current.month+=1;
	if(current.month==13){
		current.month=1;
		current.year+=1;
	}
	while(record!=NULL){
		if(record->is_valid==true&&record->io_type==1
		   &&constract_two_days(current,record->deadline_time))//确认这条进货记录之前没有处理过
		{//确认时间只有这些时间要求全部满足
			record->is_valid=false;
			M->stock-=record->number;
		}
		record=record->next;
	}
}

void automatic_check_medicine(Medicine *head_M){
	while(head_M!=NULL){
		check_signal_medicine_status(head_M);
		head_M=head_M->next;
	}
}


int date_to_int(DateTime dt) {
	return dt.year * 10000 + dt.month * 100 + dt.day;
}

// 计算两个日期之间的天数差（简化版）
int days_between(DateTime a, DateTime b) {
	// 使用已有的date_to_days函数
	int da = date_to_days(a.year, a.month, a.day);
	int db = date_to_days(b.year, b.month, b.day);
	return db - da;
}

// 日期加法（返回新日期）
DateTime date_add_days(DateTime base, int days) {
	DateTime result = base;
	// 简化实现：逐天增加
	int month_days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	
	// 闰年判断
	bool is_leap = (base.year % 4 == 0 && base.year % 100 != 0) || (base.year % 400 == 0);
	if (is_leap) month_days[2] = 29;
	
	result.day += days;
	while (result.day > month_days[result.month]) {
		result.day -= month_days[result.month];
		result.month++;
		if (result.month > 12) {
			result.month = 1;
			result.year++;
			// 重新判断闰年
			is_leap = (result.year % 4 == 0 && result.year % 100 != 0) || (result.year % 400 == 0);
			month_days[2] = is_leap ? 29 : 28;
		}
	}
	return result;
}


// 时间比较辅助函数：t1<t2返回负数，t1==t2返回0，t1>t2返回正数
int time_compare(DateTime t1, DateTime t2) {
	int d1 = date_to_int(t1);
	int d2 = date_to_int(t2);
	if (d1 != d2) return d1 - d2;
	if (t1.hour != t2.hour) return t1.hour - t2.hour;
	if (t1.minute != t2.minute) return t1.minute - t2.minute;
	return t1.second - t2.second;
}



// 1
void clear_input_buffer(void){
	int c;
	while((c=getchar())!='\n' && c!=EOF);
}


//=====基础信息查询接口===//
// 2.1
Patient* find_patient(char* patientID_0,Patient *head_P) {
	Patient* p = head_P;
	while (p != NULL) {
		if (strcmp(p->patientID, patientID_0) == 0)
			return p;
		p = p->next;
	}
	return NULL;
}
// 2.2
Doctor* find_doctor(char* doctorID,Doctor *head_D) {
	Doctor* d = head_D;
	while (d != NULL) {
		if (strcmp(d->staff_id, doctorID) == 0)
			return d;
		d = d->next;
	}
	return NULL;
}
// 2.3
Nurse* find_nurse(char* nurseID,Nurse *head_N) {
	Nurse* n = head_N;
	while (n != NULL) {
		if (strcmp(n->staff_id, nurseID) == 0)
			return n;
		n = n->next;
	}
	return NULL;
}
// 2.4
Administrator* find_administrator(char* AdministratorID,Administrator *head_A) {
	Administrator* a = head_A;
	while (a != NULL) {
		if (strcmp(a->staff_id, AdministratorID) == 0)
			return a;
		a = a->next;
	}
	return NULL;
}
// 2.5
Medicine* find_medicine(char* Medical_name,Medicine *head_M){
	while(head_M!=0&&strcmp(Medical_name,head_M->name)!=0){
		head_M=head_M->next;
	}
	if(head_M==NULL)return NULL;
	return head_M;
}
//2.6
ExaminationItem* find_by_code(ExaminationItem *head, const char *code) {
	for (ExaminationItem *p = head; p; p = p->next)
		if (strcmp(p->item_code, code) == 0) return p;
	return NULL;
}



// 工具函数：将日期转换成 从公元0年开始的总天数（用于计算差值）
int date_to_days(int year, int month, int day)
{
	if (month < 3) {
		year--;
		month += 12;
	}
	return 365 * year + year / 4 - year / 100 + year / 400 +
	(153 * month - 457) / 5 + day - 32045;
}




//3
//辅助算出从2000.1.1开始到输入时间点的天数
//要处理闰年的情况，还有一种情况就是直接从2000.1.1算出对应的天数；
int days(DateTime time){
	int day=0;
	int prime_year=2000;
	
	// 加保护，防止非法年份导致死循环
	if(time.year < 2000){
		printf("输入年份小于2000即未出院数据进入\n");
		 return 0;
		
	}
	while(prime_year != time.year){
		if((prime_year%4==0 && prime_year%100!=0) || prime_year%400==0)
			day += 366;
		else 
			day += 365;
		prime_year++;
	}
	int month=1;
	while(month!=time.month){
		if(month==1||month==3||month==5||month==7||month==8||month==10) day+=31;  //1 3 5 7 8 10 12这里去除12因为他就没有=12的机会
		else if(month==4||month==6||month==9||month==11) day+=30;
		else if(month==2){
			if((time.year%4==0&&time.year%100!=0)||time.year%400==0) day+=29;
			else day+=28;
		}
		month++;
	}
	day+=time.day;
	return day;
}

//4.1
//算出两个时间段的时间
int calculate_day(DateTime in,DateTime out){
	int day=0;
	day=days(out)-days(in);
	if(out.hour<8||(out.hour==8&&out.minute==0&&out.second==0))
		day--;
	return day+1;
}  


//4.2 计算住院出院时间差天数
//这个函数用来处理，就是输入的是住院，出院时间的计算天数的函数
// 你要的函数：出院 0~8点不算当天
int get_days_between(DateTime start, DateTime end)
{
	// 1. 计算两个日期的自然日差（不看时分秒）
	int days_start = date_to_days(start.year, start.month, start.day);
	int days_end = date_to_days(end.year, end.month, end.day);
	int total_days = days_end - days_start;
	total_days++;
	// 2. 如果出院时间在 00:00 ~ 08:00 之间，减去1天
	if (end.hour < 8||(end.hour==8&&end.minute==0&&end.second==0)) {
		total_days--;
	}
	// 3. 天数不能为负数
	return (total_days < 0) ? 0 : total_days;
}

//4.3  计算住院内的一段时间天数
//这个函数用来处理，就是输入的是住院的一段时间时间的计算天数的函数
// 你要的函数：出院 0~8点不算当天
int get_days_between_1(DateTime start, DateTime end)
{
	// 1. 计算两个日期的自然日差（不看时分秒）
	int days_start = date_to_days(start.year, start.month, start.day);
	int days_end = date_to_days(end.year, end.month, end.day);
	int total_days = days_end - days_start+1;
	
	// 2. 如果当前扣费时间时间在 00:00 ~ 08:00 之间，减去1天
	if (end.hour < 8||(end.hour==8&&end.minute==0&&end.second==0)) {
		total_days--;
	}
	if(start.hour>8){
		total_days--;
	}	
	// 3. 天数不能为负数
	return (total_days < 0) ? 0 : total_days;
}

// 5
//比较两个时间段精确到秒若T1>=T2返回true；//要满足天数可以比较大小，或者天数相同时比当天已经度过的秒数就行 
bool constract_two_days(DateTime T1,DateTime T2){
	if(days(T2)<days(T1)
	   ||(days(T2)==days(T1)
		  &&(T2.hour*3600+T2.minute*60+T2.second<=T1.hour*3600+T1.minute*60+T1.second)))
		return true;
	return false;
}
// 6
//检查输入的时间点是否超越当前时间，
bool check_weather_surpuss_1(DateTime initial){
	DateTime current=get_current_time();
	if(constract_two_days(current,initial))return true;
	return false;
}

// 7. date转DateTime（默认时分秒为0）
DateTime date_to_datetime(date day, int hour, int minute, int second) {
	DateTime dt;
	dt.year = day.year;
	dt.month = day.month;
	dt.day = day.day;
	dt.hour = hour;
	dt.minute = minute;
	dt.second = second;
	return dt;
}

// 8.辅助函数：得到date对应的星期几（逻辑不变，仅参数更清晰）
int Get_current_day_of_the_week(date day) {
	// 直接用工具函数转换，避免手动赋值
	DateTime D1 = date_to_datetime(day, 0, 0, 0);//把date转换成datetime
	int total_days = days(D1);
	return ( total_days - 1 + 5 ) % 7 + 1;
}


//9. 获取系统当前时间，返回封装好的DateTime结构体
DateTime get_current_time(void) {
	return current_dt;
}



//10.辅助函数，获取科室索引
int get_dept_index(const char*input_dept_names)
{
	for(int i=0;i<7;i++)
	{
		if(strcmp(input_dept_names,dept_names[i])==0) return i;
	}
	return -1;
}


//11.上线就执行这段时间所有床位的扣费
void auto_deduct_bed_fee_for_all(Bed *head_B)
{
	DateTime now = get_current_time();
	Bed *p = head_B;
	
	while (p != NULL) {
		if (p->status != NULL&&p->status->check_out.year==0)   // 遍历床位链表找出所有状态是住院的床位
		{
			Admission_information *info = p->status;
			int days = get_days_between_1(info->last_deduct_day, now);
			if (days <= 0) {
				p = p->next;
				continue;
			}
			
			float between_cost = p->daily_cost * days;
			info->ya_cash -= between_cost;
			info->cost_cash += between_cost;
			info->last_deduct_day = now;
		}
		p = p->next;
	}
}


